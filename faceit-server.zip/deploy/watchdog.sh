#!/bin/bash
# Сторож ETN FACEIT: запускается таймером раз в минуту (под root).
# Сайт не отвечает 2 минуты подряд — перезапускает его и пишет админам в Telegram.
# Также следит за Caddy (https), заполненностью диска и свободной памятью.
main() {
  local ST=/var/lib/faceit-watchdog
  mkdir -p "$ST"
  tg() {
    python3 -I - "$1" <<'PY'
import json, sys, urllib.request, urllib.parse
try:
    db = json.load(open('/opt/faceit/data/db.json', encoding='utf-8'))
    tok = (db.get('tg') or {}).get('token')
    if not tok:
        sys.exit(0)
    for u in db.get('users', {}).values():
        if u.get('admin') and u.get('tg') and not u.get('banned'):
            data = urllib.parse.urlencode({'chat_id': u['tg']['id'], 'text': sys.argv[1]}).encode()
            try:
                urllib.request.urlopen('https://api.telegram.org/bot%s/sendMessage' % tok, data, timeout=10)
            except Exception:
                pass
except Exception:
    pass
PY
  }

  if curl -fsS --max-time 6 http://127.0.0.1:8090/api/health >/dev/null 2>&1; then
    if [ -f "$ST/down" ]; then
      local mins=$(( ( $(date +%s) - $(cat "$ST/down") ) / 60 ))
      tg "✅ FACEIT снова работает (не отвечал примерно ${mins} мин)."
      rm -f "$ST/down"
    fi
    echo 0 > "$ST/fails"
  else
    local f=$(( $(cat "$ST/fails" 2>/dev/null || echo 0) + 1 ))
    echo "$f" > "$ST/fails"
    if [ "$f" -eq 2 ]; then
      date +%s > "$ST/down"
      systemctl restart faceit
      tg "⚠️ FACEIT не отвечал 2 минуты — перезапускаю сервер."
    elif [ "$f" -eq 6 ]; then
      tg "🛑 FACEIT не поднимается уже 6 минут. Зайди в Termius и посмотри журнал: journalctl -u faceit -n 50"
    fi
  fi

  if [ -f /etc/caddy/faceit.caddy ]; then
    if systemctl is-active --quiet caddy; then
      rm -f "$ST/caddy"
    elif [ ! -f "$ST/caddy" ]; then
      touch "$ST/caddy"
      systemctl restart caddy
      tg "⚠️ Caddy (https) остановился — перезапускаю."
    fi
  fi

  local use
  use=$(df --output=pcent / 2>/dev/null | tail -1 | tr -dc 0-9)
  if [ "${use:-0}" -ge 90 ]; then
    [ -f "$ST/disk" ] || { touch "$ST/disk"; tg "💾 Диск сервера заполнен на ${use}%."; }
  elif [ "${use:-0}" -lt 85 ]; then
    rm -f "$ST/disk"
  fi

  local avail total pct
  avail=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
  total=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
  if [ -n "$avail" ] && [ -n "$total" ] && [ "$total" -gt 0 ]; then
    pct=$(( avail * 100 / total ))
    if [ "$pct" -le 5 ]; then
      [ -f "$ST/mem" ] || { touch "$ST/mem"; tg "🧠 На сервере заканчивается память: свободно ${pct}%."; }
    elif [ "$pct" -ge 15 ]; then
      rm -f "$ST/mem"
    fi
  fi
}
main "$@"
exit 0
