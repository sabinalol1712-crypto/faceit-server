#!/bin/bash
# Запускается таймером каждые 3 минуты: берёт новую версию с GitHub.
# Перезапуск — когда никто не в матче и не в лобби (или после 30 минут ожидания). Аккаунты и матчи хранятся в data/ и не теряются.
DIR=/opt/faceit
cd "$DIR" || exit 0
[ -d .git ] || exit 0
# если Caddyfile переписали (например, переустановили Prodigy Strike) — вернуть адрес FACEIT
if [ -f /etc/caddy/faceit.caddy ] && [ -f /etc/caddy/Caddyfile ] && ! grep -q 'import /etc/caddy/faceit.caddy' /etc/caddy/Caddyfile; then
  printf '\nimport /etc/caddy/faceit.caddy\n' >> /etc/caddy/Caddyfile
  systemctl reload caddy 2>/dev/null || systemctl restart caddy
fi
OLD=$(git rev-parse HEAD)
sudo -u faceit git fetch -q origin || exit 0
NEW=$(git rev-parse origin/HEAD 2>/dev/null || git rev-parse origin/main)
[ "$OLD" = "$NEW" ] && { rm -f /tmp/faceit-pending; exit 0; }
H=$(curl -fsS --max-time 3 http://127.0.0.1:8090/api/health)
ACTIVE=$(echo "$H" | sed -n 's/.*"active":\([0-9]*\).*/\1/p')
QUEUE=$(echo "$H" | sed -n 's/.*"queue":\([0-9]*\).*/\1/p')
[ -f /tmp/faceit-pending ] || date +%s > /tmp/faceit-pending
WAITED=$(( $(date +%s) - $(cat /tmp/faceit-pending) ))
if [ "${ACTIVE:-0}${QUEUE:-0}" != "00" ] && [ "$WAITED" -lt 1800 ]; then exit 0; fi
sudo -u faceit git reset -q --hard "$NEW"
if [ -f faceit-server.zip ]; then sudo -u faceit python3 -m zipfile -e faceit-server.zip . ; fi
cp deploy/faceit.service /etc/systemd/system/faceit.service
systemctl daemon-reload
systemctl restart faceit
rm -f /tmp/faceit-pending
echo "updated $OLD -> $NEW"
