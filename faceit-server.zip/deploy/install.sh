#!/bin/bash
# Установка ETN FACEIT на сервер с Ubuntu 22.04 / 24.04 (можно на тот же, где работает Prodigy Strike).
# Запуск (под root):
#   git clone https://github.com/ТВОЙ_НИК/faceit-server /opt/faceit && cd /opt/faceit && python3 -m zipfile -e faceit-server.zip . && bash deploy/install.sh
set -e
DIR=/opt/faceit
PORT=8090
export DEBIAN_FRONTEND=noninteractive
cd "$DIR"
[ -f server.js ] || python3 -m zipfile -e faceit-server.zip .

echo "== пакеты"
NEED=""
command -v node >/dev/null 2>&1 || NEED="$NEED nodejs"
command -v git >/dev/null 2>&1 || NEED="$NEED git"
command -v curl >/dev/null 2>&1 || NEED="$NEED curl"
if [ -n "$NEED" ]; then apt-get update -y && apt-get install -y $NEED; fi
NODE_MAJOR=$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)
if [ "$NODE_MAJOR" -lt 16 ]; then echo "!! Node.js $NODE_MAJOR слишком старый, нужен 16 или новее (Ubuntu 24.04)."; exit 1; fi

echo "== пользователь и папка данных"
id faceit >/dev/null 2>&1 || useradd --system --home "$DIR" --shell /usr/sbin/nologin faceit
mkdir -p "$DIR/data"
chown -R faceit:faceit "$DIR"
chmod 750 "$DIR/data"
git config --system --add safe.directory "$DIR" 2>/dev/null || true

echo "== служба"
cp deploy/faceit.service /etc/systemd/system/faceit.service
cp deploy/faceit-update.service /etc/systemd/system/faceit-update.service
cp deploy/faceit-update.timer /etc/systemd/system/faceit-update.timer
systemctl daemon-reload
systemctl enable faceit >/dev/null 2>&1
systemctl restart faceit
if [ -d "$DIR/.git" ]; then systemctl enable --now faceit-update.timer >/dev/null 2>&1; fi
sleep 1
curl -fsS --max-time 5 "http://127.0.0.1:$PORT/api/health" >/dev/null && echo "сервер отвечает" || echo "!! сервер не отвечает — смотри: journalctl -u faceit -n 50"

echo "== внешний адрес"
pub_ip() {
  local ip
  ip=$(curl -fsS --max-time 3 http://169.254.169.254/hetzner/v1/metadata/public-ipv4 2>/dev/null || true)
  if [ -n "$ip" ]; then echo "$ip"; return; fi
  for ip in $(hostname -I); do
    case "$ip" in
      *:*|10.*|127.*|169.254.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*|100.6[4-9].*|100.[7-9][0-9].*|100.1[01][0-9].*|100.12[0-7].*) ;;
      *) echo "$ip"; return ;;
    esac
  done
  curl -fsS --max-time 5 https://api.ipify.org 2>/dev/null || true
}
IP=$(pub_ip)
command -v caddy >/dev/null 2>&1 || apt-get install -y caddy >/dev/null 2>&1 || true
if command -v caddy >/dev/null 2>&1 && [ -n "$IP" ]; then
  HOST="faceit.$(echo "$IP" | tr '.' '-').sslip.io"
  printf '%s {\n\treverse_proxy 127.0.0.1:%s\n}\n' "$HOST" "$PORT" > /etc/caddy/faceit.caddy
  touch /etc/caddy/Caddyfile
  grep -q 'import /etc/caddy/faceit.caddy' /etc/caddy/Caddyfile || printf '\nimport /etc/caddy/faceit.caddy\n' >> /etc/caddy/Caddyfile
  systemctl enable caddy >/dev/null 2>&1 || true
  systemctl reload caddy 2>/dev/null || systemctl restart caddy
  URL="https://$HOST"
else
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then ufw allow $PORT/tcp; fi
  URL="http://$IP:$PORT"
fi
echo "$URL" > /root/faceit-address.txt
echo
echo "================================================"
echo " ГОТОВО. Сайт: $URL"
echo " (первая минута — Caddy получает сертификат)"
echo " Зарегистрируйся первым — станешь администратором."
echo "================================================"
