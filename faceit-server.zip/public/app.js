(() => {
  'use strict';

  // ---------- утилиты ----------
  const $ = (s, r = document) => r.querySelector(s);
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    if (props) {
      for (const k of Object.keys(props)) {
        const v = props[k];
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'style' && typeof v === 'object') { for (const sk of Object.keys(v)) { if (sk.startsWith('--')) el.style.setProperty(sk, v[sk]); else el.style[sk] = v[sk]; } }
        else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
        else if (k === 'svg') el.innerHTML = v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    for (const c of kids.flat(Infinity)) {
      if (c == null || c === false) continue;
      el.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  }
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { /* нет доступа */ } }
  };
  const mmss = s => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  const fmtDate = ts => { const d = new Date(ts); return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }); };
  const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20) ? b : c; };

  // ---------- состояние ----------
  const S = {
    token: store.get('etn_token', null),
    meta: null, st: null, offset: 0,
    page: 'play', es: null,
    shown: new Set(), dismissed: Number(store.get('etn_dismiss', 0)),
    mode: store.get('etn_mode', null), invTab: 'shop',
    matchMounted: null, chatLen: 0, lastAccept: null,
    modalKind: null, connOkAt: Date.now(),
    sound: store.get('etn_sound', '1') === '1', snow: store.get('etn_snow', '1') === '1', calm: store.get('etn_calm', '0') === '1', topBy: 'elo'
  };
  const now = () => Date.now() + S.offset;
  const itemById = id => (S.meta ? S.meta.catalog.find(i => i.id === id) : null);

  // ---------- сеть ----------
  async function api(path, body, method) {
    try {
      const res = await fetch(path, {
        method: method || (body === undefined ? 'GET' : 'POST'),
        headers: Object.assign({ 'Content-Type': 'application/json' }, S.token ? { Authorization: 'Bearer ' + S.token } : {}),
        body: body === undefined ? undefined : JSON.stringify(body)
      });
      let j = {};
      try { j = await res.json(); } catch (e) { j = { error: 'Сервер ответил с ошибкой (' + res.status + ')' }; }
      if (res.status === 401 && j.auth === false) { logout(true); return null; }
      if (!res.ok || j.error) { toast(j.error || 'Ошибка', 'err'); return null; }
      return j;
    } catch (e) {
      toast('Нет связи с сервером', 'err');
      return null;
    }
  }

  function connect() {
    if (S.es) S.es.close();
    const es = new EventSource('/api/events?t=' + encodeURIComponent(S.token));
    S.es = es;
    es.addEventListener('state', e => {
      const st = JSON.parse(e.data);
      S.offset = st.t - Date.now();
      S.st = st;
      S.connOkAt = Date.now();
      setConn(true);
      onState();
    });
    es.addEventListener('auth', () => { es.close(); logout(true); });
    es.onerror = () => { setConn(false); if (es.readyState === 2) setTimeout(() => { if (S.es === es && S.token) connect(); }, 2000); };
  }
  function setConn(ok) {
    const el = $('#conn');
    if (ok) { el.classList.add('hidden'); clearTimeout(setConn.t); setConn.t = null; return; }
    if (setConn.t) return;
    setConn.t = setTimeout(() => { el.classList.remove('hidden'); }, 2500);
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && S.token && (!S.es || S.es.readyState === 2)) connect();
  });

  // ---------- тосты ----------
  function toast(text, kind) {
    const el = h('div', { class: 'toast' + (kind ? ' ' + kind : '') }, text);
    $('#toasts').append(el);
    setTimeout(() => el.remove(), 3600);
    while ($('#toasts').children.length > 3) $('#toasts').firstChild.remove();
  }

  // ---------- Telegram: общие ----------
  const PLANE = '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M21.4 3.6 2.9 10.7c-1.2.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.1.9.8.9.5 0 .7-.2 1-.5l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.9-1.4-1.5zM8.9 13.4l9.6-6.1c.5-.3.9-.1.5.2l-8.2 7.4-.3 3.5z" fill="currentColor"/></svg>';
  function openTg(r) {
    const mobile = /Android|iPhone|iPad/i.test(navigator.userAgent);
    if (mobile) location.href = 'tg://resolve?domain=' + r.bot + (r.payload ? '&start=' + r.payload : '');
    else window.open(r.url || 'https://t.me/' + r.bot, '_blank');
  }

  // ---------- вход ----------
  function showAuth() {
    $('#boot').classList.add('hidden');
    $('#app').classList.add('hidden');
    const root = $('#auth');
    root.classList.remove('hidden');
    let mode = 'login';
    let poll = null;
    const stopPoll = () => { if (poll) { clearInterval(poll); poll = null; } };
    const finish = r => {
      stopPoll();
      S.token = r.token;
      store.set('etn_token', r.token);
      if (r.admin) toast('Ты первый игрок — у тебя права администратора', 'ok');
      startApp();
    };
    const draw = () => {
      stopPoll();
      root.innerHTML = '';
      const tgBot = S.meta && S.meta.tgBot;
      const card = h('div', { class: 'card auth-card' },
        h('div', { class: 'auth-emblem', svg: emblem() }),
        h('div', { class: 'logo big' }, h('b', null, (S.meta && S.meta.brand) || 'ETN'), h('span', null, 'FACEIT')));
      root.append(card);

      if (mode === 'reset') {
        card.append(h('h2', { class: 'auth-h' }, 'Новый пароль'));
        if (!tgBot) {
          card.append(h('p', { class: 'hint' }, 'Восстановить пароль может администратор — напиши ему.'),
            h('button', { class: 'btn block soft', style: { marginTop: '14px' }, onclick: () => { mode = 'login'; draw(); } }, 'Назад'));
          return;
        }
        const nick = h('input', { class: 'input', placeholder: 'Твой ник', maxlength: 16, autocapitalize: 'off', spellcheck: 'false' });
        const step = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } });
        const sendBtn = h('button', { class: 'btn block tg-btn', type: 'button' }, h('span', { svg: PLANE }), 'Получить код в Telegram');
        sendBtn.onclick = async () => {
          if (!nick.value.trim()) return toast('Напиши ник', 'err');
          sendBtn.disabled = true;
          const r = await api('/api/tg/reset', { nick: nick.value.trim() });
          sendBtn.disabled = false;
          if (!r) return;
          toast('Код отправлен в Telegram ' + r.sentTo, 'ok');
          nick.disabled = true;
          const code = h('input', { class: 'input', placeholder: 'Код из Telegram', inputmode: 'numeric', maxlength: 6, autocomplete: 'one-time-code' });
          const p1 = h('input', { class: 'input', type: 'password', placeholder: 'Новый пароль', autocomplete: 'new-password', maxlength: 64 });
          const p2 = h('input', { class: 'input', type: 'password', placeholder: 'Повтори пароль', autocomplete: 'new-password', maxlength: 64 });
          const ok = h('button', { class: 'btn block', type: 'button' }, 'Сменить пароль');
          ok.onclick = async () => {
            if (p1.value !== p2.value) return toast('Пароли не совпадают', 'err');
            ok.disabled = true;
            const rr = await api('/api/tg/reset2', { nick: nick.value.trim(), code: code.value, pass: p1.value });
            ok.disabled = false;
            if (rr) { toast('Пароль изменён', 'ok'); finish(rr); }
          };
          step.innerHTML = '';
          step.append(h('div', { class: 'hint', style: { marginTop: 0 } }, 'Код отправлен в Telegram ' + r.sentTo + '. Он действует 10 минут.'), code, p1, p2, ok);
          code.focus();
        };
        step.append(sendBtn);
        card.append(h('div', { class: 'auth-form' }, nick, step),
          h('button', { class: 'link-btn', onclick: () => { mode = 'login'; draw(); } }, '← Назад ко входу'));
        nick.focus();
        return;
      }

      const nick = h('input', { class: 'input', placeholder: 'Ник', autocomplete: 'username', maxlength: 16, autocapitalize: 'off', spellcheck: 'false' });
      const pass = h('input', { class: 'input', placeholder: 'Пароль', type: 'password', autocomplete: mode === 'login' ? 'current-password' : 'new-password', maxlength: 64 });
      const pass2 = mode === 'reg' ? h('input', { class: 'input', placeholder: 'Повтори пароль', type: 'password', autocomplete: 'new-password', maxlength: 64 }) : null;
      const btn = h('button', { class: 'btn block', type: 'submit' }, mode === 'login' ? 'Войти' : 'Создать аккаунт');
      const form = h('form', {
        onsubmit: async e => {
          e.preventDefault();
          if (pass2 && pass.value !== pass2.value) return toast('Пароли не совпадают', 'err');
          btn.disabled = true;
          const r = await api(mode === 'login' ? '/api/login' : '/api/register', { nick: nick.value.trim(), pass: pass.value });
          btn.disabled = false;
          if (r) finish(r);
        }
      }, nick, pass, pass2, btn);
      card.append(
        h('div', { class: 'seg' },
          h('button', { type: 'button', class: mode === 'login' ? 'on' : '', onclick: () => { mode = 'login'; draw(); } }, 'Вход'),
          h('button', { type: 'button', class: mode === 'reg' ? 'on' : '', onclick: () => { mode = 'reg'; draw(); } }, 'Регистрация')),
        h('h2', { class: 'auth-h' }, mode === 'login' ? 'Вход на сайт' : 'Регистрация'),
        form);
      if (mode === 'login') {
        card.append(h('button', { class: 'link-btn', onclick: () => { mode = 'reset'; draw(); } }, 'Забыл пароль?'));
        if (tgBot) {
          const wait = h('div');
          const tgBtn = h('button', { class: 'btn block tg-btn', type: 'button' }, h('span', { svg: PLANE }), 'Войти через Telegram');
          tgBtn.onclick = async () => {
            const r = await api('/api/tg/login', {});
            if (!r) return;
            openTg(r);
            tgBtn.classList.add('hidden');
            wait.innerHTML = '';
            wait.append(h('div', { class: 'tg-wait' },
              h('div', { class: 'spinner' }),
              h('div', null, 'Нажми «Старт» в боте ', h('b', null, '@' + r.bot), ' и вернись сюда'),
              h('a', { class: 'link-btn', href: r.url, target: '_blank', rel: 'noopener' }, 'Telegram не открылся? Нажми здесь'),
              h('button', { class: 'link-btn', onclick: () => draw() }, 'Отмена')));
            stopPoll();
            const started = Date.now();
            poll = setInterval(async () => {
              if (Date.now() - started > 10 * 60e3) { draw(); return; }
              try {
                const res = await fetch('/api/tg/check?code=' + encodeURIComponent(r.code));
                const j = await res.json();
                if (j.token) finish(j);
                else if (!j.ok) { toast(j.error || 'Ссылка устарела', 'err'); draw(); }
              } catch (e) { /* нет связи — пробуем ещё */ }
            }, 2000);
          };
          card.append(h('div', { class: 'or' }, h('span', null, 'или')), tgBtn, wait);
        }
      }
      card.append(h('div', { class: 'hint' }, mode === 'reg' ? 'Ник — от 3 до 16 символов: буквы, цифры, _ - . Пароль — от 6 символов.' : 'Нет аккаунта? Нажми «Регистрация».'));
      nick.focus();
    };
    draw();
  }

  function logout(expired) {
    if (S.token && !expired) api('/api/logout', {});
    S.token = null;
    store.set('etn_token', null);
    if (S.es) { S.es.close(); S.es = null; }
    S.st = null;
    closeModal();
    $('#accept').classList.add('hidden');
    if (expired) toast('Войди в аккаунт заново');
    showAuth();
  }

  function startApp() {
    $('#auth').classList.add('hidden');
    $('#boot').classList.add('hidden');
    $('#app').classList.remove('hidden');
    $('#brand').textContent = S.meta.brand;
    $('#emblem').innerHTML = emblem();
    S.matchMounted = null;
    requestAnimationFrame(applyLook);
    connect();
  }

  // ---------- общие элементы ----------
  const LVL_COLORS = ['#eeeeee', '#1ce400', '#1ce400', '#ffc800', '#ffc800', '#ffc800', '#ffc800', '#ff6309', '#ff6309', '#fe1f00'];
  function lvl(n, big) {
    n = Math.max(1, Math.min(10, n || 1));
    const c = LVL_COLORS[n - 1];
    const C = 2 * Math.PI * 15, arc = C * 0.82;
    const svg = '<svg viewBox="0 0 36 36" width="100%" height="100%">' +
      '<circle cx="18" cy="18" r="15" fill="#120407"/>' +
      '<circle cx="18" cy="18" r="15" fill="none" stroke="rgba(255,255,255,.13)" stroke-width="3" stroke-linecap="round" stroke-dasharray="' + arc.toFixed(1) + ' ' + C.toFixed(1) + '" transform="rotate(122.4 18 18)"/>' +
      '<circle cx="18" cy="18" r="15" fill="none" stroke="' + c + '" stroke-width="3" stroke-linecap="round" stroke-dasharray="' + (arc * n / 10).toFixed(1) + ' ' + C.toFixed(1) + '" transform="rotate(122.4 18 18)"/>' +
      '<text x="18" y="23.2" text-anchor="middle" font-size="' + (n === 10 ? 13 : 15) + '" font-weight="900" fill="' + c + '" font-family="Exo 2, sans-serif">' + n + '</text></svg>';
    const el = h('span', { class: 'lvl' + (big ? ' big' : ''), title: n + ' уровень', svg });
    el.style.setProperty('--c', c);
    return el;
  }
  let emblemSeq = 0;
  function emblem() {
    const id = 'eg' + (++emblemSeq);
    return '<svg viewBox="0 0 48 48" width="100%" height="100%"><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff5a5f"/><stop offset="1" stop-color="#b8101f"/></linearGradient></defs>' +
      '<path d="M24 2 43 13v22L24 46 5 35V13z" fill="url(#' + id + ')"/><path d="M24 7.5 38.5 16v16L24 40.5 9.5 32V16z" fill="#14050a"/>' +
      '<path d="M27 11 15.5 27.5h8L21 37.5 33 20.5h-8z" fill="url(#' + id + ')"/></svg>';
  }

  // фаза анимации: элементы пересоздаются при каждом обновлении, а анимация идёт без рывков
  const phase = el => { el.style.setProperty('--ph', -(Date.now() % 60000) + 'ms'); return el; };
  function ava(p, size) {
    const s = size || 36;
    const hue = ((p.id || 1) * 47) % 360;
    const fr = p.frame ? itemById(p.frame) : null;
    const face = h('i', { style: { background: 'linear-gradient(135deg, hsl(' + hue + ',70%,58%), hsl(' + ((hue + 40) % 360) + ',70%,42%))' } }, (p.nick || '?')[0]);
    if (p.av) {
      // своя картинка; если не загрузилась — остаётся буква
      const img = h('img', { src: p.av, alt: '', loading: 'lazy', decoding: 'async', draggable: 'false' });
      img.onerror = () => img.remove();
      face.append(img);
    }
    const el = h('span', { class: 'ava' + (fr ? ' framed a-' + (fr.anim || 'none') + (fr.fx ? ' fx-' + fr.fx : '') : '') }, face);
    el.style.setProperty('--s', s + 'px');
    if (fr) {
      el.style.setProperty('--fr', fr.style);
      if (fr.glow) el.style.setProperty('--glow', fr.glow);
      phase(el);
      if (fr.fx) el.append(h('s', { class: 'fxl' }), h('s', { class: 'fxl2' }));
      if (fr.fx === 'royal' && s >= 30) el.append(h('em', { class: 'fx-crown' }, '♛'));
      if (fr.orbit && s >= 34) el.append(h('b', { class: 'orb', style: { color: fr.glow || '#fff' } }, fr.orbit));
    }
    return el;
  }
  function nick(p, extraClass) {
    const c = p.color ? itemById(p.color) : null;
    const el = h('span', { class: 'nick ellipsis' + (extraClass ? ' ' + extraClass : '') + (c && c.grad ? ' grad' : '') }, p.nick);
    if (c) {
      if (c.grad) { el.style.setProperty('--nk', c.style); phase(el); } else el.style.color = c.style;
    }
    return el;
  }
  function bannerEl(id, cls) {
    const it = id ? itemById(id) : null;
    const el = h('div', { class: (cls || 'banner') + (it && it.anim ? ' b-' + it.anim : '') });
    if (it) el.style.background = it.style;
    return phase(el);
  }
  const winter = () => S.meta && S.meta.season === 'winter';
  function newYear() {
    const d = new Date();
    if (d.getMonth() === 0 && d.getDate() <= 14) return 'С Новым годом! 🎄';
    const ny = new Date(d.getFullYear() + 1, 0, 1);
    const days = Math.ceil((ny - d) / 86400000);
    return 'До Нового года ' + days + ' ' + plural(days, 'день', 'дня', 'дней');
  }
  const CROWN = '<svg viewBox="0 0 64 48" width="100%" height="100%"><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fde68a"/><stop offset=".55" stop-color="#f59e0b"/><stop offset="1" stop-color="#b45309"/></linearGradient></defs><path d="M6 40 2 10l16 13L32 2l14 21 16-13-4 30z" fill="url(#cg)" stroke="#92400e" stroke-width="2" stroke-linejoin="round"/><rect x="6" y="38" width="52" height="8" rx="3" fill="url(#cg)" stroke="#92400e" stroke-width="2"/><circle cx="32" cy="27" r="4" fill="#ef4444"/><circle cx="17" cy="31" r="3" fill="#38bdf8"/><circle cx="47" cy="31" r="3" fill="#22c55e"/></svg>';
  const MAP_GR = [
    'linear-gradient(135deg,#0ea5e9,#1e3a8a)', 'linear-gradient(135deg,#f472b6,#7c3aed)', 'linear-gradient(135deg,#f59e0b,#b45309)',
    'linear-gradient(135deg,#22c55e,#14532d)', 'linear-gradient(135deg,#06b6d4,#0f766e)', 'linear-gradient(135deg,#a855f7,#1e1b4b)',
    'linear-gradient(135deg,#ef4444,#7f1d1d)', 'linear-gradient(135deg,#64748b,#0f172a)'
  ];
  function mapBg(name) { let s = 0; for (const ch of String(name)) s = (s * 31 + ch.charCodeAt(0)) >>> 0; return MAP_GR[s % MAP_GR.length]; }
  function countdown(dl, fmt) { return h('span', { 'data-dl': dl, 'data-fmt': fmt || '' }, '…'); }
  setInterval(() => {
    const t = now();
    document.querySelectorAll('[data-dl]').forEach(el => {
      const left = Math.max(0, Math.ceil((Number(el.dataset.dl) - t) / 1000));
      el.textContent = el.dataset.fmt === 'mm' ? mmss(left) : String(left);
    });
  }, 250);

  async function copy(text) {
    try { await navigator.clipboard.writeText(text); toast('Скопировано', 'ok'); return; } catch (e) { /* запасной способ ниже */ }
    const ta = h('textarea', { style: { position: 'fixed', opacity: '0' } });
    ta.value = text;
    document.body.append(ta);
    ta.select();
    try { document.execCommand('copy'); toast('Скопировано', 'ok'); } catch (e) { toast('Не удалось скопировать', 'err'); }
    ta.remove();
  }

  // ---------- навигация ----------
  document.querySelectorAll('.nav button').forEach(b => b.addEventListener('click', () => go(b.dataset.page)));
  $('#ecPill').addEventListener('click', () => { S.invTab = 'shop'; go('inv'); });
  function go(page) {
    S.page = page;
    S.matchMounted = null;
    S.homeShown = false;
    window.scrollTo(0, 0);
    const pg = $('#page');
    pg.classList.remove('enter');
    void pg.offsetWidth;
    pg.classList.add('enter');
    clearTimeout(go.t);
    go.t = setTimeout(() => pg.classList.remove('enter'), 900);
    renderPage(true);
  }

  // ---------- обработка снимка ----------
  function onState() {
    const st = S.st;
    $('#ecVal').textContent = st.me.ec;
    levelUp(st.me);
    if (S.openU) { const u = S.openU; S.openU = null; setTimeout(() => openProfile(u), 300); }
    for (const n of st.notes) {
      if (S.shown.has(n.id)) continue;
      S.shown.add(n.id);
      toast(n.t);
    }
    renderAccept();
    if (S.modalKind === 'party') renderPartyBody();
    renderPage(false);
  }

  function renderPage(force) {
    if (!S.st) return;
    document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('on', b.dataset.page === S.page));
    const page = $('#page');
    if (S.page === 'play') {
      if (S.st.match) {
        if (S.matchMounted !== S.st.match.id || force) mountMatch(page);
        updateMatch();
      } else {
        S.matchMounted = null;
        renderLobbies(page);
      }
    } else if (force) {
      page.innerHTML = '';
      if (S.page === 'profile') renderProfilePage(page);
      if (S.page === 'top') renderTop(page);
      if (S.page === 'inv') renderInv(page);
      if (S.page === 'more') renderMore(page);
    } else if (S.page === 'inv') {
      const sig = S.st.me.ec + '|' + S.st.me.items.join() + '|' + JSON.stringify(S.st.me.equip);
      if (sig !== S.invSig) { page.innerHTML = ''; renderInv(page); }
    } else if (S.page === 'more') {
      updateMore();
    }
  }

  // ---------- ИГРАТЬ: главный экран ----------
  // числа плавно «досчитываются», когда меняются
  function cnt(key, value) {
    S.cnt = S.cnt || {};
    const el = h('b', { class: 'cnt-n' }, String(value));
    const from = S.cnt[key];
    S.cnt[key] = value;
    if (from === undefined || from === value || S.calm) return el;
    const t0 = performance.now(), dur = 700;
    el.textContent = from;
    el.classList.add('bump');
    const step = t => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      el.textContent = Math.round(from + (value - from) * e);
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
    return el;
  }

  function ago(ts) {
    const m = Math.max(0, Math.round((Date.now() - ts) / 60e3));
    if (m < 1) return 'только что';
    if (m < 60) return m + ' мин назад';
    if (m < 24 * 60) return Math.round(m / 60) + ' ч назад';
    return fmtDate(ts);
  }

  // «+50 EC» вылетает над кошельком
  function flyEc(n) {
    const pill = $('#ecPill');
    if (!pill) return;
    const r = pill.getBoundingClientRect();
    const el = h('div', { class: 'fly-ec', style: { left: (r.left + r.width / 2) + 'px', top: (r.bottom + 4) + 'px' } }, '+' + n + ' EC');
    document.body.append(el);
    pill.classList.remove('pop');
    void pill.offsetWidth;
    pill.classList.add('pop');
    setTimeout(() => el.remove(), 1400);
  }

  const stack = (list, s) => h('span', { class: 'stack' }, list.slice(0, 5).map(p => ava(p, s)));

  function heroCard() {
    const st = S.st, me = st.me;
    const LV = S.meta.levels;
    const nextAt = me.lvl < 10 ? LV[me.lvl] : null;
    const curAt = LV[me.lvl - 1];
    const pct = nextAt ? Math.max(3, Math.min(100, (me.elo - curAt) / (nextAt - curAt) * 100)) : 100;
    const p = { id: me.id, nick: me.nick, frame: me.equip.frame, color: me.equip.color, av: me.av };
    const form = (me.form || '').split('').filter(Boolean);
    return phase(h('div', { class: 'card hero' },
      phase(h('div', { class: 'hero-glow' })),
      h('div', { class: 'row', style: { position: 'relative' } },
        h('button', { class: 'hero-ava', onclick: () => go('profile') }, ava(p, 66)),
        h('div', { class: 'grow' },
          h('div', { class: 'hello' }, hello() + ','),
          nick(p, 'hero-nick')),
        lvl(me.lvl, true)),
      h('div', { class: 'hero-elo' }, h('b', null, me.elo), h('span', null, ' ELO'),
        h('em', null, nextAt ? 'до ' + (me.lvl + 1) + ' уровня — ' + (nextAt - me.elo) : 'максимальный уровень')),
      h('div', { class: 'prog hero-prog' }, phase(h('i', { style: { width: pct + '%' } }))),
      h('div', { class: 'hero-row' },
        h('div', { class: 'hero-form' },
          h('small', null, 'Форма'),
          form.length ? form.map(x => h('i', { class: x === 'W' ? 'w' : x === 'L' ? 'l' : 'x' }, x === 'X' ? '×' : x)) : h('em', null, 'нет игр')),
        me.streak >= 2 ? h('span', { class: 'hero-streak' }, '🔥 ' + me.streak + ' ' + plural(me.streak, 'победа', 'победы', 'побед') + ' подряд') : null,
        me.daily ? h('button', { class: 'hero-gift', onclick: async () => { const r = await api('/api/daily', {}); if (r) { flyEc(r.bonus); toast('+' + r.bonus + ' EC — ежедневный бонус', 'ok'); } } }, '🎁 +' + S.meta.rewards.daily + ' EC') : null)));
  }

  function hello() {
    const hr = new Date().getHours();
    return hr < 5 ? 'Доброй ночи' : hr < 12 ? 'Доброе утро' : hr < 18 ? 'Добрый день' : 'Добрый вечер';
  }

  function announceCard(a) {
    if (!a || Number(store.get('etn_ann', 0)) === a.id) return null;
    const el = h('div', { class: 'card announce' },
      h('div', { class: 'an-ico' }, '📣'),
      h('div', { class: 'grow' }, h('div', { class: 'an-t' }, 'Объявление'), h('div', { class: 'an-x' }, a.t)),
      h('button', { class: 'an-close', title: 'Скрыть', onclick: () => { store.set('etn_ann', String(a.id)); el.classList.add('gone'); setTimeout(() => el.remove(), 300); } }, '✕'));
    return el;
  }

  function statsStrip(home) {
    const st = S.st;
    const t = (cls, key, v, label) => h('div', { class: 'ss ' + cls }, h('i'), cnt(key, v), h('span', null, label));
    return h('div', { class: 'stats-strip' },
      t('on', 'on', st.online, 'онлайн'),
      t('q', 'q', st.queue, 'в поиске'),
      t('m', 'm', home.today, 'матчей сегодня'),
      t('p', 'p', home.players, 'игроков'));
  }

  function questsCard(me, home) {
    const qs = me.quests || [];
    const reset = new Date();
    reset.setUTCHours(24, 0, 0, 0);
    const hrs = Math.max(1, Math.round((reset - Date.now()) / 36e5));
    const doneN = qs.filter(q => q.got).length;
    const icon = q => q.id === 'map'
      ? (mapImg(home.mapDay) ? h('img', { class: 'qs-map', src: mapImg(home.mapDay), alt: '' }) : h('span', { class: 'qs-ic' }, '🗺'))
      : h('span', { class: 'qs-ic' }, q.id === 'win' ? '🏆' : '⚔');
    return h('div', { class: 'card quests' },
      h('div', { class: 'row', style: { marginBottom: '6px' } },
        h('div', { class: 'grow' }, h('div', { class: 'blk-h' }, '🎯 Задания дня'), h('div', { class: 'muted small' }, 'Новые через ' + hrs + ' ч · выполнено ' + doneN + ' из ' + qs.length)),
        h('span', { class: 'tag dark' }, 'Карта дня: ' + home.mapDay)),
      qs.map(q => {
        const ready = q.v >= q.n && !q.got;
        return h('div', { class: 'quest' + (q.got ? ' got' : '') + (ready ? ' ready' : '') },
          icon(q),
          h('div', { class: 'grow' },
            h('div', { class: 'qs-t' }, q.t),
            h('div', { class: 'qs-bar' }, h('i', { style: { width: (q.v / q.n * 100) + '%' } })),
            h('div', { class: 'qs-v' }, q.v + ' / ' + q.n)),
          q.got ? h('span', { class: 'qs-done' }, '✓')
            : ready ? h('button', { class: 'qs-claim', onclick: async () => { const r = await api('/api/quest', { id: q.id }); if (r) { flyEc(r.bonus); toast('+' + r.bonus + ' EC за задание', 'ok'); } } }, '+' + q.r + ' EC')
              : h('span', { class: 'qs-r' }, '+' + q.r + ' EC'));
      }));
  }

  function leadersCard(home) {
    if (!home.leaders.length) return null;
    const order = [1, 0, 2].filter(i => home.leaders[i]);
    return h('button', { class: 'card leaders', onclick: () => go('top') },
      h('div', { class: 'row' }, h('div', { class: 'grow blk-h' }, '👑 Лидеры'), h('span', { class: 'go-arrow' }, 'Весь топ →')),
      h('div', { class: 'ld-row' }, order.map(i => {
        const p = home.leaders[i];
        return h('div', { class: 'ld ld' + (i + 1) },
          h('div', { class: 'ld-ava' }, ava(p, i === 0 ? 62 : 50), h('b', { class: 'ld-n' }, i + 1)),
          nick(p, 'ld-nick'),
          h('span', { class: 'ld-e' }, p.elo + ' ELO'));
      })));
  }

  const STATE_RU = { veto: 'Вето', live: 'Идёт', dispute: 'Спор' };
  function liveCard(home) {
    const card = h('div', { class: 'card live-card' },
      h('div', { class: 'row', style: { marginBottom: '4px' } },
        h('div', { class: 'grow blk-h' }, h('span', { class: 'live-dot' }), 'Сейчас играют'),
        h('span', { class: 'tag ' + (home.live.length ? 'red' : 'dark') }, home.live.length)));
    if (!home.live.length) card.append(h('div', { class: 'pf-empty', style: { marginTop: '8px' } }, 'Сейчас никто не играет — найди матч первым!'));
    home.live.forEach(m => {
      const src = m.map && mapImg(m.map);
      card.append(h('button', { class: 'lv-row', onclick: () => openLiveMatch(m.id) },
        src ? h('img', { class: 'lv-map', src, alt: '' }) : h('span', { class: 'lv-map lv-veto' }, '✕'),
        h('div', { class: 'grow', style: { minWidth: 0 } },
          h('div', { class: 'lv-teams' }, stack(m.a, 26), h('b', { class: 'lv-vs' }, 'vs'), stack(m.b, 26)),
          h('div', { class: 'muted small' }, (S.meta.modes[m.mode] ? S.meta.modes[m.mode].title : m.mode) + ' · ' + (m.map || 'выбор карты') + ' · ' + ago(m.t))),
        h('span', { class: 'lv-st ' + m.state }, STATE_RU[m.state] || m.state)));
    });
    return card;
  }

  function feedCard(home) {
    if (!home.feed.length) return null;
    return h('div', { class: 'card feed-card' },
      h('div', { class: 'blk-h', style: { marginBottom: '4px' } }, '⚡ Последние матчи'),
      home.feed.map(m => {
        const src = m.map && mapImg(m.map);
        return h('button', { class: 'fd-row', onclick: () => openLiveMatch(m.id) },
          src ? h('img', { class: 'lv-map', src, alt: '' }) : h('span', { class: 'lv-map lv-veto' }, '?'),
          h('div', { class: 'grow', style: { minWidth: 0 } },
            h('div', { class: 'fd-w' }, stack(m.w, 24), h('span', { class: 'fd-win' }, 'победа')),
            h('div', { class: 'muted small' }, (m.map || '—') + ' · ' + ago(m.ts))),
          h('span', { class: 'fd-d' }, '±' + m.d));
      }));
  }

  async function openLiveMatch(id) {
    const M = await api('/api/match?id=' + id);
    if (!M) return;
    openModal('livematch', 'Матч #' + M.id, body => {
      const src = M.map && mapImg(M.map);
      body.append(
        M.map ? h('div', { class: 'map-hero', style: { marginBottom: '14px' } },
          h('div', { class: 'mh-bg', style: src ? { backgroundImage: 'url(' + src + ')' } : { background: mapBg(M.map) } }),
          src ? h('img', { class: 'mh-img', src, alt: '' }) : null,
          h('div', { class: 'mh-t' }, h('small', null, (S.meta.modes[M.mode] ? S.meta.modes[M.mode].title : M.mode) + ' · ' + (M.result ? 'завершён' : (STATE_RU[M.state] || M.state))), h('b', null, M.map))) : h('p', { class: 'muted' }, 'Капитаны ещё выбирают карту.'),
        h('div', { class: 'teams' }, M.teams.map((t, k) => h('div', { class: 'card team' + (M.result && M.result.winner === k ? ' won' : '') },
          h('div', { class: 'tn' }, h('span', null, 'Команда ' + 'AB'[k] + (M.result && M.result.winner === k ? ' 🏆' : '')), h('span', null, Math.round(t.reduce((s, p) => s + p.elo, 0) / t.length))),
          t.map(p => h('button', { class: 'tp', style: { width: '100%', textAlign: 'left' }, onclick: () => openProfile(p.id) },
            ava(p, 32), h('div', { class: 'grow' }, nick(p), h('div', { class: 'elo' }, p.elo + ' ELO')), lvl(p.lvl)))))));
    });
  }

  function renderLobbies(page) {
    const st = S.st;
    const home = st.home || { live: [], feed: [], leaders: [], today: 0, players: 0, mapDay: '' };
    const modes = Object.keys(S.meta.modes);
    if (!S.mode || !S.meta.modes[S.mode]) S.mode = modes[0];
    const y = window.scrollY;
    const first = !S.homeShown;
    S.homeShown = true;
    page.innerHTML = '';
    const colL = h('div', { class: 'col' });
    const colR = h('div', { class: 'col' });
    page.append(h('div', { class: 'cols' }, colL, colR));
    const an = announceCard(home.announce);
    if (an) colL.append(an);
    colL.append(heroCard());

    if (st.recent && st.recent.id > S.dismissed) colL.append(resultCard(st.recent));

    for (const inv of st.inv) {
      colL.append(h('div', { class: 'card invite-card' },
        h('div', { class: 'row' }, ava(inv.from, 44),
          h('div', { class: 'grow' }, h('div', null, nick(inv.from)), h('div', { class: 'muted small' }, 'зовёт тебя в пати'))),
        h('div', { class: 'btns' },
          h('button', { class: 'btn sm', onclick: () => api('/api/party/accept', { from: inv.from.id }) }, 'Принять'),
          h('button', { class: 'btn sm soft', onclick: () => api('/api/party/decline', { from: inv.from.id }) }, 'Отклонить'))));
    }

    // режим и быстрая игра
    const k = modes.indexOf(S.mode);
    const seg = h('div', { class: 'modeseg', style: { '--n': modes.length, '--k': k } }, h('i', { class: 'thumb' }));
    modes.forEach((m, i) => seg.append(h('button', {
      class: m === S.mode ? 'on' : '',
      onclick: () => {
        if (m === S.mode) return;
        seg.style.setProperty('--k', i);
        seg.querySelectorAll('button').forEach((b, j) => b.classList.toggle('on', j === i));
        S.mode = m;
        store.set('etn_mode', m);
        setTimeout(() => { if (S.page === 'play' && !S.st.match) renderLobbies(page); }, 260);
      }
    }, S.meta.modes[m].title)));
    if (st.me.cd > now()) {
      colL.append(h('div', { class: 'card ban-card' },
        h('div', { class: 'ban-ico' }, '⛔'),
        h('div', { class: 'grow' },
          h('div', { class: 'ban-t' }, 'Поиск недоступен ', countdown(st.me.cd, 'mm')),
          h('div', { class: 'small', style: { opacity: .85, fontWeight: 700 } }, 'Причина: ' + (st.me.banReason || 'штраф') + '. Чем чаще — тем дольше.'))));
    }
    colL.append(seg);

    const cdLeft = st.me.cd - now();
    const inLobby = st.lobby !== null;
    colL.append(phase(h('button', {
      class: 'quick' + (inLobby ? ' searching' : ''), onclick: async () => {
        if (inLobby) { api('/api/lobby/leave', {}); return; }
        const r = await api('/api/quick', { mode: S.mode });
        if (r) toast('Ты в лобби #' + r.lobby, 'ok');
      }
    },
    h('span', { class: 'q-shine' }),
    inLobby ? h('span', { class: 'q-radar' }, h('i'), h('i'), h('i')) : null,
    h('span', { class: 'q-ico', svg: inLobby ? '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>' : '<svg viewBox="0 0 24 24" width="26" height="26"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>' }),
    h('span', { class: 'q-t' }, inLobby ? 'Идёт поиск…' : 'Найти матч',
      h('small', null, inLobby
        ? 'Лобби #' + st.lobbies[st.lobby].num + ' · ' + st.lobbies[st.lobby].p.length + '/' + st.lobbies[st.lobby].size + ' · нажми, чтобы выйти'
        : cdLeft > 0 ? h('span', null, 'штраф ещё ', countdown(st.me.cd, 'mm')) : S.meta.modes[S.mode].title + ' · сам подберу лобби')))));

    // пати
    const party = st.party;
    colL.append(h('div', { class: 'card party-card' },
      h('div', { class: 'row' },
        h('div', { class: 'ico', svg: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.3-5.5 6.5-5.5s5.7 1.9 6.5 5.5"/><circle cx="16.5" cy="7" r="3"/><path d="M15.5 13.6c2.9.2 5 2 5.8 5.4"/></svg>' }),
        h('div', { class: 'grow' },
          h('div', { class: 't' }, party ? 'Твоя пати' : 'Собери пати'),
          party
            ? h('div', { class: 'party-faces' }, party.members.map(m => ava(m, 32)))
            : h('div', { class: 'd' }, 'До ' + S.meta.partyMax + ' игроков в одной команде')),
        h('button', { class: 'btn soft sm', onclick: openParty }, 'Пати'))));
    colL.append(statsStrip(home));

    // лобби
    colR.append(h('div', { class: 'section-t', style: { marginTop: '4px' } }, 'Лобби · ' + S.meta.modes[S.mode].title));
    const grid = h('div', { class: 'lobby-grid' });
    for (const L of st.lobbies) {
      if (L.mode !== S.mode && st.lobby !== L.i) continue;
      const mine = st.lobby === L.i;
      const filled = L.p.length > 0;
      const left = L.size - L.p.length;
      const btn = mine
        ? h('button', { class: 'btn ghost lobby-btn', onclick: () => api('/api/lobby/leave', {}) }, 'Выйти')
        : h('button', { class: 'btn soft lobby-btn', onclick: () => api('/api/lobby/join', { i: L.i }) }, 'Войти');
      if (L.state === 'accept' && !mine) btn.disabled = true;
      const fit = st.me.lvl >= L.min && st.me.lvl <= L.max;
      if (!fit && !mine) { btn.disabled = true; btn.textContent = 'Не твой ур.'; }
      grid.append(h('div', { class: 'card lobby' + (mine ? ' mine' : '') + (filled ? ' filled' : '') + (filled && left === 1 ? ' almost' : '') },
        h('div', { class: 'head' },
          h('div', { class: 'name' }, 'Лобби #' + L.num),
          h('div', { class: 'cnt' }, L.p.length, h('small', null, '/' + L.size)),
          btn),
        h('div', { class: 'lobby-sub' },
          h('span', { class: 'lvl-tag' + (L.min === 1 && L.max === 10 ? ' all' : '') }, L.min === 1 && L.max === 10 ? 'Все уровни' : 'Уровень ' + L.min + '–' + L.max),
          L.mode !== S.mode ? h('span', { class: 'mode-tag' }, S.meta.modes[L.mode].title) : null),
        filled
          ? h('div', { class: 'players' }, L.p.map(p => h('button', { class: 'pchip', onclick: () => openProfile(p.id) }, ava(p, 30), nick(p), lvl(p.lvl))))
          : h('div', { class: 'empty' }, 'Пока никого — будь первым'),
        filled && left === 1 && L.state === 'wait' ? h('div', { class: 'almost-tag' }, 'Не хватает одного игрока!') : null,
        L.state === 'accept' ? h('div', { class: 'center muted small', style: { marginTop: '12px', fontWeight: 800 } }, 'Игроки принимают матч… ', countdown(L.dl), ' с') : null,
        phase(h('div', { class: 'segs' }, Array.from({ length: L.size }, (_, j) => h('i', { class: j < L.p.length ? 'on' : '' }))))));
    }
    colR.append(grid);
    colR.append(questsCard(st.me, home));
    colR.append(liveCard(home));
    const fd = feedCard(home);
    if (fd) colR.append(fd);
    const ld = leadersCard(home);
    if (ld) colR.append(ld);
    if (winter()) colR.append(winterStrip());
    if (first && !S.calm && Element.prototype.animate) {
      page.querySelectorAll('.col > *').forEach((el, i) => el.animate(
        [{ opacity: 0, transform: 'translateY(16px) scale(.98)' }, { opacity: 1, transform: 'none' }],
        { duration: 420, delay: Math.min(i * 55, 600), easing: 'cubic-bezier(.2,.9,.3,1.2)', fill: 'backwards' }));
    }
    window.scrollTo(0, y);
  }

  function winterStrip() {
    return h('button', { class: 'card winter-strip', onclick: () => { S.invTab = 'shop'; go('inv'); } },
      h('span', { class: 'ws-flake' }, '❄'),
      h('div', { class: 'grow', style: { textAlign: 'left' } },
        h('div', { class: 'ws-t' }, 'Зимний сезон'),
        h('div', { class: 'ws-d' }, newYear() + ' · новые рамки и баннеры')),
      h('span', { class: 'ws-go' }, '→'));
  }

  function resultCard(M) {
    const me = S.st.me.id;
    let cls = '', big = 'Матч отменён', sub = 'ELO не изменилось';
    if (M.state === 'done' && M.result) {
      const myTeam = M.teams[0].some(p => p.id === me) ? 0 : 1;
      const win = M.result.winner === myTeam;
      const d = M.result.deltas[me] || 0;
      cls = win ? 'win' : 'lose';
      big = win ? 'Победа' : 'Поражение';
      sub = null;
      return h('div', { class: 'card result ' + cls },
        h('div', { class: 'muted small' }, ['Матч #' + M.id, M.map, S.meta.modes[M.mode].title].filter(Boolean).join(' · ')),
        h('div', { class: 'big' }, big),
        h('div', { class: 'deltas' },
          h('div', null, (d >= 0 ? '+' : '') + d + ' ELO'),
          h('div', null, '+' + (win ? S.meta.rewards.win : S.meta.rewards.loss) + ' EC')),
        h('button', { class: 'btn block', onclick: dismissResult }, 'Продолжить'));
    }
    return h('div', { class: 'card result' },
      h('div', { class: 'muted small' }, 'Матч #' + M.id),
      h('div', { class: 'big' }, big),
      h('p', { class: 'muted' }, sub),
      h('button', { class: 'btn block', onclick: dismissResult }, 'Продолжить'));
    function dismissResult() { S.dismissed = M.id; store.set('etn_dismiss', String(M.id)); renderPage(true); }
  }

  // ---------- карты и эффекты матча ----------
  const mapImg = name => (S.meta.mapImages || {})[name] || null;
  function mapTile(name, extra, attrs) {
    const img = mapImg(name);
    const el = h('button', Object.assign({ class: 'mtile' + (extra ? ' ' + extra : '') }, attrs || {}),
      img ? h('img', { src: img, alt: name, draggable: 'false' }) : h('div', { class: 'mtile-fb', style: { background: mapBg(name) } }, name),
      h('span', { class: 'mtile-n' }, name));
    return el;
  }

  // полноэкранная анимация «Матч найден»
  function renderAccept() {
    const st = S.st;
    const box = $('#accept');
    const L = st.lobby !== null ? st.lobbies[st.lobby] : null;
    if (!L || L.state !== 'accept') {
      if (!box.classList.contains('hidden')) {
        box.classList.add('closing');
        setTimeout(() => { box.classList.add('hidden'); box.classList.remove('closing'); box.innerHTML = ''; }, 350);
      }
      S.acceptKey = null;
      return;
    }
    const iAccepted = L.acc.includes(st.me.id);
    if (S.acceptKey !== L.dl) {
      S.acceptKey = L.dl;
      try { if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 300]); } catch (e) { /* нет вибрации */ }
      Sound.found();
      Sound.flash(L.dl);
      const total = S.meta.acceptSeconds * 1000;
      const elapsed = Math.max(0, total - (L.dl - now()));
      box.innerHTML = '';
      box.className = 'found';
      box.append(
        h('div', { class: 'f-bg' }, h('i'), h('i'), h('i')),
        h('div', { class: 'f-in' },
          h('div', { class: 'f-sub' }, 'Лобби #' + L.num + ' · ' + S.meta.modes[L.mode].title),
          h('div', { class: 'f-title', 'data-t': 'МАТЧ НАЙДЕН' }, 'МАТЧ НАЙДЕН'),
          h('div', { class: 'f-ring' },
            h('span', { svg: '<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="52" class="f-track"/><circle cx="60" cy="60" r="52" class="f-prog" style="animation-duration:' + total + 'ms;animation-delay:-' + elapsed + 'ms"/></svg>' }),
            h('b', null, countdown(L.dl))),
          h('div', { class: 'f-faces', id: 'fFaces' }),
          h('div', { id: 'fBtn' }),
          h('button', { class: 'f-decline', onclick: () => confirmAsk('Отказаться от матча? За это будет штраф — поиск станет недоступен на время.', () => api('/api/lobby/leave', {})) }, 'Отказаться')));
    }
    // лица и кнопку не пересоздаём на каждое обновление — иначе анимация прилёта повторяется
    const faces = $('#fFaces');
    const fKey = L.p.map(p => p.id).join(',');
    if (faces.dataset.k !== fKey) {
      faces.dataset.k = fKey;
      faces.innerHTML = '';
      L.p.forEach((p, k) => {
        const a = ava(p, L.p.length > 4 ? 48 : 56);
        a.dataset.id = p.id;
        faces.append(h('div', { class: 'f-face', style: { animationDelay: (0.25 + k * 0.07) + 's' } }, a));
      });
      faces.append(h('div', { class: 'f-count' }));
    }
    faces.querySelectorAll('.ava[data-id]').forEach(a => {
      const ok = L.acc.includes(Number(a.dataset.id)) || L.acc.includes(a.dataset.id);
      a.classList.toggle('ok', ok);
      a.classList.toggle('wait', !ok);
    });
    faces.querySelector('.f-count').textContent = 'Приняли ' + L.acc.length + ' из ' + L.size;
    const fb = $('#fBtn');
    if (fb.dataset.k !== String(iAccepted)) {
      fb.dataset.k = String(iAccepted);
      fb.innerHTML = '';
      fb.append(iAccepted
        ? h('button', { class: 'f-accept done', disabled: true }, '✓ Принято — ждём остальных')
        : h('button', { class: 'f-accept', onclick: () => api('/api/accept', {}) }, 'ПРИНЯТЬ'));
    }
  }

  // новый уровень — праздничный экран (один раз на каждый уровень)
  function levelUp(me) {
    const key = 'etn_lvl_' + me.id;
    const was = Number(store.get(key, 0));
    store.set(key, String(me.lvl));
    if (!was || me.lvl <= was || S.calm) return;
    const el = h('div', { class: 'reveal lvlup', onclick: () => close() },
      h('div', { class: 'rv-rays' }),
      h('div', { class: 'rv-label' }, 'НОВЫЙ УРОВЕНЬ'),
      h('div', { class: 'lu-gauge' }, lvl(me.lvl, true)),
      h('div', { class: 'rv-name' }, 'Уровень ' + me.lvl),
      h('div', { class: 'lu-sub' }, me.elo + ' ELO · так держать!'));
    const close = () => { el.classList.add('out'); setTimeout(() => el.remove(), 450); };
    document.body.append(el);
    try { Sound.found(); } catch (e) { /* без звука */ }
    setTimeout(close, 3600);
  }

  // экран «VS» при старте матча — один раз на матч
  function vsIntro(M) {
    let seen = 0;
    try { seen = Number(localStorage.getItem('etn_vs') || 0); } catch (e) { /* без хранилища */ }
    if (seen >= M.id || S.calm) return;
    try { localStorage.setItem('etn_vs', String(M.id)); } catch (e) { /* без хранилища */ }
    const side = (t, k) => h('div', { class: 'vs-side vs-' + (k ? 'r' : 'l') },
      h('div', { class: 'vs-team' }, 'Команда ' + 'AB'[k]),
      t.map((p, j) => h('div', { class: 'vs-p', style: { animationDelay: (0.15 + j * 0.09) + 's' } }, ava(p, 54), h('div', { class: 'vs-pn' }, nick(p), h('small', null, p.elo + ' ELO')))));
    const el = h('div', { class: 'vs' },
      h('div', { class: 'vs-top' }, 'МАТЧ #' + M.id + ' · ' + S.meta.modes[M.mode].title),
      h('div', { class: 'vs-body' }, side(M.teams[0], 0), h('div', { class: 'vs-mid' }, 'VS'), side(M.teams[1], 1)),
      h('div', { class: 'vs-hint' }, 'Капитаны выбирают карту…'));
    el.addEventListener('click', () => close());
    document.body.append(el);
    const close = () => { el.classList.add('out'); setTimeout(() => el.remove(), 450); };
    setTimeout(close, 3200);
  }

  // показ выбранной карты после вето
  function mapReveal(M) {
    const key = M.id + ':' + M.map;
    if (S.revealed === key || S.calm) return;
    S.revealed = key;
    let seen = '';
    try { seen = localStorage.getItem('etn_reveal') || ''; localStorage.setItem('etn_reveal', key); } catch (e) { /* без хранилища */ }
    if (seen === key) return;
    const img = mapImg(M.map);
    const el = h('div', { class: 'reveal' },
      h('div', { class: 'rv-rays' }),
      h('div', { class: 'rv-label' }, 'ИГРАЕМ НА КАРТЕ'),
      img ? h('img', { class: 'rv-img', src: img, alt: M.map }) : h('div', { class: 'rv-img rv-fb', style: { background: mapBg(M.map) } }),
      h('div', { class: 'rv-name' }, M.map));
    el.addEventListener('click', () => close());
    document.body.append(el);
    try { if (navigator.vibrate) navigator.vibrate(120); } catch (e) { /* нет вибрации */ }
    const close = () => { el.classList.add('out'); setTimeout(() => el.remove(), 450); };
    setTimeout(close, 2600);
  }

  // ---------- комната матча ----------
  const STATUS = { veto: 'Вето карт', live: 'Идёт игра', dispute: 'Спор', done: 'Завершён', cancelled: 'Отменён' };
  function mountMatch(page) {
    const M = S.st.match;
    S.matchMounted = M.id;
    S.chatLen = -1;
    S.tSig = S.sSig = S.cSig = null;
    page.innerHTML = '';
    const chatList = h('div', { class: 'chat', id: 'mChat' });
    const chatInput = h('input', { class: 'input', placeholder: 'Сообщение команде…', maxlength: 200, id: 'mChatIn' });
    const sendChat = async () => {
      const text = chatInput.value.trim();
      if (!text) return;
      chatInput.value = '';
      await api('/api/match/chat', { text });
    };
    chatInput.addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });
    page.append(
      h('div', { class: 'card' },
        h('div', { class: 'm-head' },
          h('div', null, h('div', { class: 'm-title' }, 'Матч #' + M.id), h('div', { class: 'muted small', style: { marginTop: '6px', fontWeight: 800 } }, S.meta.modes[M.mode].title + ' · лобби #' + M.lobby)),
          h('div', { id: 'mStatus', class: 'm-status' }))),
      h('div', { id: 'mStage' }),
      h('div', { id: 'mTeams', class: 'teams' }),
      h('div', { class: 'card' },
        h('div', { class: 'section-t', style: { margin: '0 0 8px' } }, 'Чат матча'),
        chatList,
        h('div', { class: 'chat-in' }, chatInput,
          h('button', { class: 'btn', onclick: sendChat, svg: '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M3 11.5 21 3l-8.5 18-2-7.5z" fill="#fff"/></svg>' }))),
      h('div', { id: 'mCancel' }));
  }

  function updateMatch() {
    const M = S.st.match;
    const me = S.st.me.id;
    vsIntro(M);
    if (M.state !== 'veto' && M.map && M.bans.length) mapReveal(M);
    const myTeam = M.teams[0].some(p => p.id === me) ? 0 : 1;
    const isCap = M.caps[myTeam] === me;
    const st = $('#mStatus');
    st.textContent = STATUS[M.state] || M.state;
    st.className = 'm-status ' + M.state;

    // команды
    const tSig = JSON.stringify(M.teams) + myTeam;
    const teams = $('#mTeams');
    if (tSig !== S.tSig) { S.tSig = tSig; teams.innerHTML = ''; }
    else teams.dataset.keep = '1';
    if (!teams.dataset.keep) M.teams.forEach((t, k) => {
      const avg = Math.round(t.reduce((s, p) => s + p.elo, 0) / t.length);
      teams.append(h('div', { class: 'card team' + (k === myTeam ? ' me' : '') },
        h('div', { class: 'tn' }, h('span', null, 'Команда ' + 'AB'[k]), h('span', null, avg)),
        t.map(p => h('button', { class: 'tp', style: { width: '100%', textAlign: 'left' }, onclick: () => openProfile(p.id) },
          ava(p, 34),
          h('div', { class: 'grow' },
            h('div', { class: 'row', style: { gap: '4px' } }, nick(p), M.caps[k] === p.id ? h('span', { class: 'crown', title: 'капитан' }, '♛') : null),
            h('div', { class: 'elo' }, p.elo + ' ELO', M.host === p.id ? ' · хост' : ''),
            p.rid ? h('span', { class: 'rid-tag', onclick: e => { e.stopPropagation(); copy(p.rid); } }, '🎮 ' + p.rid) : null),
          lvl(p.lvl)))));
    });

    delete teams.dataset.keep;

    // этап (перерисовывается только когда он меняется — чтобы не сбивать ввод кода)
    const stage = $('#mStage');
    const sSig = JSON.stringify([M.state, M.bans, M.turn, M.room, M.reports, M.map, M.autoAt, M.dl, isCap]);
    const prevRoom = $('#mRoomIn') ? $('#mRoomIn').value : '';
    if (sSig !== S.sSig) { S.sSig = sSig; stage.innerHTML = ''; renderStage(); }
    function renderStage() {
    if (M.state === 'veto') {
      const myTurn = isCap && M.turn === myTeam;
      const capOf = k => M.teams[k].find(p => p.id === M.caps[k]) || { nick: '?', id: 0 };
      const left = M.pool.length - M.bans.length;
      const total = (S.meta.vetoSeconds || 20) * 1000;
      const elapsed = Math.max(0, Math.min(total, total - (M.dl - now())));
      const side = k => h('div', { class: 'vt-side vt-' + 'ab'[k] + (M.turn === k ? ' turn' : ' idle') + (k === myTeam ? ' mine' : '') },
        h('div', { class: 'vt-ava' }, ava(capOf(k), 56), h('span', { class: 'vt-crown' }, '♛')),
        nick(capOf(k), 'vt-nick'),
        h('div', { class: 'vt-team' }, 'Команда ' + 'AB'[k] + (k === myTeam ? ' · вы' : '')),
        M.turn === k ? h('div', { class: 'vt-now' }, 'банит', h('span', { class: 'dots' }, h('i'), h('i'), h('i'))) : h('div', { class: 'vt-now off' }, 'ждёт'));
      const grid = h('div', { class: 'mgrid vt-grid' });
      M.pool.forEach(name => {
        const b = M.bans.find(x => x.map === name);
        const fresh = b && !(S.prevBans || []).includes(name);
        const t = mapTile(name, (b ? 'banned' : '') + (fresh ? ' just' : '') + (myTurn && !b ? ' can' : '') + (!b && left <= 2 ? ' final' : ''), {
          disabled: !myTurn || !!b,
          onclick: e => {
            const el = e.currentTarget;
            if (el.classList.contains('sel')) { el.classList.add('going'); api('/api/match/veto', { map: name }); return; }
            grid.querySelectorAll('.sel').forEach(x => x.classList.remove('sel'));
            el.classList.add('sel');
          }
        });
        if (b) t.append(h('span', { class: 'mtile-ban' }, 'БАН ' + 'AB'[b.t]));
        else if (myTurn) t.append(h('span', { class: 'mtile-sel' }, '✕ Убрать?'));
        grid.append(t);
      });
      stage.append(h('div', { class: 'card veto' + (myTurn ? ' my-turn' : '') },
        h('div', { class: 'vt-title' }, 'ВЫБОР КАРТЫ'),
        h('div', { class: 'vt-head' }, side(0),
          h('div', { class: 'vt-mid' },
            h('div', { class: 'vt-ring', svg: '<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" class="vt-tr"/><circle cx="32" cy="32" r="28" class="vt-pr" style="animation-duration:' + total + 'ms;animation-delay:-' + elapsed + 'ms"/></svg>' },
              h('b', null, countdown(M.dl)), h('small', null, 'сек')),
            h('div', { class: 'vt-arrow ' + (M.turn === 0 ? 'l' : 'r') }, h('i'), h('i'), h('i'))),
          side(1)),
        h('div', { class: 'vt-hint' + (myTurn ? ' me' : '') }, myTurn ? '🔥 Твой ход! Нажми на карту, потом ещё раз — чтобы убрать' : 'Капитан ' + capOf(M.turn).nick + ' выбирает карту для бана…'),
        h('div', { class: 'vt-steps' }, Array.from({ length: M.pool.length - 1 }, (_, i) => h('i', { class: i < M.bans.length ? 'on ' + 'ab'[M.bans[i].t] : i === M.bans.length ? 'cur' : '' }))),
        left === 2 ? h('div', { class: 'vt-decider' }, '⚔ Решающий бан — останется одна карта') : null,
        grid,
        M.bans.length ? h('div', { class: 'vt-log' }, M.bans.map((b, i) => h('span', { class: 'vt-chip ' + 'ab'[b.t] + (i === M.bans.length - 1 ? ' last' : '') }, h('b', null, 'AB'[b.t]), ' ✕ ' + b.map))) : null));
      S.prevBans = M.bans.map(x => x.map);
    } else if (M.state === 'live' || M.state === 'dispute') {
      const canRoom = M.host === me || isCap;
      const roomBlock = [];
      if (M.room) {
        roomBlock.push(h('div', { class: 'code-box' }, h('div', { class: 'grow' }, h('div', { class: 'small', style: { opacity: .7, fontWeight: 800 } }, 'КОД КОМНАТЫ'), h('b', null, M.room)),
          h('button', { class: 'btn sm', onclick: () => copy(M.room) }, 'Копировать')));
      } else {
        roomBlock.push(h('p', { class: 'muted', style: { margin: '12px 0 0', fontWeight: 700 } },
          canRoom ? 'Создай комнату в игре и отправь код сюда.' : 'Ждём, пока ' + (M.teams.flat().find(p => p.id === M.host) || {}).nick + ' создаст комнату и напишет код.'));
      }
      if (canRoom && M.state === 'live') {
        const inp = h('input', { class: 'input', placeholder: M.room ? 'Новый код комнаты' : 'Код комнаты', maxlength: 40, id: 'mRoomIn' });
        inp.value = prevRoom;
        roomBlock.push(h('div', { class: 'chat-in', style: { marginTop: '12px' } }, inp,
          h('button', { class: 'btn', style: { width: 'auto', padding: '0 18px' }, onclick: () => { if (inp.value.trim()) api('/api/match/room', { code: inp.value.trim() }).then(r => { if (r) inp.value = ''; }); } }, 'OK')));
      }
      stage.append(h('div', { class: 'card' },
        h('div', { class: 'map-hero' },
          mapImg(M.map) ? h('div', { class: 'mh-bg', style: { backgroundImage: 'url(' + mapImg(M.map) + ')' } }) : h('div', { class: 'mh-bg', style: { background: mapBg(M.map) } }),
          mapImg(M.map) ? h('img', { class: 'mh-img', src: mapImg(M.map), alt: M.map }) : null,
          h('div', { class: 'mh-t' }, h('small', null, 'КАРТА'), h('b', null, M.map))),
        roomBlock));

      // результат
      const rep = M.reports;
      const repLine = k => {
        const capNick = (M.teams[k].find(p => p.id === M.caps[k]) || {}).nick;
        if (rep[k] === null) return h('div', { class: 'row small', style: { marginTop: '6px' } }, h('span', { class: 'tag' }, 'Капитан ' + 'AB'[k]), h('span', { class: 'muted' }, capNick + ' — ещё не отметил'));
        return h('div', { class: 'row small', style: { marginTop: '6px' } }, h('span', { class: 'tag green' }, 'Капитан ' + 'AB'[k]), h('span', null, capNick + ': победила ', h('b', null, 'команда ' + 'AB'[rep[k]])));
      };
      const resCard = h('div', { class: 'card' }, h('div', { class: 'section-t', style: { margin: '0 0 6px' } }, 'Результат'), repLine(0), repLine(1));
      if (M.state === 'dispute') {
        resCard.append(h('p', { style: { fontWeight: 800, color: '#fb923c' } }, 'Капитаны отметили разное — ждём решения администратора. Пришлите доказательства (скрин) админу.'));
      } else {
        if (M.autoAt) resCard.append(h('p', { class: 'muted small', style: { fontWeight: 700 } }, 'Если второй капитан не ответит — результат засчитается через ', countdown(M.autoAt, 'mm')));
        if (isCap) {
          resCard.append(h('div', { class: 'btns' },
            h('button', { class: 'btn green grow', onclick: () => confirmAsk('Твоя команда выиграла?', () => api('/api/match/report', { win: true })) }, 'Мы выиграли'),
            h('button', { class: 'btn red grow', onclick: () => confirmAsk('Твоя команда проиграла?', () => api('/api/match/report', { win: false })) }, 'Мы проиграли')));
        } else {
          resCard.append(h('p', { class: 'muted small', style: { fontWeight: 700 } }, 'Результат отмечают капитаны (♛). Если они согласны — ELO и EC начисляются сразу.'));
        }
      }
      stage.append(resCard);
    }
    }

    // чат
    const chat = $('#mChat');
    if (S.chatLen !== M.chat.length || chat.childElementCount !== M.chat.length) {
      const atBottom = chat.scrollHeight - chat.scrollTop - chat.clientHeight < 40;
      chat.innerHTML = '';
      for (const c of M.chat) {
        if (c.s) chat.append(h('div', { class: 'msg sys' }, c.x));
        else chat.append(h('div', { class: 'msg' + (c.u === me ? ' me' : '') }, h('b', null, c.n), c.x));
      }
      if (atBottom || S.chatLen === -1) chat.scrollTop = chat.scrollHeight;
      S.chatLen = M.chat.length;
    }

    // отмена и ливеры
    const cancel = $('#mCancel');
    const cSig = M.state + JSON.stringify(M.cancel) + JSON.stringify(M.leavers || {});
    if (cSig === S.cSig) return;
    S.cSig = cSig;
    cancel.innerHTML = '';
    if (M.state === 'veto' || M.state === 'live') {
      const voted = M.cancel.includes(me);
      const others = M.teams.flat().filter(p => p.id !== me);
      cancel.append(h('div', { class: 'card' },
        h('div', { class: 'section-t', style: { margin: '0 0 4px' } }, 'Кто-то не зашёл или вышел?'),
        h('p', { class: 'muted small', style: { margin: '0 0 10px', fontWeight: 700 } },
          'Отметь его. Если согласятся ' + M.leaverNeed + ' игрока — матч отменится, ливер получит −ELO и бан, остальным ELO не меняется.'),
        h('div', { class: 'leaver-row' }, others.map(p => {
          const votes = (M.leavers || {})[p.id] || [];
          const mine2 = votes.includes(me);
          return h('button', { class: 'leaver-chip' + (mine2 ? ' on' : '') + (votes.length ? ' hot' : ''), onclick: () => (mine2 ? api('/api/match/leaver', { id: p.id }) : confirmAsk(p.nick + ' покинул матч или не зашёл?', () => api('/api/match/leaver', { id: p.id }))) },
            ava(p, 26), h('span', { class: 'ellipsis' }, p.nick), votes.length ? h('b', null, votes.length + '/' + M.leaverNeed) : null);
        })),
        h('button', { class: 'btn block ghost', style: { marginTop: '12px' }, onclick: () => api('/api/match/cancel', {}) },
          voted ? 'Убрать голос за отмену' : 'Голосовать за отмену', ' (' + M.cancel.length + '/' + M.need + ')')));
    }
  }

  function confirmAsk(text, fn) {
    openModal('confirm', 'Точно?', body => {
      body.append(h('p', { style: { fontSize: '18px', fontWeight: 700 } }, text),
        h('div', { class: 'btns' },
          h('button', { class: 'btn grow', onclick: () => { closeModal(); fn(); } }, 'Да'),
          h('button', { class: 'btn soft grow', onclick: closeModal }, 'Нет')));
    });
  }

  // ---------- модальные окна ----------
  function openModal(kind, title, fill) {
    const box = $('#modal');
    S.modalKind = kind;
    box.innerHTML = '';
    const body = h('div', { id: 'modalBody' });
    const sheet = h('div', { class: 'sheet' },
      h('div', { class: 'sheet-h' }, h('b', null, title), h('button', { class: 'x', onclick: closeModal }, '×')),
      body);
    box.append(sheet);
    box.classList.remove('hidden');
    box.onclick = e => { if (e.target === box) closeModal(); };
    fill(body);
  }
  function closeModal() { $('#modal').classList.add('hidden'); $('#modal').innerHTML = ''; S.modalKind = null; }

  function openParty() {
    openModal('party', 'Пати', body => {
      body.append(h('div', { id: 'partyList' }));
      const inp = h('input', { class: 'input', placeholder: 'Ник друга', maxlength: 16, autocapitalize: 'off' });
      const send = async () => {
        if (!inp.value.trim()) return;
        const r = await api('/api/party/invite', { nick: inp.value.trim() });
        if (r) { toast('Приглашение отправлено', 'ok'); inp.value = ''; }
      };
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
      body.append(h('div', { class: 'section-t' }, 'Позвать игрока'),
        h('div', { class: 'chat-in' }, inp, h('button', { class: 'btn', style: { width: 'auto', padding: '0 18px' }, onclick: send }, 'Позвать')),
        h('p', { class: 'muted small' }, 'В пати до ' + S.meta.partyMax + ' игроков. В лобби заходит лидер — пати попадает туда целиком и играет в одной команде.'),
        h('div', { id: 'partyLeave' }));
      renderPartyBody();
    });
  }
  function renderPartyBody() {
    const list = $('#partyList');
    if (!list) return;
    const p = S.st.party;
    const me = S.st.me.id;
    list.innerHTML = '';
    if (!p) {
      list.append(h('p', { class: 'muted', style: { fontWeight: 700 } }, 'Ты пока один. Позови друга по нику — когда он примет приглашение, вы будете в одной пати.'));
    } else {
      for (const m of p.members) {
        list.append(h('div', { class: 'row', style: { padding: '10px 0' } },
          ava(m, 42),
          h('div', { class: 'grow' }, h('div', { class: 'row', style: { gap: '6px' } }, nick(m), p.leader === m.id ? h('span', { class: 'crown' }, '♛') : null),
            h('div', { class: 'muted small' }, h('span', { class: 'online-dot' + (m.on ? ' on' : '') }), m.on ? ' в сети' : ' не в сети', ' · ', m.elo, ' ELO')),
          lvl(m.lvl),
          p.leader === me && m.id !== me ? h('button', { class: 'btn xs soft', onclick: () => api('/api/party/kick', { id: m.id }) }, 'Убрать') : null));
      }
    }
    const leave = $('#partyLeave');
    leave.innerHTML = '';
    if (p) leave.append(h('button', { class: 'btn block ghost', style: { marginTop: '12px' }, onclick: () => api('/api/party/leave', {}) }, 'Выйти из пати'));
  }

  async function openProfile(id) {
    const p = await api('/api/profile?id=' + id);
    if (!p) return;
    openModal('profile', 'Профиль', body => {
      body.append(profileCard(p, id !== S.st.me.id));
    });
  }

  // ---------- ПРОФИЛЬ ----------
  const lvlOfElo = e => Math.max(1, S.meta.levels.filter(x => e >= x).length);
  const ACH = [
    { ic: '🩸', t: 'Первая кровь', d: 'Выиграй первый матч', v: p => p.wins, n: 1 },
    { ic: '🎮', t: 'В деле', d: 'Сыграй 10 матчей', v: p => p.matches, n: 10 },
    { ic: '🎖', t: 'Ветеран', d: 'Сыграй 100 матчей', v: p => p.matches, n: 100 },
    { ic: '🏆', t: 'Победитель', d: 'Выиграй 25 матчей', v: p => p.wins, n: 25 },
    { ic: '🔥', t: 'В ударе', d: 'Серия из 3 побед', v: p => p.bestStreak, n: 3 },
    { ic: '⚡', t: 'Неудержимый', d: 'Серия из 7 побед', v: p => p.bestStreak, n: 7 },
    { ic: '⭐', t: 'Опытный', d: 'Дойди до 5 уровня', v: p => lvlOfElo(p.best || p.elo), n: 5 },
    { ic: '💎', t: 'Элита', d: 'Дойди до 10 уровня', v: p => lvlOfElo(p.best || p.elo), n: 10 },
    { ic: '👑', t: 'Пьедестал', d: 'Попади в топ-3', v: p => (p.matches && p.rank && p.rank <= 3 ? 1 : 0), n: 1 },
    { ic: '🛡', t: 'Честный игрок', d: '30 матчей без ливов', v: p => (p.leaves ? 0 : p.matches), n: 30 },
    { ic: '🗺', t: 'Картограф', d: 'Победы на 5 разных картах', v: p => Object.values(p.maps || {}).filter(r => r[0] > 0).length, n: 5 },
    { ic: '🧰', t: 'Коллекционер', d: 'Собери 5 предметов', v: p => p.items, n: 5 },
    { ic: '📸', t: 'Своё лицо', d: 'Поставь свой аватар', v: p => (p.av ? 1 : 0), n: 1 },
    { ic: '✈', t: 'На связи', d: 'Привяжи Telegram', v: p => (p.tg ? 1 : 0), n: 1 },
    { ic: '📅', t: 'Старожил', d: '30 дней в ' + 'ETN', v: p => Math.floor((Date.now() - p.created) / 864e5), n: 30 }
  ];

  function seenText(ts) {
    if (!ts) return 'не в сети';
    const m = Math.round((Date.now() - ts) / 60e3);
    if (m < 2) return 'был(а) только что';
    if (m < 60) return 'был(а) ' + m + ' мин назад';
    if (m < 24 * 60) return 'был(а) ' + Math.round(m / 60) + ' ч назад';
    return 'был(а) ' + fmtDate(ts);
  }

  // график ELO по последним матчам
  function eloChart(p) {
    const hist = (p.history || []).slice().reverse();
    const pts = [];
    let e = p.elo;
    const back = [e];
    for (const m of p.history || []) { e -= m.d; back.push(e); }
    back.reverse().forEach(v => pts.push(v));
    if (pts.length < 3) return h('div', { class: 'pf-empty' }, 'Сыграй пару матчей — тут появится график ELO');
    const W = 320, H = 110, pad = 8;
    let lo = Math.min(...pts), hi = Math.max(...pts);
    if (hi - lo < 40) { const c = (hi + lo) / 2; lo = c - 20; hi = c + 20; }
    const X = i => pad + i * (W - pad * 2) / (pts.length - 1);
    const Y = v => H - pad - (v - lo) / (hi - lo) * (H - pad * 2);
    const line = pts.map((v, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1)).join(' ');
    const area = line + ' L' + X(pts.length - 1).toFixed(1) + ' ' + H + ' L' + X(0).toFixed(1) + ' ' + H + ' Z';
    // границы уровней, которые попадают в диапазон
    let grid = '';
    S.meta.levels.forEach((v, k) => {
      if (k && v > lo && v < hi) grid += '<line x1="0" x2="' + W + '" y1="' + Y(v).toFixed(1) + '" y2="' + Y(v).toFixed(1) + '" class="ec-lv"/><text x="' + (W - 4) + '" y="' + (Y(v) - 3).toFixed(1) + '" class="ec-lt">' + (k + 1) + ' ур.</text>';
    });
    const dots = hist.map((m, i) => '<circle cx="' + X(i + 1).toFixed(1) + '" cy="' + Y(pts[i + 1]).toFixed(1) + '" r="2.6" class="' + (m.leave ? 'ec-x' : m.win ? 'ec-w' : 'ec-l') + '"/>').join('');
    const last = pts[pts.length - 1];
    const svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" class="ec-svg">' +
      '<defs><linearGradient id="ecG" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#f24044" stop-opacity=".45"/><stop offset="1" stop-color="#f24044" stop-opacity="0"/></linearGradient></defs>' +
      grid + '<path d="' + area + '" fill="url(#ecG)" class="ec-area"/><path d="' + line + '" class="ec-line" pathLength="1"/>' + dots +
      '<circle cx="' + X(pts.length - 1).toFixed(1) + '" cy="' + Y(last).toFixed(1) + '" r="5" class="ec-now"/></svg>';
    const total = pts[pts.length - 1] - pts[0];
    return h('div', { class: 'ec' },
      h('div', { class: 'ec-head' },
        h('span', null, 'ELO за ' + (pts.length - 1) + ' ' + plural(pts.length - 1, 'матч', 'матча', 'матчей')),
        h('b', { class: total >= 0 ? 'p' : 'n' }, (total >= 0 ? '+' : '') + total)),
      h('div', { class: 'ec-box', svg }),
      h('div', { class: 'ec-foot' }, h('span', null, 'мин ' + Math.min(...pts)), h('span', null, 'макс ' + Math.max(...pts))));
  }

  function ring(pct, label) {
    const C = 2 * Math.PI * 34;
    return h('div', { class: 'pf-ring', svg: '<svg viewBox="0 0 80 80"><circle cx="40" cy="40" r="34" class="r-bg"/><circle cx="40" cy="40" r="34" class="r-fg" style="stroke-dasharray:' + (C * pct / 100).toFixed(1) + ' ' + C.toFixed(1) + '"/></svg>' },
      h('b', null, pct + '%'), h('small', null, label));
  }

  function profileCard(p, other) {
    const LV = S.meta.levels;
    const nextAt = p.lvl < 10 ? LV[p.lvl] : null;
    const curAt = LV[p.lvl - 1];
    const pct = nextAt ? Math.max(3, Math.min(100, (p.elo - curAt) / (nextAt - curAt) * 100)) : 100;
    const wr = p.matches ? Math.round(p.wins / p.matches * 100) : 0;
    const mine = p.id === S.st.me.id;
    const wrap = h('div', { class: 'pf' });

    // шапка
    const chips = h('div', { class: 'pf-chips' },
      h('span', { class: 'pf-chip lv' }, lvl(p.lvl), 'Уровень ' + p.lvl),
      p.rank ? h('span', { class: 'pf-chip' + (p.rank <= 3 && p.matches ? ' gold' : '') }, (p.rank <= 3 && p.matches ? '👑 ' : '') + '#' + p.rank + ' в топе') : null,
      p.admin ? h('span', { class: 'pf-chip red' }, 'Админ') : null,
      p.tg ? h('span', { class: 'pf-chip tg' }, '✈ Telegram') : null,
      p.banned ? h('span', { class: 'pf-chip red' }, 'Заблокирован') : null);
    const hero = h('div', { class: 'card pf-hero' },
      bannerEl(p.banner, 'pf-banner'),
      h('div', { class: 'pf-top' },
        h('div', { class: 'pf-ava' }, ava(p, 104), h('i', { class: 'pf-on' + (p.online ? ' on' : '') })),
        h('div', { class: 'pf-id' },
          nick(p, 'pf-nick'),
          h('div', { class: 'pf-sub' }, h('span', { class: 'online-dot' + (p.online ? ' on' : '') }), p.online ? 'в сети' : seenText(p.seen), ' · ID #' + p.id))),
      chips,
      p.bio ? h('div', { class: 'pf-bio' }, p.bio) : null,
      p.rid ? h('button', { class: 'pf-rid', onclick: () => copy(p.rid) },
        h('span', { class: 'pf-rid-ic' }, '🎮'),
        h('span', { class: 'grow' }, h('small', null, 'ID в игре'), h('b', null, p.rid)),
        h('span', { class: 'pf-rid-cp' }, 'Копировать')) : null,
      h('div', { class: 'pf-acts' },
        mine ? h('button', { class: 'btn soft grow', onclick: () => openEditProfile() }, '✎ Изменить профиль') : null,
        other && !p.banned ? h('button', { class: 'btn grow', onclick: async () => { const r = await api('/api/party/invite', { nick: p.nick }); if (r) toast('Приглашение отправлено', 'ok'); } }, 'Позвать в пати') : null,
        h('button', { class: 'btn ghost pf-share', title: 'Поделиться', onclick: () => shareProfile(p), svg: '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M18 8a3 3 0 1 0-2.8-4M6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm12 7a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM8.6 13.5l6.8 4M15.4 6.5l-6.8 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>' })));
    wrap.append(hero);

    // ELO, уровень и график
    wrap.append(h('div', { class: 'card pf-elo' },
      h('div', { class: 'elo-row' }, lvl(p.lvl, true),
        h('div', { class: 'grow' },
          h('div', { class: 'row' }, h('span', { class: 'e' }, p.elo), h('span', { class: 'muted', style: { fontWeight: 800 } }, 'ELO')),
          h('div', { class: 'prog' }, phase(h('i', { style: { width: pct + '%' } }))),
          h('div', { class: 'muted small', style: { marginTop: '4px', fontWeight: 700 } }, nextAt ? 'до ' + (p.lvl + 1) + ' уровня: ' + (nextAt - p.elo) + ' ELO' : 'максимальный уровень'))),
      eloChart(p)));

    // форма и цифры
    const last5 = (p.history || []).slice(0, 5).reverse();
    wrap.append(h('div', { class: 'card pf-form' },
      ring(wr, 'винрейт'),
      h('div', { class: 'grow' },
        h('div', { class: 'pf-lbl' }, 'Форма'),
        h('div', { class: 'pf-five' }, last5.length ? last5.map((m, k) => h('span', { class: 'f5 ' + (m.leave ? 'x' : m.win ? 'w' : 'l'), style: { animationDelay: (k * 0.07) + 's' } }, m.leave ? '×' : m.win ? 'W' : 'L')) : h('span', { class: 'muted small' }, 'нет матчей')),
        h('div', { class: 'pf-wl' }, h('b', { class: 'w' }, p.wins), ' побед · ', h('b', { class: 'l' }, p.losses), ' поражений'))));
    const tile = (ic, v, t, sm) => h('div', { class: 'pf-stat' + (sm ? ' sm' : '') }, h('i', null, ic), h('b', null, v), h('span', null, t));
    wrap.append(h('div', { class: 'pf-stats' },
      tile('⚔', p.matches, 'Матчи'),
      tile('🏆', p.wins, 'Победы'),
      tile('📈', p.best, 'Рекорд ELO'),
      tile('🔥', p.bestStreak || 0, 'Лучшая серия'),
      tile(p.streak >= 0 ? '↗' : '↘', p.streak > 0 ? p.streak + 'W' : p.streak < 0 ? -p.streak + 'L' : '0', 'Серия сейчас'),
      tile('📅', fmtDay(p.created), 'В ' + S.meta.brand + ' с', true)));
    if (p.leaves) wrap.append(h('div', { class: 'leaves-line' }, '⚠ Покинул матчей: ' + p.leaves));

    // карты
    const mapsCard = h('div', { class: 'card' }, h('div', { class: 'section-t', style: { margin: '0 0 8px' } }, 'Карты'));
    const rows = Object.entries(p.maps || {}).map(([name, r]) => ({ name, w: r[0], l: r[1], n: r[0] + r[1] })).filter(x => x.n).sort((a, b) => b.n - a.n || b.w - a.w);
    if (!rows.length) mapsCard.append(h('div', { class: 'pf-empty' }, 'Ещё не играл ни на одной карте'));
    rows.forEach((x, k) => {
      const w = Math.round(x.w / x.n * 100);
      const src = mapImg(x.name);
      mapsCard.append(h('div', { class: 'pf-map' },
        src ? h('img', { src, alt: '', loading: 'lazy' }) : h('span', { class: 'pf-map-fb' }, x.name[0]),
        h('div', { class: 'grow' },
          h('div', { class: 'row', style: { gap: '6px' } }, h('b', null, x.name), k === 0 ? h('span', { class: 'pf-fav' }, '★ любимая') : null),
          h('div', { class: 'pf-bar' }, h('i', { class: w >= 50 ? 'w' : 'l', style: { width: Math.max(4, w) + '%' } })),
          h('div', { class: 'muted small' }, x.n + ' ' + plural(x.n, 'матч', 'матча', 'матчей') + ' · ' + x.w + '–' + x.l)),
        h('div', { class: 'pf-pct ' + (w >= 50 ? 'w' : 'l') }, w + '%')));
    });
    wrap.append(mapsCard);

    // достижения
    const got = ACH.filter(a => a.v(p) >= a.n).length;
    wrap.append(h('div', { class: 'card' },
      h('div', { class: 'row', style: { marginBottom: '10px' } }, h('div', { class: 'section-t grow', style: { margin: 0 } }, 'Достижения'), h('span', { class: 'tag dark' }, got + ' из ' + ACH.length)),
      h('div', { class: 'ach-grid' }, ACH.map(a => {
        const v = Math.max(0, a.v(p) || 0);
        const done = v >= a.n;
        return h('div', { class: 'ach' + (done ? ' got' : '') },
          h('div', { class: 'ach-ic' }, a.ic),
          h('b', null, a.t),
          h('span', null, a.d),
          done ? h('em', null, '✓ Получено') : a.n > 1 ? h('div', { class: 'ach-p' }, h('i', { style: { width: Math.min(100, v / a.n * 100) + '%' } }), h('small', null, Math.min(v, a.n) + ' / ' + a.n)) : h('em', { class: 'no' }, 'Не получено'));
      }))));

    // последние матчи
    const hist = h('div', { class: 'card' }, h('div', { class: 'section-t', style: { margin: '0 0 4px' } }, 'Последние матчи'));
    if (!p.history.length) hist.append(h('p', { class: 'muted' }, 'Пока нет сыгранных матчей.'));
    for (const m of p.history.slice(0, 15)) {
      const src = m.map && mapImg(m.map);
      hist.append(h('div', { class: 'hist' },
        h('div', { class: 'wl ' + (m.leave ? 'x' : m.win ? 'w' : 'l') }, m.leave ? 'ЛИВ' : m.win ? 'W' : 'L'),
        src ? h('img', { class: 'hist-map', src, alt: '', loading: 'lazy' }) : null,
        h('div', { class: 'grow' }, h('div', { style: { fontWeight: 900 } }, m.map || '—'), h('div', { class: 'muted small' }, (S.meta.modes[m.mode] ? S.meta.modes[m.mode].title : m.mode) + ' · матч #' + m.m + ' · ' + fmtDate(m.ts))),
        h('div', { class: 'delta ' + (m.d >= 0 ? 'p' : 'n') }, (m.d >= 0 ? '+' : '') + m.d)));
    }
    wrap.append(hist);
    return wrap;
  }

  function fmtDay(ts) {
    try { return new Date(ts).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: '2-digit' }); } catch (e) { return '—'; }
  }

  function shareProfile(p) {
    const url = location.origin + '/?u=' + p.id;
    const text = p.nick + ' — ' + p.elo + ' ELO, уровень ' + p.lvl + ' в ' + S.meta.brand + ' FACEIT';
    if (navigator.share) { navigator.share({ title: p.nick, text, url }).catch(() => {}); return; }
    copy(url);
  }

  async function renderProfilePage(page) {
    page.append(h('h1', { class: 'h1' }, 'Профиль'), h('div', { class: 'h1-bar' }));
    const p = await api('/api/profile?id=' + S.st.me.id);
    if (!p || S.page !== 'profile') return;
    page.append(profileCard(p, false));
  }

  // ---------- редактирование профиля ----------
  async function openEditProfile() {
    const p = await api('/api/profile?id=' + S.st.me.id);
    if (!p) return;
    openModal('pedit', 'Мой профиль', body => {
      const me = S.st.me;
      const face = h('div', { class: 'pe-ava' });
      const drawFace = () => { face.innerHTML = ''; face.append(ava({ id: me.id, nick: me.nick, frame: me.equip.frame, av: S.st.me.av }, 92)); };
      drawFace();
      const file = h('input', { type: 'file', accept: 'image/*', style: { display: 'none' } });
      file.onchange = () => { const f = file.files && file.files[0]; file.value = ''; if (f) cropAvatar(f, body); };
      const bio = h('textarea', { class: 'input pe-bio', maxlength: 140, rows: 3, placeholder: 'Пара слов о себе: роль, любимое оружие, когда играешь…' });
      bio.value = p.bio || '';
      const cnt = h('span', { class: 'pe-cnt' }, bio.value.length + '/140');
      bio.oninput = () => { cnt.textContent = bio.value.length + '/140'; };
      const rid = h('input', { class: 'input', maxlength: 24, placeholder: 'Например 1234567 или ник в игре', autocapitalize: 'off' });
      rid.value = p.rid || '';
      body.append(
        h('div', { class: 'pe-top' }, face,
          h('div', { class: 'grow' },
            h('button', { class: 'btn sm', onclick: () => file.click() }, '📷 Загрузить фото'),
            S.st.me.av ? h('button', { class: 'btn sm ghost', style: { marginTop: '8px' }, onclick: () => confirmAsk('Удалить аватар?', async () => { if (await api('/api/avatar/remove', {})) { S.st.me.av = null; toast('Аватар удалён', 'ok'); openEditProfile(); } }) }, 'Удалить') : null,
            h('div', { class: 'muted small', style: { marginTop: '8px' } }, 'JPG, PNG или WebP. Видно всем: в топе, лобби и матчах.'))),
        file,
        h('div', { class: 'section-t' }, 'О себе'), bio, cnt,
        h('div', { class: 'section-t' }, 'ID в игре'),
        rid,
        h('div', { class: 'muted small', style: { marginTop: '6px' } }, 'Покажется в профиле и в комнате матча — так тебя быстрее найдут и добавят.'),
        h('button', { class: 'btn block', style: { marginTop: '18px' }, onclick: async () => {
          if (await api('/api/profile/edit', { bio: bio.value, rid: rid.value })) {
            toast('Профиль сохранён', 'ok');
            closeModal();
            if (S.page === 'profile') renderPage(true);
          }
        } }, 'Сохранить'));
    });
  }

  // выбор и обрезка аватара: двигаешь пальцем, ползунком приближаешь
  function cropAvatar(fileObj, body) {
    const url = URL.createObjectURL(fileObj);
    const img = new Image();
    img.onerror = () => { URL.revokeObjectURL(url); toast('Не получилось открыть картинку — попробуй JPG или PNG', 'err'); };
    img.onload = () => {
      const V = 260;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const cv = h('canvas', { class: 'crop-cv', width: V * dpr, height: V * dpr });
      const ctx = cv.getContext('2d');
      const base = Math.max(V / img.naturalWidth, V / img.naturalHeight);
      const st = { z: 1, x: 0, y: 0 };
      const clamp = () => {
        const sc = base * st.z;
        const mx = Math.max(0, (img.naturalWidth * sc - V) / 2), my = Math.max(0, (img.naturalHeight * sc - V) / 2);
        st.x = Math.max(-mx, Math.min(mx, st.x));
        st.y = Math.max(-my, Math.min(my, st.y));
      };
      const draw = (c, size) => {
        const k = size / V, sc = base * st.z * k;
        const w = img.naturalWidth * sc, hh = img.naturalHeight * sc;
        c.fillStyle = '#140609';
        c.fillRect(0, 0, size, size);
        c.drawImage(img, size / 2 - w / 2 + st.x * k, size / 2 - hh / 2 + st.y * k, w, hh);
      };
      const paint = () => { ctx.setTransform(1, 0, 0, 1, 0, 0); draw(ctx, V * dpr); };
      paint();
      let drag = null;
      cv.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, sx: st.x, sy: st.y }; cv.setPointerCapture(e.pointerId); });
      cv.addEventListener('pointermove', e => { if (!drag) return; st.x = drag.sx + e.clientX - drag.x; st.y = drag.sy + e.clientY - drag.y; clamp(); paint(); });
      const up = () => { drag = null; };
      cv.addEventListener('pointerup', up);
      cv.addEventListener('pointercancel', up);
      const zoom = h('input', { type: 'range', min: 1, max: 4, step: 0.01, value: 1, class: 'crop-zoom' });
      zoom.oninput = () => { st.z = Number(zoom.value); clamp(); paint(); };
      cv.addEventListener('wheel', e => { e.preventDefault(); st.z = Math.max(1, Math.min(4, st.z * (e.deltaY < 0 ? 1.08 : 0.92))); zoom.value = st.z; clamp(); paint(); }, { passive: false });
      const saveBtn = h('button', { class: 'btn block', onclick: async () => {
        saveBtn.disabled = true;
        saveBtn.textContent = 'Загружаю…';
        const out = h('canvas', { width: 256, height: 256 });
        draw(out.getContext('2d'), 256);
        const blob = await new Promise(r => out.toBlob(b => {
          if (b && b.type === 'image/webp') r(b); else out.toBlob(r, 'image/jpeg', 0.88);
        }, 'image/webp', 0.86));
        URL.revokeObjectURL(url);
        const ok = blob && await uploadAvatar(blob);
        if (ok) { toast('Аватар обновлён', 'ok'); if (S.page === 'profile') renderPage(true); openEditProfile(); } else { saveBtn.disabled = false; saveBtn.textContent = 'Сохранить'; }
      } }, 'Сохранить');
      body.innerHTML = '';
      body.append(
        h('div', { class: 'crop' }, cv, h('div', { class: 'crop-mask' })),
        h('div', { class: 'crop-row' }, h('span', null, '−'), zoom, h('span', null, '+')),
        h('div', { class: 'muted small center', style: { margin: '6px 0 14px' } }, 'Перетащи фото пальцем, ползунком — приблизь'),
        saveBtn,
        h('button', { class: 'btn block ghost', style: { marginTop: '10px' }, onclick: () => { URL.revokeObjectURL(url); openEditProfile(); } }, 'Отмена'));
    };
    img.src = url;
  }

  async function uploadAvatar(blob) {
    try {
      const res = await fetch('/api/avatar', { method: 'POST', headers: { 'Content-Type': blob.type, Authorization: 'Bearer ' + S.token }, body: blob });
      let j = {};
      try { j = await res.json(); } catch (e) { j = { error: 'Сервер ответил с ошибкой (' + res.status + ')' }; }
      if (!res.ok || j.error) { toast(j.error || 'Ошибка', 'err'); return false; }
      if (S.st && j.av) S.st.me.av = j.av;
      return true;
    } catch (e) {
      toast('Нет связи с сервером', 'err');
      return false;
    }
  }

  // ---------- ТОП ----------
  async function renderTop(page) {
    const by = S.topBy || 'elo';
    page.append(h('div', { class: 'top-hero' },
      h('div', { class: 'th-rays' }),
      h('div', { class: 'th-cup', svg: '<svg viewBox="0 0 64 64"><defs><linearGradient id="cupG" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#fff3c4"/><stop offset=".5" stop-color="#fbbf24"/><stop offset="1" stop-color="#b45309"/></linearGradient></defs><path d="M18 8h28v14a14 14 0 0 1-28 0z" fill="url(#cupG)"/><path d="M18 12H9a9 9 0 0 0 10 12M46 12h9a9 9 0 0 1-10 12" fill="none" stroke="#fbbf24" stroke-width="4"/><path d="M28 36h8v10h-8z" fill="#d97706"/><rect x="20" y="46" width="24" height="8" rx="3" fill="url(#cupG)"/><path d="M27 14l3 6 6 1-4.5 4 1 6-5.5-3" fill="#fff8" /></svg>' }),
      h('h1', { class: 'h1 th-t' }, 'Топ игроков'),
      h('p', { class: 'sub' }, winter() ? '❄ Зимний сезон · ' + S.meta.brand + ' FACEIT' : 'Лучшие игроки ' + S.meta.brand)));
    const tabs = [['elo', 'ELO'], ['wins', 'Победы'], ['wr', 'Винрейт'], ['week', 'Неделя']];
    const k = tabs.findIndex(t => t[0] === by);
    const seg = h('div', { class: 'modeseg top-seg', style: { '--n': tabs.length, '--k': k } }, h('i', { class: 'thumb' }));
    tabs.forEach(([key, title], i) => seg.append(h('button', {
      class: key === by ? 'on' : '',
      onclick: () => {
        if (key === (S.topBy || 'elo')) return;
        seg.style.setProperty('--k', i);
        S.topBy = key;
        setTimeout(() => { if (S.page === 'top') go('top'); }, 240);
      }
    }, title)));
    page.append(seg);
    const hint = { elo: 'Рейтинг по ELO', wins: 'Больше всего побед', wr: 'Лучший процент побед (от 5 матчей)', week: 'Больше всех набрали ELO за 7 дней' }[by];
    page.append(h('div', { class: 'top-hint' }, hint));
    const box = h('div', { class: 'top-box' }, h('div', { class: 'top-skel' }, Array.from({ length: 5 }, () => h('i'))));
    page.append(box);
    const r = await api('/api/top?by=' + by);
    if (!r || S.page !== 'top') return;
    box.innerHTML = '';
    const val = p => (by === 'wins' ? p.wins : by === 'wr' ? p.wr + '%' : by === 'week' ? (p.wk > 0 ? '+' : '') + p.wk : p.elo);
    const unit = p => (by === 'wins' ? plural(p.wins, 'победа', 'победы', 'побед') : by === 'wr' ? p.matches + ' ' + plural(p.matches, 'матч', 'матча', 'матчей') : by === 'week' ? 'ELO за неделю' : 'ELO');
    if (!r.list.length) {
      box.append(h('div', { class: 'card center muted', style: { padding: '30px 16px', fontWeight: 700 } }, by === 'wr' ? 'Сюда попадают игроки, у которых 5+ матчей.' : by === 'week' ? 'На этой неделе ещё никто не играл.' : 'Пока пусто — сыграй первый матч!'));
      return;
    }

    // пьедестал
    const podium = h('div', { class: 'podium' }, h('div', { class: 'pod-spot' }));
    [1, 0, 2].forEach(i => {
      const p = r.list[i];
      const place = i + 1;
      podium.append(h('div', { class: 'pod p' + place + (p ? '' : ' none'), onclick: p ? () => openProfile(p.id) : null },
        h('div', { class: 'pod-ava' },
          place === 1 && p ? h('div', { class: 'crown', svg: CROWN }) : null,
          p ? ava(p, place === 1 ? 86 : 68) : h('span', { class: 'ava-empty' }, '?'),
          p && p.on ? h('i', { class: 'pod-on' }) : null),
        p ? nick(p, 'pod-nick') : h('span', { class: 'pod-nick muted' }, 'свободно'),
        p ? h('div', { class: 'pod-val' }, lvl(p.lvl), h('b', null, val(p))) : h('div', { class: 'pod-val' }),
        phase(h('div', { class: 'pod-block' }, h('span', null, place), p ? h('small', null, unit(p)) : null))));
    });
    if (r.list[0]) podium.append(h('div', { class: 'pod-sparks' }, Array.from({ length: 10 }, (_, j) => h('i', { style: { '--x': (8 + j * 9) + '%', '--d': (j * 0.37 % 2.2) + 's', '--t': (2.2 + j % 3 * 0.6) + 's' } }))));
    box.append(podium);

    // моё место
    if (r.me) {
      const me = r.me;
      const pct = Math.max(1, Math.round((1 - (me.rank - 1) / Math.max(1, r.total)) * 100));
      box.append(h('div', { class: 'card my-place' },
        h('div', { class: 'mp-shine' }),
        h('div', { class: 'mp-rank' }, h('small', null, 'место'), '#' + me.rank),
        ava(me, 46),
        h('div', { class: 'grow' }, nick(me), h('div', { class: 'small', style: { opacity: .85, fontWeight: 800 } }, me.rank <= 3 ? 'Ты на пьедестале! 👑' : 'Лучше, чем ' + pct + '% игроков')),
        h('div', { class: 'mp-val' }, val(me), h('small', null, unit(me)))));
    } else if (by === 'wr' || by === 'week') {
      box.append(h('div', { class: 'card muted small center', style: { fontWeight: 700 } }, by === 'wr' ? 'Сыграй 5 матчей, чтобы попасть в этот топ.' : 'Сыграй матч на этой неделе, чтобы попасть сюда.'));
    }

    // поиск и остальные
    if (r.list.length > 3) {
      const q = h('input', { class: 'input top-search', placeholder: '🔍 Найти игрока в топе', autocapitalize: 'off' });
      const card = h('div', { class: 'card top-list' });
      const rows = r.list.slice(3).map((p, j) => {
        const form = (p.form || '').split('').filter(Boolean);
        return h('button', {
          class: 'trow' + (p.id === S.st.me.id ? ' me' : '') + (p.rank <= 10 ? ' t10' : ''),
          style: { animationDelay: Math.min(j * 35, 700) + 'ms' },
          'data-n': p.nick.toLowerCase(),
          onclick: () => openProfile(p.id)
        },
        h('div', { class: 'rk' }, p.rank),
        h('div', { class: 'tr-ava' }, ava(p, 42), p.on ? h('i', { class: 'pod-on sm' }) : null),
        h('div', { class: 'grow', style: { minWidth: 0 } }, nick(p),
          h('div', { class: 'tr-sub' },
            form.length ? h('span', { class: 'tr-form' }, form.map(x => h('i', { class: x === 'W' ? 'w' : x === 'L' ? 'l' : 'x' }))) : null,
            h('span', { class: 'muted small' }, p.matches + ' ' + plural(p.matches, 'матч', 'матча', 'матчей') + ' · ' + p.wr + '%'))),
        lvl(p.lvl),
        h('div', { class: 'e' + (by === 'week' ? (p.wk >= 0 ? ' up' : ' down') : '') }, val(p)));
      });
      const empty = h('div', { class: 'muted center small', style: { padding: '14px', display: 'none', fontWeight: 700 } }, 'Никого не нашлось');
      q.oninput = () => {
        const v = q.value.trim().toLowerCase();
        let n = 0;
        rows.forEach(rw => { const ok = !v || rw.dataset.n.includes(v); rw.style.display = ok ? '' : 'none'; if (ok) n++; });
        empty.style.display = n ? 'none' : '';
      };
      card.append(...rows, empty);
      box.append(q, card);
    }
    box.append(h('div', { class: 'muted small center', style: { margin: '14px 0 0', fontWeight: 700 } }, 'Всего в рейтинге: ' + r.total));
  }

  // ---------- ИНВЕНТАРЬ ----------
  const TYPES = { frame: 'Рамки аватара', color: 'Цвет ника', banner: 'Баннеры профиля' };
  function renderInv(page) {
    const me = S.st.me;
    S.invSig = me.ec + '|' + me.items.join() + '|' + JSON.stringify(me.equip);
    page.append(h('h1', { class: 'h1' }, 'Инвентарь'), h('div', { class: 'h1-bar' }),
      h('div', { class: 'seg' },
        h('button', { class: S.invTab === 'mine' ? 'on' : '', onclick: () => { S.invTab = 'mine'; go('inv'); } }, 'Мои предметы'),
        h('button', { class: S.invTab === 'shop' ? 'on' : '', onclick: () => { S.invTab = 'shop'; go('inv'); } }, 'Магазин')));
    const all = S.meta.catalog.filter(it => (S.invTab === 'mine' ? me.items.includes(it.id) : true));
    if (!all.length) {
      page.append(h('div', { class: 'card center' }, h('p', { style: { fontWeight: 700 } }, 'У тебя пока нет предметов.'),
        h('button', { class: 'btn', onclick: () => { S.invTab = 'shop'; go('inv'); } }, 'В магазин')));
      return;
    }
    const groups = [];
    if (S.invTab === 'shop' && winter()) {
      groups.push(['❄ Зимняя коллекция', all.filter(it => it.season === 'winter'), true]);
      for (const t of Object.keys(TYPES)) groups.push([TYPES[t], all.filter(it => it.type === t && it.season !== 'winter')]);
    } else {
      for (const t of Object.keys(TYPES)) groups.push([TYPES[t], all.filter(it => it.type === t)]);
    }
    for (const [title, list, special] of groups) {
      if (!list.length) continue;
      page.append(h('div', { class: 'section-t' + (special ? ' winter-t' : '') }, title));
      page.append(h('div', { class: 'items' }, list.map(it => itemCard(it, me))));
    }
  }
  function itemCard(it, me) {
    const owned = me.items.includes(it.id);
    const on = me.equip[it.type] === it.id;
    const fake = { id: me.id, nick: me.nick, frame: me.equip.frame, color: me.equip.color, av: me.av };
    let pv;
    if (it.type === 'frame') pv = ava(Object.assign({}, fake, { frame: it.id }), 62);
    else if (it.type === 'color') pv = nick(Object.assign({}, fake, { color: it.id }), 'pv-nick');
    else pv = bannerEl(it.id, 'pv-banner');
    let btn;
    if (on) btn = h('button', { class: 'btn ghost', onclick: () => api('/api/shop/unequip', { type: it.type }) }, 'Снять');
    else if (owned) btn = h('button', { class: 'btn soft', onclick: () => api('/api/shop/equip', { id: it.id }) }, 'Надеть');
    else btn = h('button', { class: 'btn', disabled: me.ec < it.price, onclick: () => confirmAsk('Купить «' + it.name + '» за ' + it.price + ' EC?', async () => { if (await api('/api/shop/buy', { id: it.id })) toast('Куплено и надето', 'ok'); }) }, me.ec < it.price ? 'Мало EC' : 'Купить');
    return h('div', { class: 'item' + (on ? ' on' : '') + (it.season === 'winter' ? ' winter-item' : '') },
      it.rare ? h('span', { class: 'ribbon rare-' + it.rare }, it.rare === 'legend' ? '★ Легенда' : '◆ Эпик') : it.season === 'winter' ? h('span', { class: 'ribbon' }, '❄ Зима') : null,
      it.anim || it.grad ? h('span', { class: 'ribbon anim', title: 'анимация' }, '✦') : null,
      h('div', { class: 'pv' }, pv),
      h('div', { class: 'nm' }, it.name),
      owned ? h('div', { class: 'small muted', style: { fontWeight: 800 } }, on ? 'Надето' : 'Есть') : h('div', { class: 'pr' }, it.price + ' EC'),
      btn);
  }

  // ---------- ЕЩЁ ----------
  function renderMore(page) {
    const me = S.st.me;
    page.append(h('h1', { class: 'h1' }, 'Ещё'), h('div', { class: 'h1-bar' }));
    page.append(h('div', { class: 'card' },
      h('div', { class: 'row' },
        h('div', { class: 'grow' }, h('div', { style: { fontWeight: 900, fontSize: '20px' } }, 'Ежедневный бонус'), h('div', { class: 'muted' }, '+' + S.meta.rewards.daily + ' EC раз в сутки')),
        h('button', { class: 'btn sm', id: 'dailyBtn', onclick: async () => { const r = await api('/api/daily', {}); if (r) toast('+' + r.bonus + ' EC', 'ok'); } }, 'Забрать'))));
    page.append(h('div', { class: 'card' },
      h('div', { class: 'section-t', style: { margin: '0 0 4px' } }, 'Оформление'),
      winter() ? toggleRow('Снег', 'Падающий снег на всех экранах', S.snow, v => { S.snow = v; store.set('etn_snow', v ? '1' : '0'); applyLook(); }) : null,
      toggleRow('Звук «Матч найден»', 'Сигнал, когда лобби собралось', S.sound, v => { S.sound = v; store.set('etn_sound', v ? '1' : '0'); if (v) Sound.found(); }),
      toggleRow('Анимации', 'Выключи, если телефон тормозит', !S.calm, v => { S.calm = !v; store.set('etn_calm', S.calm ? '1' : '0'); applyLook(); })));

    page.append(h('div', { id: 'tgBox' }));
    if (me.admin) page.append(...adminPanel());

    const nickIn = h('input', { class: 'input', placeholder: 'Новый ник', maxlength: 16, value: me.nick });
    const oldP = h('input', { class: 'input', type: 'password', placeholder: 'Старый пароль', autocomplete: 'current-password' });
    const newP = h('input', { class: 'input', type: 'password', placeholder: 'Новый пароль', autocomplete: 'new-password' });
    page.append(h('div', { class: 'card' },
      h('div', { class: 'section-t', style: { margin: '0 0 10px' } }, 'Аккаунт · ID #' + me.id),
      h('div', { class: 'chat-in' }, nickIn, h('button', { class: 'btn', style: { width: 'auto', padding: '0 16px' }, onclick: async () => { if (await api('/api/nick', { nick: nickIn.value.trim() })) toast('Ник изменён', 'ok'); } }, 'OK')),
      h('p', { class: 'muted small' }, 'Ник можно менять раз в сутки.'),
      h('div', { style: { display: 'grid', gap: '10px', marginTop: '6px' } }, oldP, newP,
        h('button', { class: 'btn soft', onclick: async () => { if (await api('/api/password', { old: oldP.value, pass: newP.value })) { toast('Пароль изменён', 'ok'); oldP.value = newP.value = ''; } } }, 'Сменить пароль'))));

    const m = S.meta;
    page.append(h('div', { class: 'card rules' },
      h('div', { class: 'section-t', style: { margin: '0 0 10px' } }, 'Как это работает'),
      h('p', null, '1. Зайди в лобби или нажми «Быструю игру». Когда лобби заполнится — у всех появится окно «Матч найден», на принятие ' + m.acceptSeconds + ' секунд. Кто не принял — вылетает и получает паузу.'),
      h('p', null, '2. Команды собираются автоматически по ELO, пати всегда в одной команде. Капитаны (♛) по очереди убирают карты, пока не останется одна.'),
      h('p', null, '3. Хост создаёт комнату в игре и пишет код в матч. Все заходят по коду и играют.'),
      h('p', null, '4. После игры капитаны отмечают результат. Совпало — ELO и EC начисляются сразу (победа +' + m.rewards.win + ' EC, поражение +' + m.rewards.loss + ' EC). Не совпало — решает администратор. Если второй капитан молчит ' + m.autoConfirmMinutes + ' минут, засчитывается то, что отметил первый.'),
      h('p', null, '5. Матч можно отменить, если за это проголосует больше половины игроков.')));

    page.append(h('div', { class: 'card' }, h('button', { class: 'list-btn', style: { color: '#ff5c6c' }, onclick: () => logout(false) }, 'Выйти из аккаунта')));
    updateMore();
  }
  // ---------- Telegram в «Ещё» ----------
  function fillTg() {
    const box = $('#tgBox');
    if (!box) return;
    const me = S.st.me;
    const sig = JSON.stringify([me.tg, S.st.tgBot]);
    if (box.dataset.sig === sig) return;
    box.dataset.sig = sig;
    box.innerHTML = '';
    if (!S.st.tgBot && !me.admin) return;
    const card = h('div', { class: 'card tg-card' },
      h('div', { class: 'row' },
        h('div', { class: 'tg-ico', svg: PLANE }),
        h('div', { class: 'grow' },
          h('div', { class: 'tg-t' }, 'Telegram'),
          h('div', { class: 'muted small', style: { fontWeight: 700 } }, me.tg ? 'Привязан: ' + me.tg.name : 'Уведомления о матчах, вход без пароля и восстановление пароля'))));
    if (!S.st.tgBot) {
      card.append(h('p', { class: 'muted small', style: { fontWeight: 700, marginBottom: 0 } }, 'Бот ещё не подключён. Подключи его ниже в админ-панели.'));
    } else if (me.tg) {
      card.append(toggleRow('Уведомления в Telegram', 'Матч найден, пати, код комнаты, результат', me.tg.notify, v => api('/api/tg/notify', { on: v })),
        h('div', { class: 'btns' },
          h('button', { class: 'btn sm soft', onclick: () => openTg({ bot: S.st.tgBot }) }, 'Открыть бота'),
          h('button', { class: 'btn sm ghost', onclick: () => confirmAsk('Отвязать Telegram от аккаунта?', () => api('/api/tg/unlink', {})) }, 'Отвязать')));
    } else {
      card.append(h('button', {
        class: 'btn block tg-btn', style: { marginTop: '14px' },
        onclick: async () => {
          const r = await api('/api/tg/link', {});
          if (r) { openTg(r); toast('Нажми «Старт» в боте — и Telegram привяжется', 'ok'); }
        }
      }, h('span', { svg: PLANE }), 'Привязать Telegram'));
    }
    box.append(card);
  }

  function backupAdminBlock() {
    const box = h('div');
    const fmtSize = n => (n > 1048576 ? (n / 1048576).toFixed(1) + ' МБ' : Math.max(1, Math.round(n / 1024)) + ' КБ');
    const load = async () => {
      const r = await api('/api/admin/backups');
      box.innerHTML = '';
      if (!r) return;
      const file = h('input', { type: 'file', accept: '.gz,.json,application/gzip,application/json', style: { display: 'none' } });
      file.onchange = () => {
        const f = file.files[0];
        if (!f) return;
        confirmAsk('Заменить ВСЮ базу на «' + f.name + '»? Текущая база сохранится отдельной копией, сайт перезапустится.', async () => {
          const res = await fetch('/api/admin/restore', { method: 'POST', headers: { Authorization: 'Bearer ' + S.token, 'Content-Type': 'application/octet-stream' }, body: await f.arrayBuffer() });
          const j = await res.json().catch(() => ({}));
          if (!res.ok) return toast(j.error || 'Не получилось', 'err');
          toast('Восстановлено: ' + j.users + ' игроков. Сайт перезапускается…', 'ok');
          setTimeout(() => location.reload(), 5000);
        });
        file.value = '';
      };
      const last = r.last.time ? fmtDate(r.last.time) : 'ещё не было';
      box.append(
        h('div', { style: { fontWeight: 900, margin: '4px 0 6px' } }, 'Последний: ' + last),
        h('p', { class: 'muted small', style: { margin: '0 0 10px', lineHeight: 1.5 } },
          'Каждый день сервер сохраняет копию базы (14 последних) и присылает файл в Telegram всем админам с привязанным Telegram' +
          (r.tgAdmins ? ' (сейчас: ' + r.tgAdmins + ').' : ' — сейчас таких нет, привяжи Telegram выше.') + ' Команда боту /backup — бэкап сразу.'),
        h('div', { class: 'btns' },
          h('button', { class: 'btn xs', onclick: async () => { const x = await api('/api/admin/backup', {}); if (x) { toast('Бэкап готов' + (x.sent ? ', отправлен в Telegram' : ''), 'ok'); load(); } } }, 'Сделать сейчас'),
          r.files.length ? h('button', { class: 'btn xs soft', onclick: () => downloadBackup(r.files[0].name) }, 'Скачать последний') : null,
          h('button', { class: 'btn xs ghost', onclick: () => file.click() }, 'Восстановить из файла')),
        file,
        r.files.length ? h('div', { class: 'muted small', style: { marginTop: '8px' } }, 'На сервере: ' + r.files.length + ' шт., последний ' + fmtSize(r.files[0].size)) : null);
    };
    load();
    return box;
  }
  async function downloadBackup(name) {
    const res = await fetch('/api/admin/backup/file?name=' + encodeURIComponent(name), { headers: { Authorization: 'Bearer ' + S.token } });
    if (!res.ok) return toast('Не получилось скачать', 'err');
    const url = URL.createObjectURL(await res.blob());
    const a = h('a', { href: url, download: name });
    document.body.append(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 2000);
  }

  function tgAdminBlock() {
    const box = h('div');
    const load = async () => {
      const r = await api('/api/admin/tg');
      box.innerHTML = '';
      if (!r) return;
      const inp = h('input', { class: 'input', placeholder: '123456789:AAH…', autocapitalize: 'off', spellcheck: 'false' });
      box.append(
        h('div', { style: { fontWeight: 900, margin: '4px 0 8px' } },
          r.on ? (r.status === 'error' ? '⚠️ Ошибка: ' + r.error : '✅ Подключён: @' + r.bot + ' · привязали ' + r.linked) : 'Бот не подключён'),
        h('div', { class: 'chat-in' }, inp,
          h('button', { class: 'btn sm', style: { width: 'auto' }, onclick: async () => { if (await api('/api/admin/tg', { token: inp.value.trim() })) { toast('Бот подключён', 'ok'); load(); } } }, 'Подключить')),
        r.on ? h('button', { class: 'btn xs ghost', style: { marginTop: '8px' }, onclick: () => confirmAsk('Отключить Telegram-бота?', async () => { if (await api('/api/admin/tg', { token: '' })) load(); }) }, 'Отключить бота') : null,
        h('p', { class: 'muted small', style: { lineHeight: 1.5 } },
          '1. Открой в Telegram @BotFather → /newbot. 2. Придумай имя и ник бота (ник должен заканчиваться на bot). 3. BotFather пришлёт токен — вставь его сюда и нажми «Подключить».'));
    };
    load();
    return box;
  }

  function toggleRow(title, desc, on, fn) {
    const sw = h('button', { class: 'switch' + (on ? ' on' : ''), onclick: () => { const v = !sw.classList.contains('on'); sw.classList.toggle('on', v); fn(v); } }, h('i'));
    return h('div', { class: 'row', style: { padding: '10px 0' } },
      h('div', { class: 'grow' }, h('div', { style: { fontWeight: 900, fontSize: '17px' } }, title), h('div', { class: 'muted small' }, desc)), sw);
  }
  function updateMore() {
    fillTg();
    const b = $('#dailyBtn');
    if (b) { b.disabled = !S.st.me.daily; b.textContent = S.st.me.daily ? 'Забрать' : 'Получено'; }
    const d = $('#admDisputes');
    if (d) { d.textContent = S.st.disputes ? '⚠ ' + S.st.disputes : '✓'; d.className = 'adm-disp' + (S.st.disputes ? ' hot' : ''); d.title = S.st.disputes ? 'Спорных матчей: ' + S.st.disputes : 'Спорных матчей нет'; }
  }

  // ---------- АДМИН-ПАНЕЛЬ ----------
  const SHIELD = '<svg viewBox="0 0 48 56"><defs><linearGradient id="shG" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#ff8a8e"/><stop offset=".55" stop-color="#f24044"/><stop offset="1" stop-color="#7a0c18"/></linearGradient></defs><path d="M24 2 44 9v16c0 14-9 24-20 29C13 49 4 39 4 25V9z" fill="url(#shG)" stroke="#ffd0d2" stroke-width="2"/><path d="M15 28l6 6 12-13" fill="none" stroke="#fff" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function admSection(icon, title, body, open, extra) {
    const card = h('div', { class: 'card adm-sec' + (open ? ' open' : '') },
      h('button', { class: 'adm-sec-h', onclick: () => card.classList.toggle('open') },
        h('span', { class: 'adm-ic' }, icon), h('span', { class: 'grow' }, title), extra || null, h('span', { class: 'adm-chev' }, '›')),
      h('div', { class: 'adm-sec-b' }, h('div', null, body)));
    return card;
  }

  function adminPanel() {
    const cards = [];
    cards.push(h('div', { class: 'card adm-head' },
      h('div', { class: 'adm-shield', svg: SHIELD }),
      h('div', { class: 'grow' }, h('div', { class: 'adm-t' }, 'Админ-панель'), h('div', { class: 'adm-sub' }, h('span', { class: 'live-dot' }), 'Обновляется сама')),
      h('div', { id: 'admDisputes', class: 'adm-disp' })));

    // статистика
    const tiles = h('div', { class: 'adm-tiles' });
    const chart = h('div', { class: 'adm-chart' });
    const onl = h('div', { class: 'adm-onl' });
    const fresh = h('div', { class: 'adm-fresh' });
    const statsCard = h('div', { class: 'card adm-stats' }, h('div', { class: 'blk-h', style: { marginBottom: '10px' } }, '📊 Сводка'), tiles,
      h('div', { class: 'blk-h', style: { margin: '18px 0 8px' } }, '📈 Неделя'), chart,
      h('div', { class: 'adm-legend' }, h('span', { class: 'm' }, 'матчи'), h('span', { class: 'r' }, 'регистрации')));
    cards.push(statsCard);
    const onN = h('span', { class: 'tag green' }, '0');
    const onlCard = h('div', { class: 'card' }, h('div', { class: 'row', style: { marginBottom: '8px' } }, h('div', { class: 'grow blk-h' }, h('span', { class: 'live-dot g' }), 'Сейчас онлайн'), onN), onl);
    cards.push(onlCard);
    const DOW = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
    S.cnt = S.cnt || {};
    const loadStats = async () => {
      const r = await api('/api/admin/stats');
      if (!r) return;
      const tile = (ic, key, v, label, cls) => {
        if (S.cnt['adm_' + key] === undefined) S.cnt['adm_' + key] = 0;
        return h('div', { class: 'adm-tile ' + (cls || '') }, h('i', null, ic), cnt('adm_' + key, v), h('span', null, label));
      };
      tiles.innerHTML = '';
      tiles.append(
        tile('👥', 'users', r.users, 'игроков'),
        tile('🟢', 'online', r.online, 'онлайн', 'g'),
        tile('⚔', 'today', r.today, 'матчей сегодня'),
        tile('🎮', 'active', r.active, 'идут сейчас'),
        tile('⚠', 'disp', r.disputes, 'споров', r.disputes ? 'hot' : ''),
        tile('✨', 'new', r.newToday, 'новых сегодня'),
        tile('⛔', 'ban', r.banned, 'в бане · штраф ' + r.penalized),
        tile('💰', 'ec', r.ec, 'EC у игроков'),
        tile('📊', 'elo', r.avgElo, 'средний ELO'));
      const max = Math.max(1, ...r.days.map(d => Math.max(d.m, d.r)));
      chart.innerHTML = '';
      r.days.forEach((d, i) => {
        const wd = DOW[new Date(d.d + 'T12:00:00Z').getUTCDay()];
        chart.append(h('div', { class: 'ac-col' + (i === r.days.length - 1 ? ' today' : '') },
          h('div', { class: 'ac-bars' },
            h('div', { class: 'ac-b m', style: { height: Math.max(3, d.m / max * 100) + '%', animationDelay: (i * 60) + 'ms' } }, d.m ? h('b', null, d.m) : null),
            h('div', { class: 'ac-b r', style: { height: Math.max(3, d.r / max * 100) + '%', animationDelay: (i * 60 + 30) + 'ms' } }, d.r ? h('b', null, d.r) : null)),
          h('span', null, i === r.days.length - 1 ? 'Сег.' : wd)));
      });
      onl.innerHTML = '';
      onN.textContent = r.onlineList.length;
      if (!r.onlineList.length) onl.append(h('div', { class: 'muted small' }, 'Никого нет в сети.'));
      r.onlineList.forEach(p => onl.append(h('button', { class: 'adm-on', onclick: () => { q.value = String(p.id); loadUser(); playersSec.classList.add('open'); playersSec.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }, ava(p, 44), h('span', null, p.nick))));
      fresh.innerHTML = '';
      r.fresh.forEach(p => fresh.append(h('button', { class: 'adm-fr', onclick: () => { q.value = String(p.id); loadUser(); } }, ava(p, 30), h('span', null, p.nick), h('small', null, ago(p.created)))));
      if (r.announce && !annIn.dataset.touched) annIn.value = r.announce.t;
      annNow.textContent = r.announce ? 'Сейчас висит: «' + r.announce.t + '» — ' + r.announce.by : 'Сейчас объявления нет';
    };

    // матчи
    const mList = h('div');
    const mCount = h('span', { class: 'tag dark' }, '…');
    const loadMatches = async () => {
      const r = await api('/api/admin/matches');
      mList.innerHTML = '';
      if (!r) return;
      mCount.textContent = r.list.length;
      mCount.className = 'tag ' + (r.list.some(m => m.state === 'dispute') ? 'red' : r.list.length ? 'green' : 'dark');
      if (!r.list.length) mList.append(h('div', { class: 'pf-empty' }, 'Активных матчей нет.'));
      for (const M of r.list) {
        const src = M.map && mapImg(M.map);
        mList.append(h('div', { class: 'adm-m ' + M.state },
          h('div', { class: 'row' },
            src ? h('img', { class: 'lv-map', src, alt: '' }) : h('span', { class: 'lv-map lv-veto' }, '✕'),
            h('div', { class: 'grow' }, h('b', null, 'Матч #' + M.id), h('div', { class: 'muted small' }, (S.meta.modes[M.mode] ? S.meta.modes[M.mode].title : M.mode) + ' · ' + (M.map || 'вето') + (M.room ? ' · код ' + M.room : ''))),
            h('span', { class: 'lv-st ' + M.state }, STATUS[M.state])),
          h('div', { class: 'adm-teams' },
            h('div', { class: 'adm-team' }, h('b', null, 'A'), stack(M.teams[0], 26), h('span', null, M.teams[0].map(p => p.nick).join(', '))),
            h('div', { class: 'adm-team' }, h('b', null, 'B'), stack(M.teams[1], 26), h('span', null, M.teams[1].map(p => p.nick).join(', ')))),
          h('div', { class: 'small muted' }, 'Отметили: A → ' + (M.reports[0] === null ? '—' : 'победа ' + 'AB'[M.reports[0]]) + ', B → ' + (M.reports[1] === null ? '—' : 'победа ' + 'AB'[M.reports[1]])),
          h('div', { class: 'btns' },
            h('button', { class: 'btn xs green', onclick: () => confirmAsk('Победа команды A в матче #' + M.id + '?', async () => { if (await api('/api/admin/resolve', { id: M.id, winner: 0 })) loadMatches(); }) }, '🏆 Победа A'),
            h('button', { class: 'btn xs green', onclick: () => confirmAsk('Победа команды B в матче #' + M.id + '?', async () => { if (await api('/api/admin/resolve', { id: M.id, winner: 1 })) loadMatches(); }) }, '🏆 Победа B'),
            h('button', { class: 'btn xs red', onclick: () => confirmAsk('Отменить матч #' + M.id + '?', async () => { if (await api('/api/admin/resolve', { id: M.id, winner: 'cancel' })) loadMatches(); }) }, '✕ Отменить'))));
      }
    };
    cards.push(admSection('⚔', 'Активные матчи', [h('button', { class: 'btn xs soft', style: { marginBottom: '6px' }, onclick: loadMatches }, '↻ Обновить'), mList], true, mCount));

    // игроки
    const q = h('input', { class: 'input', placeholder: 'Ник или ID игрока' });
    const uBox = h('div');
    const loadUser = async () => {
      if (!q.value.trim()) return;
      const u = await api('/api/admin/user?q=' + encodeURIComponent(q.value.trim()));
      uBox.innerHTML = '';
      if (!u) return;
      const amount = h('input', { class: 'input', type: 'number', placeholder: 'EC (+/−)', style: { height: '44px' } });
      const elo = h('input', { class: 'input', type: 'number', placeholder: 'ELO', style: { height: '44px' } });
      uBox.append(
        u.av || u.bio ? h('div', { class: 'adm-ava' }, ava({ id: u.id, nick: u.nick, av: u.av }, 56),
          h('div', { class: 'grow small muted', style: { whiteSpace: 'pre-line' } }, u.bio || 'без «О себе»'),
          h('button', { class: 'btn xs red', onclick: () => confirmAsk('Удалить аватар и «О себе» у ' + u.nick + '?', async () => { if (await api('/api/admin/avatar', { id: u.id, bio: true })) { toast('Удалено', 'ok'); loadUser(); } }) }, 'Удалить')) : null,
        h('div', { class: 'kv' },
        h('span', null, 'Игрок'), h('b', null, u.nick + ' · ID #' + u.id + (u.online ? ' · в сети' : '')),
        h('span', null, 'ELO / EC'), h('b', null, u.elo + ' / ' + u.ec),
        h('span', null, 'Матчи'), h('b', null, u.matches + ' (побед ' + u.wins + ')'),
        h('span', null, 'Статус'), h('b', null, (u.banned ? 'заблокирован' : 'активен') + (u.admin ? ', админ' : '')),
        h('span', null, 'Штраф'), h('b', null, u.banUntil ? 'до ' + fmtDate(u.banUntil) + ' (' + u.banReason + ')' : 'нет'),
        h('span', null, 'Ливы / отказы'), h('b', null, u.leaves + ' всего / ' + u.declines + ' за сутки')),
      h('div', { class: 'chat-in' }, amount, h('button', { class: 'btn sm', style: { width: 'auto' }, onclick: async () => { if (await api('/api/admin/ec', { id: u.id, amount: Number(amount.value) })) { toast('Готово', 'ok'); loadUser(); } } }, 'EC')),
      h('div', { class: 'chat-in', style: { marginTop: '8px' } }, elo, h('button', { class: 'btn sm', style: { width: 'auto' }, onclick: async () => { if (await api('/api/admin/elo', { id: u.id, elo: Number(elo.value) })) { toast('Готово', 'ok'); loadUser(); } } }, 'ELO')),
      h('div', { class: 'btns' },
        u.banUntil || u.declines ? h('button', { class: 'btn xs green', onclick: async () => { if (await api('/api/admin/pardon', { id: u.id })) { toast('Штраф снят', 'ok'); loadUser(); } } }, 'Снять штраф') : null,
        h('button', { class: 'btn xs ' + (u.banned ? 'green' : 'red'), onclick: () => confirmAsk((u.banned ? 'Разблокировать ' : 'Заблокировать ') + u.nick + '?', async () => { if (await api('/api/admin/ban', { id: u.id, on: !u.banned })) loadUser(); }) }, u.banned ? 'Разблокировать' : 'Заблокировать'),
        h('button', { class: 'btn xs soft', onclick: () => confirmAsk((u.admin ? 'Снять права админа с ' : 'Сделать админом ') + u.nick + '?', async () => { if (await api('/api/admin/admin', { id: u.id, on: !u.admin })) loadUser(); }) }, u.admin ? 'Снять админа' : 'Сделать админом')));
    };
    q.addEventListener('keydown', e => { if (e.key === 'Enter') loadUser(); });
    const playersSec = admSection('👤', 'Игроки', [
      h('div', { class: 'chat-in' }, q, h('button', { class: 'btn', style: { width: 'auto', padding: '0 16px' }, onclick: loadUser }, 'Найти')), uBox,
      h('div', { class: 'section-t' }, 'Новые игроки'), fresh], true);
    cards.push(playersSec);

    // объявление
    const annIn = h('textarea', { class: 'input pe-bio', maxlength: 300, rows: 3, placeholder: 'Например: сегодня в 20:00 турнир 3×3, приз 1000 EC!' });
    annIn.oninput = () => { annIn.dataset.touched = '1'; };
    const annNow = h('div', { class: 'muted small', style: { marginTop: '8px' } });
    cards.push(admSection('📣', 'Объявление на главной', [
      h('div', { class: 'muted small', style: { marginBottom: '8px' } }, 'Покажется всем игрокам вверху главного экрана.'),
      annIn,
      h('div', { class: 'btns' },
        h('button', { class: 'btn xs', onclick: async () => { if (await api('/api/admin/announce', { text: annIn.value })) { toast('Объявление опубликовано', 'ok'); delete annIn.dataset.touched; loadStats(); } } }, 'Опубликовать'),
        h('button', { class: 'btn xs soft', onclick: async () => { if (await api('/api/admin/announce', { text: '' })) { annIn.value = ''; toast('Объявление убрано', 'ok'); loadStats(); } } }, 'Убрать')),
      annNow], false));

    cards.push(admSection('✈', 'Telegram-бот', tgAdminBlock(), false));
    cards.push(admSection('💾', 'Бэкапы базы', backupAdminBlock(), false));

    loadMatches();
    loadStats();
    const timer = setInterval(() => {
      if (!document.body.contains(statsCard)) { clearInterval(timer); return; }
      loadStats();
      loadMatches();
    }, 15000);
    if (!S.calm && Element.prototype.animate) {
      cards.forEach((el, i) => el.animate([{ opacity: 0, transform: 'translateY(18px)' }, { opacity: 1, transform: 'none' }], { duration: 450, delay: i * 70, easing: 'cubic-bezier(.2,.9,.3,1.15)', fill: 'backwards' }));
    }
    return cards;
  }

  // ---------- звук «Матч найден» (синтезируется, без файлов) ----------
  const Sound = {
    ctx: null,
    unlock() {
      try {
        if (!this.ctx) { const AC = window.AudioContext || window.webkitAudioContext; if (AC) this.ctx = new AC(); }
        if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
      } catch (e) { /* без звука */ }
    },
    tone(freq, start, dur, vol, type) {
      const c = this.ctx, o = c.createOscillator(), g = c.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq, c.currentTime + start);
      g.gain.setValueAtTime(0.0001, c.currentTime + start);
      g.gain.exponentialRampToValueAtTime(vol, c.currentTime + start + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + start + dur);
      o.connect(g); g.connect(c.destination);
      o.start(c.currentTime + start); o.stop(c.currentTime + start + dur + 0.05);
    },
    found() {
      if (!S.sound) return;
      this.unlock();
      if (!this.ctx) return;
      try {
        [[659, 0], [880, 0.14], [1175, 0.28], [880, 0.62], [1175, 0.76], [1568, 0.9]].forEach(([f, t]) => {
          this.tone(f, t, 0.32, 0.22, 'triangle');
          this.tone(f * 2, t, 0.18, 0.05, 'sine');
        });
      } catch (e) { /* без звука */ }
    },
    flash(dl) {
      clearInterval(this.ft);
      const base = document.title;
      let k = 0;
      this.ft = setInterval(() => {
        const L = S.st && S.st.lobby !== null ? S.st.lobbies[S.st.lobby] : null;
        if (!L || L.state !== 'accept' || now() > dl) { clearInterval(this.ft); document.title = base; return; }
        document.title = (k++ % 2) ? base : '🔥 МАТЧ НАЙДЕН — ПРИМИ!';
      }, 800);
    }
  };
  document.addEventListener('pointerdown', () => Sound.unlock(), { once: true, capture: true });

  // ---------- зима: снег и гирлянда ----------
  const Snow = {
    c: null, ctx: null, flakes: [], raf: 0, running: false, w: 0, hgt: 0, last: 0,
    start() {
      if (!this.c) {
        this.c = h('canvas', { class: 'snow' });
        document.body.append(this.c);
        this.ctx = this.c.getContext('2d');
        window.addEventListener('resize', () => { if (this.running) this.resize(); });
        document.addEventListener('visibilitychange', () => {
          if (!this.running) return;
          cancelAnimationFrame(this.raf);
          if (!document.hidden) { this.last = performance.now(); this.raf = requestAnimationFrame(t => this.loop(t)); }
        });
      }
      if (this.running) return;
      this.running = true;
      this.c.classList.remove('hidden');
      this.resize();
      this.last = performance.now();
      this.raf = requestAnimationFrame(t => this.loop(t));
    },
    stop() {
      this.running = false;
      cancelAnimationFrame(this.raf);
      if (this.c) this.c.classList.add('hidden');
    },
    resize() {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      this.w = window.innerWidth;
      this.hgt = window.innerHeight;
      this.c.width = Math.round(this.w * dpr);
      this.c.height = Math.round(this.hgt * dpr);
      this.c.style.width = this.w + 'px';
      this.c.style.height = this.hgt + 'px';
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.max(25, Math.min(110, Math.round(this.w * this.hgt / 14000)));
      while (this.flakes.length < n) this.flakes.push(this.flake(true));
      this.flakes.length = n;
    },
    flake(anyY) {
      const r = 0.9 + Math.random() * 2.6;
      return {
        x: Math.random() * this.w, y: anyY ? Math.random() * this.hgt : -6 - Math.random() * 40, r,
        vy: 16 + r * 14 + Math.random() * 18, sw: Math.random() * 6.28, sws: 0.4 + Math.random() * 0.9,
        swa: 6 + Math.random() * 22, a: 0.55 + Math.random() * 0.45
      };
    },
    loop(t) {
      if (!this.running) return;
      const dt = Math.min(0.05, (t - this.last) / 1000);
      this.last = t;
      const ctx = this.ctx;
      ctx.clearRect(0, 0, this.w, this.hgt);
      for (let i = 0; i < this.flakes.length; i++) {
        const f = this.flakes[i];
        f.y += f.vy * dt;
        f.sw += f.sws * dt;
        if (f.y > this.hgt + 6) { this.flakes[i] = this.flake(false); continue; }
        const x = f.x + Math.sin(f.sw) * f.swa;
        ctx.beginPath();
        ctx.arc(x, f.y, f.r + 1.3, 0, 6.283);
        ctx.fillStyle = 'rgba(255, 190, 200, ' + (0.07 * f.a) + ')';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(x, f.y, f.r, 0, 6.283);
        ctx.fillStyle = 'rgba(255, 255, 255, ' + f.a + ')';
        ctx.fill();
      }
      this.raf = requestAnimationFrame(tt => this.loop(tt));
    }
  };

  function buildGarland() {
    const top = $('.top');
    let g = $('#garland');
    if (!winter()) { if (g) g.remove(); return; }
    if (!g) { g = h('div', { id: 'garland', class: 'garland' }); top.append(g); }
    const w = top.clientWidth;
    if (!w) return;
    const n = Math.max(7, Math.round(w / 48));
    const step = w / n;
    const colors = ['#f43f5e', '#facc15', '#22c55e', '#38bdf8', '#a855f7'];
    let d = 'M0 3';
    let bulbs = '';
    for (let i = 0; i < n; i++) {
      const x0 = i * step, x1 = (i + 1) * step, mx = x0 + step / 2;
      d += ' Q ' + mx.toFixed(1) + ' 19 ' + x1.toFixed(1) + ' 3';
      const c = colors[i % colors.length];
      bulbs += '<g class="bulb d' + (i % 3) + '" style="color:' + c + '"><rect x="' + (mx - 2.5).toFixed(1) + '" y="8" width="5" height="4" rx="1" fill="#4b3f6b"/>' +
        '<ellipse cx="' + mx.toFixed(1) + '" cy="16.5" rx="4.5" ry="6" fill="' + c + '"/></g>';
    }
    g.innerHTML = '<svg width="' + w + '" height="28" viewBox="0 0 ' + w + ' 28"><path d="' + d + '" fill="none" stroke="#4b3f6b" stroke-width="1.6" opacity=".75"/>' + bulbs + '</svg>';
  }

  function applyLook() {
    document.body.classList.toggle('winter', winter());
    document.body.classList.toggle('calm', S.calm);
    if (winter() && S.snow && !S.calm) Snow.start(); else Snow.stop();
    buildGarland();
  }
  window.addEventListener('resize', () => { clearTimeout(applyLook.t); applyLook.t = setTimeout(buildGarland, 200); });

  // ---------- запуск ----------
  async function boot() {
    try {
      const r = await fetch('/api/meta');
      S.meta = await r.json();
    } catch (e) {
      $('#bootMsg').innerHTML = '';
      $('#bootMsg').append('Нет связи с сервером.', h('br'), h('button', { class: 'btn sm', style: { marginTop: '14px' }, onclick: () => location.reload() }, 'Повторить'));
      return;
    }
    document.title = S.meta.brand + ' FACEIT';
    try {
      const q = new URLSearchParams(location.search);
      if (/^\d+$/.test(q.get('u') || '')) S.openU = Number(q.get('u'));
      if (q.has('u')) history.replaceState(null, '', location.pathname);
    } catch (e) { /* старый браузер */ }
    applyLook();
    if (S.token) startApp(); else showAuth();
  }
  boot();
})();
