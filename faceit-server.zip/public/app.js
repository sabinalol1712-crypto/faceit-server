(() => {
  'use strict';

  // ---------- утилиты ----------
  const $ = (s, r = document) => r.querySelector(s);
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    if (props) {
      for (const k of Object.keys(props)) {
        const v = props[k];
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
        else if (k === 'svg') el.innerHTML = v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    for (const c of kids.flat(Infinity)) {
      if (c == null || c === false) continue;
      el.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  }
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { /* нет доступа */ } }
  };
  const mmss = s => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  const fmtDate = ts => { const d = new Date(ts); return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }); };
  const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20) ? b : c; };

  // ---------- состояние ----------
  const S = {
    token: store.get('etn_token', null),
    meta: null, st: null, offset: 0,
    page: 'play', es: null,
    shown: new Set(), dismissed: Number(store.get('etn_dismiss', 0)),
    mode: store.get('etn_mode', null), invTab: 'shop',
    matchMounted: null, chatLen: 0, lastAccept: null,
    modalKind: null, connOkAt: Date.now()
  };
  const now = () => Date.now() + S.offset;
  const itemById = id => (S.meta ? S.meta.catalog.find(i => i.id === id) : null);

  // ---------- сеть ----------
  async function api(path, body, method) {
    try {
      const res = await fetch(path, {
        method: method || (body === undefined ? 'GET' : 'POST'),
        headers: Object.assign({ 'Content-Type': 'application/json' }, S.token ? { Authorization: 'Bearer ' + S.token } : {}),
        body: body === undefined ? undefined : JSON.stringify(body)
      });
      let j = {};
      try { j = await res.json(); } catch (e) { j = { error: 'Сервер ответил с ошибкой (' + res.status + ')' }; }
      if (res.status === 401 && j.auth === false) { logout(true); return null; }
      if (!res.ok || j.error) { toast(j.error || 'Ошибка', 'err'); return null; }
      return j;
    } catch (e) {
      toast('Нет связи с сервером', 'err');
      return null;
    }
  }

  function connect() {
    if (S.es) S.es.close();
    const es = new EventSource('/api/events?t=' + encodeURIComponent(S.token));
    S.es = es;
    es.addEventListener('state', e => {
      const st = JSON.parse(e.data);
      S.offset = st.t - Date.now();
      S.st = st;
      S.connOkAt = Date.now();
      setConn(true);
      onState();
    });
    es.addEventListener('auth', () => { es.close(); logout(true); });
    es.onerror = () => { setConn(false); if (es.readyState === 2) setTimeout(() => { if (S.es === es && S.token) connect(); }, 2000); };
  }
  function setConn(ok) {
    const el = $('#conn');
    if (ok) { el.classList.add('hidden'); clearTimeout(setConn.t); setConn.t = null; return; }
    if (setConn.t) return;
    setConn.t = setTimeout(() => { el.classList.remove('hidden'); }, 2500);
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && S.token && (!S.es || S.es.readyState === 2)) connect();
  });

  // ---------- тосты ----------
  function toast(text, kind) {
    const el = h('div', { class: 'toast' + (kind ? ' ' + kind : '') }, text);
    $('#toasts').append(el);
    setTimeout(() => el.remove(), 3600);
    while ($('#toasts').children.length > 3) $('#toasts').firstChild.remove();
  }

  // ---------- вход ----------
  function showAuth() {
    $('#boot').classList.add('hidden');
    $('#app').classList.add('hidden');
    const root = $('#auth');
    root.classList.remove('hidden');
    let mode = 'login';
    const draw = () => {
      root.innerHTML = '';
      const nick = h('input', { class: 'input', placeholder: 'Ник', autocomplete: 'username', maxlength: 16, autocapitalize: 'off', spellcheck: 'false' });
      const pass = h('input', { class: 'input', placeholder: 'Пароль', type: 'password', autocomplete: mode === 'login' ? 'current-password' : 'new-password', maxlength: 64 });
      const pass2 = mode === 'reg' ? h('input', { class: 'input', placeholder: 'Повтори пароль', type: 'password', autocomplete: 'new-password', maxlength: 64 }) : null;
      const btn = h('button', { class: 'btn block', type: 'submit' }, mode === 'login' ? 'Войти' : 'Создать аккаунт');
      const form = h('form', {
        onsubmit: async e => {
          e.preventDefault();
          if (pass2 && pass.value !== pass2.value) return toast('Пароли не совпадают', 'err');
          btn.disabled = true;
          const r = await api(mode === 'login' ? '/api/login' : '/api/register', { nick: nick.value.trim(), pass: pass.value });
          btn.disabled = false;
          if (!r) return;
          S.token = r.token;
          store.set('etn_token', r.token);
          if (r.admin) toast('Ты первый игрок — у тебя права администратора', 'ok');
          startApp();
        }
      }, nick, pass, pass2, btn);
      root.append(
        h('div', { class: 'logo big' }, h('b', null, (S.meta && S.meta.brand) || 'ETN'), h('span', null, 'FACEIT')),
        h('div', { class: 'card' },
          h('div', { class: 'seg' },
            h('button', { type: 'button', class: mode === 'login' ? 'on' : '', onclick: () => { mode = 'login'; draw(); } }, 'Вход'),
            h('button', { type: 'button', class: mode === 'reg' ? 'on' : '', onclick: () => { mode = 'reg'; draw(); } }, 'Регистрация')),
          form,
          h('div', { class: 'hint' }, mode === 'reg' ? 'Ник — от 3 до 16 символов: буквы, цифры, _ - . Пароль — от 6 символов.' : 'Нет аккаунта? Нажми «Регистрация».'))
      );
      nick.focus();
    };
    draw();
  }

  function logout(expired) {
    if (S.token && !expired) api('/api/logout', {});
    S.token = null;
    store.set('etn_token', null);
    if (S.es) { S.es.close(); S.es = null; }
    S.st = null;
    closeModal();
    $('#accept').classList.add('hidden');
    if (expired) toast('Войди в аккаунт заново');
    showAuth();
  }

  function startApp() {
    $('#auth').classList.add('hidden');
    $('#boot').classList.add('hidden');
    $('#app').classList.remove('hidden');
    $('#brand').textContent = S.meta.brand;
    S.matchMounted = null;
    connect();
  }

  // ---------- общие элементы ----------
  const LVL_COLORS = ['#9ca3af', '#22c55e', '#22c55e', '#eab308', '#eab308', '#eab308', '#f59e0b', '#f97316', '#f97316', '#ef4444'];
  function lvl(n, big) { return h('span', { class: 'lvl' + (big ? ' big' : ''), style: { '--c': LVL_COLORS[Math.max(1, Math.min(10, n)) - 1] } }, n); }

  function ava(p, size) {
    const hue = ((p.id || 1) * 47) % 360;
    const fr = p.frame ? itemById(p.frame) : null;
    const el = h('span', { class: 'ava' + (fr ? ' framed' : '') },
      h('i', { style: { background: 'linear-gradient(135deg, hsl(' + hue + ',70%,58%), hsl(' + ((hue + 40) % 360) + ',70%,42%))' } }, (p.nick || '?')[0]));
    el.style.setProperty('--s', (size || 36) + 'px');
    if (fr) el.style.background = fr.style;
    return el;
  }
  function nick(p, extraClass) {
    const c = p.color ? itemById(p.color) : null;
    const el = h('span', { class: 'nick ellipsis' + (extraClass ? ' ' + extraClass : '') + (c && c.id === 'nick_gold' ? ' gold' : '') }, p.nick);
    if (c) el.style.color = c.style;
    return el;
  }
  const MAP_GR = [
    'linear-gradient(135deg,#0ea5e9,#1e3a8a)', 'linear-gradient(135deg,#f472b6,#7c3aed)', 'linear-gradient(135deg,#f59e0b,#b45309)',
    'linear-gradient(135deg,#22c55e,#14532d)', 'linear-gradient(135deg,#06b6d4,#0f766e)', 'linear-gradient(135deg,#a855f7,#1e1b4b)',
    'linear-gradient(135deg,#ef4444,#7f1d1d)', 'linear-gradient(135deg,#64748b,#0f172a)'
  ];
  function mapBg(name) { let s = 0; for (const ch of String(name)) s = (s * 31 + ch.charCodeAt(0)) >>> 0; return MAP_GR[s % MAP_GR.length]; }
  function countdown(dl, fmt) { return h('span', { 'data-dl': dl, 'data-fmt': fmt || '' }, '…'); }
  setInterval(() => {
    const t = now();
    document.querySelectorAll('[data-dl]').forEach(el => {
      const left = Math.max(0, Math.ceil((Number(el.dataset.dl) - t) / 1000));
      el.textContent = el.dataset.fmt === 'mm' ? mmss(left) : String(left);
    });
  }, 250);

  async function copy(text) {
    try { await navigator.clipboard.writeText(text); toast('Скопировано', 'ok'); return; } catch (e) { /* запасной способ ниже */ }
    const ta = h('textarea', { style: { position: 'fixed', opacity: '0' } });
    ta.value = text;
    document.body.append(ta);
    ta.select();
    try { document.execCommand('copy'); toast('Скопировано', 'ok'); } catch (e) { toast('Не удалось скопировать', 'err'); }
    ta.remove();
  }

  // ---------- навигация ----------
  document.querySelectorAll('.nav button').forEach(b => b.addEventListener('click', () => go(b.dataset.page)));
  $('#ecPill').addEventListener('click', () => { S.invTab = 'shop'; go('inv'); });
  function go(page) {
    S.page = page;
    S.matchMounted = null;
    window.scrollTo(0, 0);
    renderPage(true);
  }

  // ---------- обработка снимка ----------
  function onState() {
    const st = S.st;
    $('#ecVal').textContent = st.me.ec;
    for (const n of st.notes) {
      if (S.shown.has(n.id)) continue;
      S.shown.add(n.id);
      toast(n.t);
    }
    renderAccept();
    if (S.modalKind === 'party') renderPartyBody();
    renderPage(false);
  }

  function renderPage(force) {
    if (!S.st) return;
    document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('on', b.dataset.page === S.page));
    const page = $('#page');
    if (S.page === 'play') {
      if (S.st.match) {
        if (S.matchMounted !== S.st.match.id || force) mountMatch(page);
        updateMatch();
      } else {
        S.matchMounted = null;
        renderLobbies(page);
      }
    } else if (force) {
      page.innerHTML = '';
      if (S.page === 'profile') renderProfilePage(page);
      if (S.page === 'top') renderTop(page);
      if (S.page === 'inv') renderInv(page);
      if (S.page === 'more') renderMore(page);
    } else if (S.page === 'inv') {
      const sig = S.st.me.ec + '|' + S.st.me.items.join() + '|' + JSON.stringify(S.st.me.equip);
      if (sig !== S.invSig) { page.innerHTML = ''; renderInv(page); }
    } else if (S.page === 'more') {
      updateMore();
    }
  }

  // ---------- ИГРАТЬ: лобби ----------
  function renderLobbies(page) {
    const st = S.st;
    const modes = Object.keys(S.meta.modes);
    if (!S.mode || !S.meta.modes[S.mode]) S.mode = modes[0];
    const y = window.scrollY;
    page.innerHTML = '';
    page.append(h('h1', { class: 'h1' }, 'Играть'), h('div', { class: 'h1-bar' }),
      h('p', { class: 'sub' }, 'В очередях сейчас: ', h('b', null, st.queue), '   ·   онлайн: ', h('b', null, st.online)));

    if (st.recent && st.recent.id > S.dismissed) page.append(resultCard(st.recent));

    for (const inv of st.inv) {
      page.append(h('div', { class: 'card invite-card' },
        h('div', { class: 'row' }, ava(inv.from, 44),
          h('div', { class: 'grow' }, h('div', null, nick(inv.from)), h('div', { class: 'muted small' }, 'зовёт тебя в пати'))),
        h('div', { class: 'btns' },
          h('button', { class: 'btn sm', onclick: () => api('/api/party/accept', { from: inv.from.id }) }, 'Принять'),
          h('button', { class: 'btn sm soft', onclick: () => api('/api/party/decline', { from: inv.from.id }) }, 'Отклонить'))));
    }

    page.append(h('div', { class: 'modes' }, modes.map(m => h('button', {
      class: 'chip' + (m === S.mode ? ' on' : ''),
      onclick: () => { S.mode = m; store.set('etn_mode', m); renderLobbies(page); }
    }, S.meta.modes[m].title))));
    const cdLeft = st.me.cd - now();
    page.append(h('button', {
      class: 'quick', onclick: async () => {
        const r = await api('/api/quick', { mode: S.mode });
        if (r) toast('Ты в лобби #' + r.lobby, 'ok');
      }
    }, 'Быстрая игра · ' + S.meta.modes[S.mode].title, cdLeft > 0 ? h('small', null, 'пауза ', countdown(st.me.cd), ' с') : null));

    // пати
    const party = st.party;
    const pc = h('div', { class: 'card party-card' },
      h('div', { class: 'row' },
        h('div', { class: 'ico', svg: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.3-5.5 6.5-5.5s5.7 1.9 6.5 5.5"/><circle cx="16.5" cy="7" r="3"/><path d="M15.5 13.6c2.9.2 5 2 5.8 5.4"/></svg>' }),
        h('div', { class: 'grow' },
          h('div', { class: 't' }, party ? 'Твоя пати' : 'Собери пати'),
          party
            ? h('div', { class: 'party-faces' }, party.members.map(m => ava(m, 30)))
            : h('div', { class: 'd' }, 'До ' + S.meta.partyMax + ' игроков в одной команде')),
        h('button', { class: 'btn soft sm', onclick: openParty }, 'Пати')));
    page.append(pc);

    // лобби
    for (const L of st.lobbies) {
      if (L.mode !== S.mode && st.lobby !== L.i) continue;
      const mine = st.lobby === L.i;
      const filled = L.p.length > 0;
      const btn = mine
        ? h('button', { class: 'btn ghost lobby-btn', onclick: () => api('/api/lobby/leave', {}) }, 'Выйти')
        : h('button', { class: 'btn soft lobby-btn', onclick: () => api('/api/lobby/join', { i: L.i }) }, 'Войти');
      if (L.state === 'accept' && !mine) btn.disabled = true;
      const card = h('div', { class: 'card lobby' + (mine ? ' mine' : '') + (filled ? ' filled' : '') },
        h('div', { class: 'head' },
          h('div', { class: 'name' }, 'Лобби #' + L.num),
          h('div', { class: 'cnt' }, L.p.length, h('small', null, '/' + L.size)),
          btn),
        L.mode !== S.mode ? h('div', { style: { marginTop: '6px' } }, h('span', { class: 'mode-tag', style: { marginLeft: 0 } }, S.meta.modes[L.mode].title)) : null,
        filled
          ? h('div', { class: 'players' }, L.p.map(p => h('button', { class: 'pchip', onclick: () => openProfile(p.id) }, ava(p, 28), nick(p), lvl(p.lvl))))
          : h('div', { class: 'empty' }, 'Пока никого — будь первым'),
        L.state === 'accept' ? h('div', { class: 'center muted small', style: { marginTop: '12px', fontWeight: 800 } }, 'Игроки принимают матч… ', countdown(L.dl), ' с') : null,
        h('div', { class: 'segs' }, Array.from({ length: L.size }, (_, k) => h('i', { class: k < L.p.length ? 'on' : '' }))));
      page.append(card);
    }
    window.scrollTo(0, y);
  }

  function resultCard(M) {
    const me = S.st.me.id;
    let cls = '', big = 'Матч отменён', sub = 'ELO не изменилось';
    if (M.state === 'done' && M.result) {
      const myTeam = M.teams[0].some(p => p.id === me) ? 0 : 1;
      const win = M.result.winner === myTeam;
      const d = M.result.deltas[me] || 0;
      cls = win ? 'win' : 'lose';
      big = win ? 'Победа' : 'Поражение';
      sub = null;
      return h('div', { class: 'card result ' + cls },
        h('div', { class: 'muted small' }, 'Матч #' + M.id + ' · ' + (M.map || '') + ' · ' + S.meta.modes[M.mode].title),
        h('div', { class: 'big' }, big),
        h('div', { class: 'deltas' },
          h('div', null, (d >= 0 ? '+' : '') + d + ' ELO'),
          h('div', null, '+' + (win ? S.meta.rewards.win : S.meta.rewards.loss) + ' EC')),
        h('button', { class: 'btn block', onclick: dismissResult }, 'Продолжить'));
    }
    return h('div', { class: 'card result' },
      h('div', { class: 'muted small' }, 'Матч #' + M.id),
      h('div', { class: 'big' }, big),
      h('p', { class: 'muted' }, sub),
      h('button', { class: 'btn block', onclick: dismissResult }, 'Продолжить'));
    function dismissResult() { S.dismissed = M.id; store.set('etn_dismiss', String(M.id)); renderPage(true); }
  }

  // ---------- окно «Матч найден» ----------
  function renderAccept() {
    const st = S.st;
    const box = $('#accept');
    const L = st.lobby !== null ? st.lobbies[st.lobby] : null;
    if (!L || L.state !== 'accept') {
      box.classList.add('hidden');
      S.lastAccept = null;
      return;
    }
    const iAccepted = L.acc.includes(st.me.id);
    if (S.lastAccept !== L.dl) {
      S.lastAccept = L.dl;
      try { if (navigator.vibrate) navigator.vibrate([200, 100, 200]); } catch (e) { /* нет вибрации */ }
    }
    box.innerHTML = '';
    box.classList.remove('hidden');
    box.append(h('div', { class: 'sheet accept-box' },
      h('div', { class: 'muted', style: { fontWeight: 800 } }, 'Лобби #' + L.num + ' · ' + S.meta.modes[L.mode].title),
      h('div', { class: 'h1', style: { fontSize: '38px' } }, 'Матч найден'),
      h('div', { class: 'ring' }, countdown(L.dl)),
      h('div', { class: 'muted small' }, 'Приняли ' + L.acc.length + ' из ' + L.size),
      h('div', { class: 'accept-faces' }, L.p.map(p => { const a = ava(p, 46); a.classList.add(L.acc.includes(p.id) ? 'ok' : 'wait'); return a; })),
      iAccepted
        ? h('button', { class: 'btn block green', disabled: true }, 'Ждём остальных…')
        : h('button', { class: 'btn block green', style: { height: '64px', fontSize: '22px' }, onclick: () => api('/api/accept', {}) }, 'Принять'),
      h('button', { class: 'btn block ghost', style: { marginTop: '10px' }, onclick: () => api('/api/lobby/leave', {}) }, 'Отказаться')));
  }

  // ---------- комната матча ----------
  const STATUS = { veto: 'Вето карт', live: 'Идёт игра', dispute: 'Спор', done: 'Завершён', cancelled: 'Отменён' };
  function mountMatch(page) {
    const M = S.st.match;
    S.matchMounted = M.id;
    S.chatLen = -1;
    S.tSig = S.sSig = S.cSig = null;
    page.innerHTML = '';
    const chatList = h('div', { class: 'chat', id: 'mChat' });
    const chatInput = h('input', { class: 'input', placeholder: 'Сообщение команде…', maxlength: 200, id: 'mChatIn' });
    const sendChat = async () => {
      const text = chatInput.value.trim();
      if (!text) return;
      chatInput.value = '';
      await api('/api/match/chat', { text });
    };
    chatInput.addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });
    page.append(
      h('div', { class: 'card' },
        h('div', { class: 'm-head' },
          h('div', null, h('div', { class: 'm-title' }, 'Матч #' + M.id), h('div', { class: 'muted small', style: { marginTop: '6px', fontWeight: 800 } }, S.meta.modes[M.mode].title + ' · лобби #' + M.lobby)),
          h('div', { id: 'mStatus', class: 'm-status' }))),
      h('div', { id: 'mTeams', class: 'teams' }),
      h('div', { id: 'mStage' }),
      h('div', { class: 'card' },
        h('div', { class: 'section-t', style: { margin: '0 0 8px' } }, 'Чат матча'),
        chatList,
        h('div', { class: 'chat-in' }, chatInput,
          h('button', { class: 'btn', onclick: sendChat, svg: '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M3 11.5 21 3l-8.5 18-2-7.5z" fill="#fff"/></svg>' }))),
      h('div', { id: 'mCancel' }));
  }

  function updateMatch() {
    const M = S.st.match;
    const me = S.st.me.id;
    const myTeam = M.teams[0].some(p => p.id === me) ? 0 : 1;
    const isCap = M.caps[myTeam] === me;
    const st = $('#mStatus');
    st.textContent = STATUS[M.state] || M.state;
    st.className = 'm-status ' + M.state;

    // команды
    const tSig = JSON.stringify(M.teams) + myTeam;
    const teams = $('#mTeams');
    if (tSig !== S.tSig) { S.tSig = tSig; teams.innerHTML = ''; }
    else teams.dataset.keep = '1';
    if (!teams.dataset.keep) M.teams.forEach((t, k) => {
      const avg = Math.round(t.reduce((s, p) => s + p.elo, 0) / t.length);
      teams.append(h('div', { class: 'card team' + (k === myTeam ? ' me' : '') },
        h('div', { class: 'tn' }, h('span', null, 'Команда ' + 'AB'[k]), h('span', null, avg)),
        t.map(p => h('button', { class: 'tp', style: { width: '100%', textAlign: 'left' }, onclick: () => openProfile(p.id) },
          ava(p, 34),
          h('div', { class: 'grow' },
            h('div', { class: 'row', style: { gap: '4px' } }, nick(p), M.caps[k] === p.id ? h('span', { class: 'crown', title: 'капитан' }, '♛') : null),
            h('div', { class: 'elo' }, p.elo + ' ELO', M.host === p.id ? ' · хост' : '')),
          lvl(p.lvl)))));
    });

    delete teams.dataset.keep;

    // этап (перерисовывается только когда он меняется — чтобы не сбивать ввод кода)
    const stage = $('#mStage');
    const sSig = JSON.stringify([M.state, M.bans, M.turn, M.room, M.reports, M.map, M.autoAt, M.dl, isCap]);
    const prevRoom = $('#mRoomIn') ? $('#mRoomIn').value : '';
    if (sSig !== S.sSig) { S.sSig = sSig; stage.innerHTML = ''; renderStage(); }
    function renderStage() {
    if (M.state === 'veto') {
      const banned = new Set(M.bans.map(b => b.map));
      const myTurn = isCap && M.turn === myTeam;
      stage.append(h('div', { class: 'card' },
        h('div', { class: 'row' },
          h('div', { class: 'grow', style: { fontWeight: 900, fontSize: '18px' } },
            myTurn ? 'Твой ход — убери карту' : 'Банит: ' + (M.teams[M.turn].find(p => p.id === M.caps[M.turn]) || {}).nick),
          h('div', { class: 'tag dark', style: { fontSize: '14px' } }, countdown(M.dl), ' с')),
        h('div', { class: 'maps' }, M.pool.map(name => {
          const b = M.bans.find(x => x.map === name);
          return h('button', {
            class: 'map' + (b ? ' banned' : '') + (myTurn && !b ? ' can' : ''),
            style: { background: mapBg(name) },
            disabled: !myTurn || !!b,
            onclick: () => api('/api/match/veto', { map: name })
          }, h('span', null, name, b ? ' · бан ' + 'AB'[b.t] : ''));
        }))));
    } else if (M.state === 'live' || M.state === 'dispute') {
      const canRoom = M.host === me || isCap;
      const roomBlock = [];
      if (M.room) {
        roomBlock.push(h('div', { class: 'code-box' }, h('div', { class: 'grow' }, h('div', { class: 'small', style: { opacity: .7, fontWeight: 800 } }, 'КОД КОМНАТЫ'), h('b', null, M.room)),
          h('button', { class: 'btn sm', onclick: () => copy(M.room) }, 'Копировать')));
      } else {
        roomBlock.push(h('p', { class: 'muted', style: { margin: '12px 0 0', fontWeight: 700 } },
          canRoom ? 'Создай комнату в игре и отправь код сюда.' : 'Ждём, пока ' + (M.teams.flat().find(p => p.id === M.host) || {}).nick + ' создаст комнату и напишет код.'));
      }
      if (canRoom && M.state === 'live') {
        const inp = h('input', { class: 'input', placeholder: M.room ? 'Новый код комнаты' : 'Код комнаты', maxlength: 40, id: 'mRoomIn' });
        inp.value = prevRoom;
        roomBlock.push(h('div', { class: 'chat-in', style: { marginTop: '12px' } }, inp,
          h('button', { class: 'btn', style: { width: 'auto', padding: '0 18px' }, onclick: () => { if (inp.value.trim()) api('/api/match/room', { code: inp.value.trim() }).then(r => { if (r) inp.value = ''; }); } }, 'OK')));
      }
      stage.append(h('div', { class: 'card' },
        h('div', { class: 'map map-big', style: { background: mapBg(M.map) } }, h('span', null, M.map)),
        roomBlock));

      // результат
      const rep = M.reports;
      const repLine = k => {
        const capNick = (M.teams[k].find(p => p.id === M.caps[k]) || {}).nick;
        if (rep[k] === null) return h('div', { class: 'row small', style: { marginTop: '6px' } }, h('span', { class: 'tag' }, 'Капитан ' + 'AB'[k]), h('span', { class: 'muted' }, capNick + ' — ещё не отметил'));
        return h('div', { class: 'row small', style: { marginTop: '6px' } }, h('span', { class: 'tag green' }, 'Капитан ' + 'AB'[k]), h('span', null, capNick + ': победила ', h('b', null, 'команда ' + 'AB'[rep[k]])));
      };
      const resCard = h('div', { class: 'card' }, h('div', { class: 'section-t', style: { margin: '0 0 6px' } }, 'Результат'), repLine(0), repLine(1));
      if (M.state === 'dispute') {
        resCard.append(h('p', { style: { fontWeight: 800, color: '#c2410c' } }, 'Капитаны отметили разное — ждём решения администратора. Пришлите доказательства (скрин) админу.'));
      } else {
        if (M.autoAt) resCard.append(h('p', { class: 'muted small', style: { fontWeight: 700 } }, 'Если второй капитан не ответит — результат засчитается через ', countdown(M.autoAt, 'mm')));
        if (isCap) {
          resCard.append(h('div', { class: 'btns' },
            h('button', { class: 'btn green grow', onclick: () => confirmAsk('Твоя команда выиграла?', () => api('/api/match/report', { win: true })) }, 'Мы выиграли'),
            h('button', { class: 'btn red grow', onclick: () => confirmAsk('Твоя команда проиграла?', () => api('/api/match/report', { win: false })) }, 'Мы проиграли')));
        } else {
          resCard.append(h('p', { class: 'muted small', style: { fontWeight: 700 } }, 'Результат отмечают капитаны (♛). Если они согласны — ELO и EC начисляются сразу.'));
        }
      }
      stage.append(resCard);
    }
    }

    // чат
    const chat = $('#mChat');
    if (S.chatLen !== M.chat.length || chat.childElementCount !== M.chat.length) {
      const atBottom = chat.scrollHeight - chat.scrollTop - chat.clientHeight < 40;
      chat.innerHTML = '';
      for (const c of M.chat) {
        if (c.s) chat.append(h('div', { class: 'msg sys' }, c.x));
        else chat.append(h('div', { class: 'msg' + (c.u === me ? ' me' : '') }, h('b', null, c.n), c.x));
      }
      if (atBottom || S.chatLen === -1) chat.scrollTop = chat.scrollHeight;
      S.chatLen = M.chat.length;
    }

    // отмена
    const cancel = $('#mCancel');
    const cSig = M.state + JSON.stringify(M.cancel);
    if (cSig === S.cSig) return;
    S.cSig = cSig;
    cancel.innerHTML = '';
    if (M.state === 'veto' || M.state === 'live') {
      const voted = M.cancel.includes(me);
      cancel.append(h('button', {
        class: 'btn block ghost', onclick: () => api('/api/match/cancel', {})
      }, voted ? 'Убрать голос за отмену' : 'Голосовать за отмену', ' (' + M.cancel.length + '/' + M.need + ')'));
    }
  }

  function confirmAsk(text, fn) {
    openModal('confirm', 'Точно?', body => {
      body.append(h('p', { style: { fontSize: '18px', fontWeight: 700 } }, text),
        h('div', { class: 'btns' },
          h('button', { class: 'btn grow', onclick: () => { closeModal(); fn(); } }, 'Да'),
          h('button', { class: 'btn soft grow', onclick: closeModal }, 'Нет')));
    });
  }

  // ---------- модальные окна ----------
  function openModal(kind, title, fill) {
    const box = $('#modal');
    S.modalKind = kind;
    box.innerHTML = '';
    const body = h('div', { id: 'modalBody' });
    const sheet = h('div', { class: 'sheet' },
      h('div', { class: 'sheet-h' }, h('b', null, title), h('button', { class: 'x', onclick: closeModal }, '×')),
      body);
    box.append(sheet);
    box.classList.remove('hidden');
    box.onclick = e => { if (e.target === box) closeModal(); };
    fill(body);
  }
  function closeModal() { $('#modal').classList.add('hidden'); $('#modal').innerHTML = ''; S.modalKind = null; }

  function openParty() {
    openModal('party', 'Пати', body => {
      body.append(h('div', { id: 'partyList' }));
      const inp = h('input', { class: 'input', placeholder: 'Ник друга', maxlength: 16, autocapitalize: 'off' });
      const send = async () => {
        if (!inp.value.trim()) return;
        const r = await api('/api/party/invite', { nick: inp.value.trim() });
        if (r) { toast('Приглашение отправлено', 'ok'); inp.value = ''; }
      };
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
      body.append(h('div', { class: 'section-t' }, 'Позвать игрока'),
        h('div', { class: 'chat-in' }, inp, h('button', { class: 'btn', style: { width: 'auto', padding: '0 18px' }, onclick: send }, 'Позвать')),
        h('p', { class: 'muted small' }, 'В пати до ' + S.meta.partyMax + ' игроков. В лобби заходит лидер — пати попадает туда целиком и играет в одной команде.'),
        h('div', { id: 'partyLeave' }));
      renderPartyBody();
    });
  }
  function renderPartyBody() {
    const list = $('#partyList');
    if (!list) return;
    const p = S.st.party;
    const me = S.st.me.id;
    list.innerHTML = '';
    if (!p) {
      list.append(h('p', { class: 'muted', style: { fontWeight: 700 } }, 'Ты пока один. Позови друга по нику — когда он примет приглашение, вы будете в одной пати.'));
    } else {
      for (const m of p.members) {
        list.append(h('div', { class: 'row', style: { padding: '10px 0' } },
          ava(m, 42),
          h('div', { class: 'grow' }, h('div', { class: 'row', style: { gap: '6px' } }, nick(m), p.leader === m.id ? h('span', { class: 'crown' }, '♛') : null),
            h('div', { class: 'muted small' }, h('span', { class: 'online-dot' + (m.on ? ' on' : '') }), m.on ? ' в сети' : ' не в сети', ' · ', m.elo, ' ELO')),
          lvl(m.lvl),
          p.leader === me && m.id !== me ? h('button', { class: 'btn xs soft', onclick: () => api('/api/party/kick', { id: m.id }) }, 'Убрать') : null));
      }
    }
    const leave = $('#partyLeave');
    leave.innerHTML = '';
    if (p) leave.append(h('button', { class: 'btn block ghost', style: { marginTop: '12px' }, onclick: () => api('/api/party/leave', {}) }, 'Выйти из пати'));
  }

  async function openProfile(id) {
    const p = await api('/api/profile?id=' + id);
    if (!p) return;
    openModal('profile', 'Профиль', body => {
      body.append(profileCard(p, id !== S.st.me.id));
    });
  }

  // ---------- ПРОФИЛЬ ----------
  function profileCard(p, other) {
    const LV = S.meta.levels;
    const nextAt = p.lvl < 10 ? LV[p.lvl] : null;
    const curAt = LV[p.lvl - 1];
    const pct = nextAt ? Math.max(0, Math.min(100, (p.elo - curAt) / (nextAt - curAt) * 100)) : 100;
    const banner = p.banner ? itemById(p.banner) : null;
    const wr = p.matches ? Math.round(p.wins / p.matches * 100) : 0;
    const card = h('div', { class: 'card', style: { overflow: 'hidden' } },
      h('div', { class: 'banner', style: banner ? { background: banner.style } : null }),
      h('div', { class: 'p-main' }, ava(p, 92),
        h('div', { class: 'grow', style: { paddingBottom: '6px' } },
          nick(p, 'p-nick'),
          h('div', { class: 'muted small', style: { fontWeight: 800, marginTop: '4px' } }, 'ID #' + p.id, p.admin ? ' · админ' : '', p.online ? ' · в сети' : ''))),
      h('div', { class: 'elo-row' }, lvl(p.lvl, true),
        h('div', { class: 'grow' },
          h('div', { class: 'row' }, h('span', { class: 'e' }, p.elo), h('span', { class: 'muted', style: { fontWeight: 800 } }, 'ELO')),
          h('div', { class: 'prog' }, h('i', { style: { width: pct + '%' } })),
          h('div', { class: 'muted small', style: { marginTop: '4px', fontWeight: 700 } }, nextAt ? 'до ' + (p.lvl + 1) + ' уровня: ' + (nextAt - p.elo) + ' ELO' : 'максимальный уровень'))),
      h('div', { class: 'stats' },
        h('div', { class: 'stat' }, h('b', null, p.matches), h('span', null, 'Матчи')),
        h('div', { class: 'stat' }, h('b', null, p.wins), h('span', null, 'Победы')),
        h('div', { class: 'stat' }, h('b', null, wr + '%'), h('span', null, 'Винрейт')),
        h('div', { class: 'stat' }, h('b', null, p.rank ? '#' + p.rank : '—'), h('span', null, 'Место')),
        h('div', { class: 'stat' }, h('b', null, p.best), h('span', null, 'Рекорд')),
        h('div', { class: 'stat' }, h('b', null, p.streak > 0 ? p.streak + 'W' : p.streak < 0 ? -p.streak + 'L' : '0'), h('span', null, 'Серия'))));
    const wrap = h('div', null, card);
    if (other && !p.banned) wrap.append(h('button', { class: 'btn block soft', style: { marginBottom: '16px' }, onclick: async () => { const r = await api('/api/party/invite', { nick: p.nick }); if (r) toast('Приглашение отправлено', 'ok'); } }, 'Позвать в пати'));
    const hist = h('div', { class: 'card' }, h('div', { class: 'section-t', style: { margin: '0 0 4px' } }, 'Последние матчи'));
    if (!p.history.length) hist.append(h('p', { class: 'muted' }, 'Пока нет сыгранных матчей.'));
    for (const m of p.history) {
      hist.append(h('div', { class: 'hist' },
        h('div', { class: 'wl ' + (m.win ? 'w' : 'l') }, m.win ? 'W' : 'L'),
        h('div', { class: 'grow' }, h('div', { style: { fontWeight: 900 } }, m.map || '—'), h('div', { class: 'muted small' }, (S.meta.modes[m.mode] ? S.meta.modes[m.mode].title : m.mode) + ' · матч #' + m.m + ' · ' + fmtDate(m.ts))),
        h('div', { class: 'delta ' + (m.d >= 0 ? 'p' : 'n') }, (m.d >= 0 ? '+' : '') + m.d)));
    }
    wrap.append(hist);
    return wrap;
  }

  async function renderProfilePage(page) {
    page.append(h('h1', { class: 'h1' }, 'Профиль'), h('div', { class: 'h1-bar' }));
    const p = await api('/api/profile?id=' + S.st.me.id);
    if (!p || S.page !== 'profile') return;
    page.append(profileCard(p, false));
  }

  // ---------- ТОП ----------
  async function renderTop(page) {
    page.append(h('h1', { class: 'h1' }, 'Топ'), h('div', { class: 'h1-bar' }), h('p', { class: 'sub' }, 'Лучшие игроки по ELO'));
    const r = await api('/api/top');
    if (!r || S.page !== 'top') return;
    const card = h('div', { class: 'card', style: { padding: '8px' } });
    if (!r.list.length) card.append(h('p', { class: 'muted center' }, 'Пока пусто'));
    for (const p of r.list) {
      card.append(h('button', { class: 'trow' + (p.id === S.st.me.id ? ' me' : ''), style: { width: '100%', textAlign: 'left' }, onclick: () => openProfile(p.id) },
        h('div', { class: 'rk' + (p.rank <= 3 ? ' r' + p.rank : '') }, p.rank),
        ava(p, 40),
        h('div', { class: 'grow' }, nick(p), h('div', { class: 'muted small' }, p.matches + ' ' + plural(p.matches, 'матч', 'матча', 'матчей') + ' · ' + p.wins + ' ' + plural(p.wins, 'победа', 'победы', 'побед'))),
        lvl(p.lvl),
        h('div', { class: 'e' }, p.elo)));
    }
    page.append(card);
  }

  // ---------- ИНВЕНТАРЬ ----------
  const TYPES = { frame: 'Рамки аватара', color: 'Цвет ника', banner: 'Баннеры профиля' };
  function renderInv(page) {
    const me = S.st.me;
    S.invSig = me.ec + '|' + me.items.join() + '|' + JSON.stringify(me.equip);
    page.append(h('h1', { class: 'h1' }, 'Инвентарь'), h('div', { class: 'h1-bar' }),
      h('div', { class: 'seg' },
        h('button', { class: S.invTab === 'mine' ? 'on' : '', onclick: () => { S.invTab = 'mine'; go('inv'); } }, 'Мои предметы'),
        h('button', { class: S.invTab === 'shop' ? 'on' : '', onclick: () => { S.invTab = 'shop'; go('inv'); } }, 'Магазин')));
    const items = S.meta.catalog.filter(it => (S.invTab === 'mine' ? me.items.includes(it.id) : true));
    if (!items.length) {
      page.append(h('div', { class: 'card center' }, h('p', { style: { fontWeight: 700 } }, 'У тебя пока нет предметов.'),
        h('button', { class: 'btn', onclick: () => { S.invTab = 'shop'; go('inv'); } }, 'В магазин')));
      return;
    }
    for (const type of Object.keys(TYPES)) {
      const list = items.filter(it => it.type === type);
      if (!list.length) continue;
      page.append(h('div', { class: 'section-t' }, TYPES[type]));
      page.append(h('div', { class: 'items' }, list.map(it => {
        const owned = me.items.includes(it.id);
        const on = me.equip[type] === it.id;
        let pv;
        const fake = { id: me.id, nick: me.nick, frame: me.equip.frame, color: me.equip.color };
        if (type === 'frame') pv = ava(Object.assign({}, fake, { frame: it.id }), 58);
        else if (type === 'color') pv = nick(Object.assign({}, fake, { color: it.id }));
        else pv = h('div', { style: { width: '100%', height: '100%', background: it.style } });
        let btn;
        if (on) btn = h('button', { class: 'btn ghost', onclick: () => api('/api/shop/unequip', { type }) }, 'Снять');
        else if (owned) btn = h('button', { class: 'btn soft', onclick: () => api('/api/shop/equip', { id: it.id }) }, 'Надеть');
        else btn = h('button', { class: 'btn', disabled: me.ec < it.price, onclick: () => confirmAsk('Купить «' + it.name + '» за ' + it.price + ' EC?', async () => { if (await api('/api/shop/buy', { id: it.id })) toast('Куплено и надето', 'ok'); }) }, me.ec < it.price ? 'Мало EC' : 'Купить');
        return h('div', { class: 'item' + (on ? ' on' : '') },
          h('div', { class: 'pv' }, pv),
          h('div', { class: 'nm' }, it.name),
          owned ? h('div', { class: 'small muted', style: { fontWeight: 800 } }, on ? 'Надето' : 'Есть') : h('div', { class: 'pr' }, it.price + ' EC'),
          btn);
      })));
    }
  }

  // ---------- ЕЩЁ ----------
  function renderMore(page) {
    const me = S.st.me;
    page.append(h('h1', { class: 'h1' }, 'Ещё'), h('div', { class: 'h1-bar' }));
    page.append(h('div', { class: 'card' },
      h('div', { class: 'row' },
        h('div', { class: 'grow' }, h('div', { style: { fontWeight: 900, fontSize: '20px' } }, 'Ежедневный бонус'), h('div', { class: 'muted' }, '+' + S.meta.rewards.daily + ' EC раз в сутки')),
        h('button', { class: 'btn sm', id: 'dailyBtn', onclick: async () => { const r = await api('/api/daily', {}); if (r) toast('+' + r.bonus + ' EC', 'ok'); } }, 'Забрать'))));

    if (me.admin) page.append(adminCard());

    const nickIn = h('input', { class: 'input', placeholder: 'Новый ник', maxlength: 16, value: me.nick });
    const oldP = h('input', { class: 'input', type: 'password', placeholder: 'Старый пароль', autocomplete: 'current-password' });
    const newP = h('input', { class: 'input', type: 'password', placeholder: 'Новый пароль', autocomplete: 'new-password' });
    page.append(h('div', { class: 'card' },
      h('div', { class: 'section-t', style: { margin: '0 0 10px' } }, 'Аккаунт · ID #' + me.id),
      h('div', { class: 'chat-in' }, nickIn, h('button', { class: 'btn', style: { width: 'auto', padding: '0 16px' }, onclick: async () => { if (await api('/api/nick', { nick: nickIn.value.trim() })) toast('Ник изменён', 'ok'); } }, 'OK')),
      h('p', { class: 'muted small' }, 'Ник можно менять раз в сутки.'),
      h('div', { style: { display: 'grid', gap: '10px', marginTop: '6px' } }, oldP, newP,
        h('button', { class: 'btn soft', onclick: async () => { if (await api('/api/password', { old: oldP.value, pass: newP.value })) { toast('Пароль изменён', 'ok'); oldP.value = newP.value = ''; } } }, 'Сменить пароль'))));

    const m = S.meta;
    page.append(h('div', { class: 'card rules' },
      h('div', { class: 'section-t', style: { margin: '0 0 10px' } }, 'Как это работает'),
      h('p', null, '1. Зайди в лобби или нажми «Быструю игру». Когда лобби заполнится — у всех появится окно «Матч найден», на принятие ' + m.acceptSeconds + ' секунд. Кто не принял — вылетает и получает паузу.'),
      h('p', null, '2. Команды собираются автоматически по ELO, пати всегда в одной команде. Капитаны (♛) по очереди убирают карты, пока не останется одна.'),
      h('p', null, '3. Хост создаёт комнату в игре и пишет код в матч. Все заходят по коду и играют.'),
      h('p', null, '4. После игры капитаны отмечают результат. Совпало — ELO и EC начисляются сразу (победа +' + m.rewards.win + ' EC, поражение +' + m.rewards.loss + ' EC). Не совпало — решает администратор. Если второй капитан молчит ' + m.autoConfirmMinutes + ' минут, засчитывается то, что отметил первый.'),
      h('p', null, '5. Матч можно отменить, если за это проголосует больше половины игроков.')));

    page.append(h('div', { class: 'card' }, h('button', { class: 'list-btn', style: { color: '#b91c1c' }, onclick: () => logout(false) }, 'Выйти из аккаунта')));
    updateMore();
  }
  function updateMore() {
    const b = $('#dailyBtn');
    if (b) { b.disabled = !S.st.me.daily; b.textContent = S.st.me.daily ? 'Забрать' : 'Получено'; }
    const d = $('#admDisputes');
    if (d) d.textContent = S.st.disputes ? 'Спорных матчей: ' + S.st.disputes : 'Спорных матчей нет';
  }

  function adminCard() {
    const card = h('div', { class: 'card' },
      h('div', { class: 'section-t', style: { margin: '0 0 6px' } }, 'Админ-панель'),
      h('div', { id: 'admDisputes', style: { fontWeight: 900 } }));
    const mList = h('div');
    const loadMatches = async () => {
      const r = await api('/api/admin/matches');
      mList.innerHTML = '';
      if (!r) return;
      if (!r.list.length) mList.append(h('p', { class: 'muted' }, 'Активных матчей нет.'));
      for (const M of r.list) {
        mList.append(h('div', { class: 'adm-m' },
          h('div', { class: 'row' }, h('b', { class: 'grow' }, 'Матч #' + M.id + ' · ' + (S.meta.modes[M.mode] ? S.meta.modes[M.mode].title : M.mode) + ' · ' + (M.map || 'вето')), h('span', { class: 'tag' + (M.state === 'dispute' ? ' red' : '') }, STATUS[M.state])),
          h('div', { class: 'small', style: { marginTop: '6px' } }, 'A: ' + M.teams[0].map(p => p.nick).join(', ')),
          h('div', { class: 'small' }, 'B: ' + M.teams[1].map(p => p.nick).join(', ')),
          h('div', { class: 'small muted' }, 'Отметили: A → ' + (M.reports[0] === null ? '—' : 'победа ' + 'AB'[M.reports[0]]) + ', B → ' + (M.reports[1] === null ? '—' : 'победа ' + 'AB'[M.reports[1]]) + (M.room ? ' · код ' + M.room : '')),
          h('div', { class: 'btns' },
            h('button', { class: 'btn xs green', onclick: () => confirmAsk('Победа команды A в матче #' + M.id + '?', async () => { if (await api('/api/admin/resolve', { id: M.id, winner: 0 })) loadMatches(); }) }, 'Победа A'),
            h('button', { class: 'btn xs green', onclick: () => confirmAsk('Победа команды B в матче #' + M.id + '?', async () => { if (await api('/api/admin/resolve', { id: M.id, winner: 1 })) loadMatches(); }) }, 'Победа B'),
            h('button', { class: 'btn xs red', onclick: () => confirmAsk('Отменить матч #' + M.id + '?', async () => { if (await api('/api/admin/resolve', { id: M.id, winner: 'cancel' })) loadMatches(); }) }, 'Отменить'))));
      }
    };
    const q = h('input', { class: 'input', placeholder: 'Ник или ID игрока' });
    const uBox = h('div');
    const loadUser = async () => {
      if (!q.value.trim()) return;
      const u = await api('/api/admin/user?q=' + encodeURIComponent(q.value.trim()));
      uBox.innerHTML = '';
      if (!u) return;
      const amount = h('input', { class: 'input', type: 'number', placeholder: 'EC (+/−)', style: { height: '44px' } });
      const elo = h('input', { class: 'input', type: 'number', placeholder: 'ELO', style: { height: '44px' } });
      uBox.append(h('div', { class: 'kv' },
        h('span', null, 'Игрок'), h('b', null, u.nick + ' · ID #' + u.id + (u.online ? ' · в сети' : '')),
        h('span', null, 'ELO / EC'), h('b', null, u.elo + ' / ' + u.ec),
        h('span', null, 'Матчи'), h('b', null, u.matches + ' (побед ' + u.wins + ')'),
        h('span', null, 'Статус'), h('b', null, (u.banned ? 'заблокирован' : 'активен') + (u.admin ? ', админ' : ''))),
      h('div', { class: 'chat-in' }, amount, h('button', { class: 'btn sm', style: { width: 'auto' }, onclick: async () => { if (await api('/api/admin/ec', { id: u.id, amount: Number(amount.value) })) { toast('Готово', 'ok'); loadUser(); } } }, 'EC')),
      h('div', { class: 'chat-in', style: { marginTop: '8px' } }, elo, h('button', { class: 'btn sm', style: { width: 'auto' }, onclick: async () => { if (await api('/api/admin/elo', { id: u.id, elo: Number(elo.value) })) { toast('Готово', 'ok'); loadUser(); } } }, 'ELO')),
      h('div', { class: 'btns' },
        h('button', { class: 'btn xs ' + (u.banned ? 'green' : 'red'), onclick: () => confirmAsk((u.banned ? 'Разблокировать ' : 'Заблокировать ') + u.nick + '?', async () => { if (await api('/api/admin/ban', { id: u.id, on: !u.banned })) loadUser(); }) }, u.banned ? 'Разблокировать' : 'Заблокировать'),
        h('button', { class: 'btn xs soft', onclick: () => confirmAsk((u.admin ? 'Снять права админа с ' : 'Сделать админом ') + u.nick + '?', async () => { if (await api('/api/admin/admin', { id: u.id, on: !u.admin })) loadUser(); }) }, u.admin ? 'Снять админа' : 'Сделать админом')));
    };
    q.addEventListener('keydown', e => { if (e.key === 'Enter') loadUser(); });
    card.append(
      h('div', { class: 'section-t' }, 'Активные матчи'),
      h('button', { class: 'btn xs soft', onclick: loadMatches }, 'Обновить'), mList,
      h('div', { class: 'section-t' }, 'Игрок'),
      h('div', { class: 'chat-in' }, q, h('button', { class: 'btn', style: { width: 'auto', padding: '0 16px' }, onclick: loadUser }, 'Найти')), uBox);
    loadMatches();
    return card;
  }

  // ---------- запуск ----------
  async function boot() {
    try {
      const r = await fetch('/api/meta');
      S.meta = await r.json();
    } catch (e) {
      $('#bootMsg').innerHTML = '';
      $('#bootMsg').append('Нет связи с сервером.', h('br'), h('button', { class: 'btn sm', style: { marginTop: '14px' }, onclick: () => location.reload() }, 'Повторить'));
      return;
    }
    document.title = S.meta.brand + ' FACEIT';
    if (S.token) startApp(); else showAuth();
  }
  boot();
})();
