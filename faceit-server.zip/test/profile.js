'use strict';
// Тест профиля: аватары (загрузка, проверка, отдача, удаление), «О себе», ID в игре, статистика по картам.
// Запуск: node test/profile.js
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');
const PORT = 20100 + Math.floor(Math.random() * 300);
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'faceit-prof-'));
const CFG = path.join(DATA, 'config.json');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
Object.assign(cfg, { acceptSeconds: 5, vetoSeconds: 30 });
fs.writeFileSync(CFG, JSON.stringify(cfg));

let proc;
function start() {
  return new Promise((resolve, reject) => {
    proc = spawn(process.execPath, [path.join(ROOT, 'server.js')], { env: Object.assign({}, process.env, { PORT: String(PORT), DATA_DIR: DATA, CONFIG: CFG, FACEIT_TEST: '1' }), stdio: ['ignore', 'pipe', 'pipe'] });
    proc.stderr.on('data', d => process.stderr.write('[server] ' + d));
    proc.stdout.on('data', d => { if (String(d).includes('запущен')) resolve(); });
    proc.on('exit', c => { if (c) reject(new Error('exit ' + c)); });
  });
}
async function call(method, p, body, token) {
  const res = await fetch('http://127.0.0.1:' + PORT + p, { method, headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}), body: body ? JSON.stringify(body) : undefined });
  return Object.assign(await res.json(), { status: res.status });
}
const post = (p, b, t) => call('POST', p, b, t);
const get = (p, t) => call('GET', p, null, t);
async function ok(pr, what) { const r = await pr; if (!r.ok) throw new Error((what || '') + ' → ' + r.status + ' ' + r.error); return r; }
async function bad(pr, re) { const r = await pr; assert(!r.ok, 'ожидалась ошибка ' + re); if (re) assert(re.test(r.error), r.error); return r; }
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, what, ms = 6000) { const t = Date.now(); while (Date.now() - t < ms) { try { if (fn()) return; } catch (_) {} await sleep(30); } throw new Error('не дождались: ' + what); }
function stream(token) {
  const s = { state: null, notes: [] };
  s.req = http.get('http://127.0.0.1:' + PORT + '/api/events?t=' + token, res => {
    let buf = '';
    res.setEncoding('utf8');
    res.on('data', ch => {
      buf += ch;
      let k;
      while ((k = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, k); buf = buf.slice(k + 2);
        const line = block.split('\n').find(l => l.startsWith('data: '));
        if (block.includes('event: state') && line) {
          s.state = JSON.parse(line.slice(6));
          for (const n of s.state.notes) if (!s.notes.some(x => x.id === n.id)) s.notes.push(n);
        }
      }
    });
  });
  s.req.on('error', () => {});
  return s;
}


const FIX = {"webp": "UklGRjoCAABXRUJQVlA4IC4CAADwDQCdASpAAEAAPl0kjkWjoiEc/iQAOAXEtABkwuBs/wk+l/krz7ByOcBtgPMB+s3U584DqAPQA6UfAN5piYTxwf8g/w3qM/2TqjfsB7AH6uLTvMNvaPvRPVuoxoUDNaoW0pgpA0NyouLxkRY5QVjHVxJ8pJbZYgAA/vFNr4ZflgT/++gG9AN6AfwXWLDjskAjgJ7I/rQf9ENvpPgQhbDmNda0Ey0O+5LL0feCwz2W5Vb0LvKGkJqwRuVW9C7+Hs546qjsWR84MlGaOorisWqW52LMUXZUPnDZkpT4WtJgBH/f/F6H3s8dNzXWQHf9/8Xofe7N3VWU/IRZ3rHO3dWAVmYwFuvR1X+Zrz6sOIe8+rHjf77V/5PMPu/3g3BsuiNQos/PeDcGzoYvVT6T3LA+AxCjRbku/E/dOUdg55UepxC0D+898MZUVgs2kFLQ1cI1iyaXNeHvzf8++6XDCDoSKXM8yXiP81cxJ4F5pdAfluuPaWqcrtNwvp2N7gcwIhcsnOPnTrGRHie7/8upZkkKWGehSP3f/l1LfCpgBFDqc3BK8YHMAI1Qlv9kCl/+/lCVbyk3qAdudxRl3u2KvGC89uMdWynIaKETgShzsdfMjDeW2yPML0iq7kP/anDEYvi3mlU5fpCjPy44onfbFeOwtgt3oVlPu70ITkroiWguj7Jlx5IYTpNrvrUPkQFxiHTdP2dx1hAbm/nVMVwuYSQhTPZ50psP9lE9+e+NwAA=", "webpl": "UklGRoQAAABXRUJQVlA4THgAAAAvP8APAA9wIe4n/x8Ke/5jCY5i24qjm3mJBKQgLUhDChJYpse3ePTcAiL6PwH6x6H2BjoJDovQbINiE2QbAAO4S7tdpWTHM9GaFKy+Y7PyjsnyP9isvCNYfUe0JiU7ntntKsnukgZAkibItkGxCM0SHKYBdUPt/Uk=", "png": "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAABQ0lEQVR4Xu2ayw3CMBBEDaIOznTAncI5QweUg5ClHIiIZ2bXrK3sK2A+GUegJIfH+VJm5jhz+A9ZIJpcIJpcIJpcIJpTjwDX+89f9+ft5et4cPwrsZF7jVcThwJUbvcm1pvYmL4Uq4K+gD36F9qhEhdwTy9PoRTokb4iKNMFBA8KVp8rwKprUC5EAUrXCO5FFBgTtAB+SbwAHaECoJY7iC9UYGR2UADZsR9N9x0sMDiNBZoL/oHtDHmEoskFoskFoskFomksoD3q8GU7Qx6haNoLxJ6ipnu7wODso0Bzx04gvugCiJYvoCNaYFiIAuAlcQH3IgqUQuhawNMrX6tQ6gKsPrdAhfXAEZSVAp06COlLMbzkq7g8d9GiV8QFFizeLgdSf826hlrD3rziWWBh1m8lQrDeA+FkgWhygWhygWimX+ANw21Z6+ZekEsAAAAASUVORK5CYII=", "jpeg": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABAAEADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDgqKKK8Q/YAorrPB3gbUfEm2f/AI9NOO4faXXduI7KuQTz34HB5yMV6XpXwv0C0ixerPfylVy0khQAjqVCYwD6EnoOfXhr5hQoPlbu/I4cRmNCg+WTu+yPCKK98vvhn4buYgkNvPaMGzvhnYkj0+fcMfhnivOvFvw61HQrc3VrJ/aFmiF5pETY0WD3XJJGOcjOMHOAMmaGZUKz5U7PzJoZnQrPlTs/M4iiiivQPQCus+HHhj/hJNa/0lc6da4e4w+0tnO1R35I56cA8g4rk693+DmnR2nhBbobWlvZXkZgmCApKBSe4+Un/gR/HhzCu6FBuO70OHMcQ6FByju9EdvDFHDEkUKLHEihURBgKBwAB2FPoor5E+OCiiigDw34r+E49FvU1LToVi065bayK3EcvJwF7KQMjGcEHoMCuAr6N+IunR6l4N1NH2hoYjcIxTcVKfNx6EgFc+jH6V85V9VlmIdajaW60PrcrxDrUbS3WgV758ILuO58EW8SBg1rLJC+RwSW38e2HH45rwOu3+FPiSLQtaktrwxR2d9tV5nJHlMu7ac9MEsQc9Mg5ABzWZUHWoNR3WpWZ0HWoNR3Wp71RRRXyZ8gFFFFAGD49u47LwbrEsoYq1u0I2jnL/IPwywz7V82V6b8ZfEkV5cRaJaGKSO2cSzyqSSJQGXZ6cAnPXk44wa8yr6nKqDpUby3ep9XlNB0qN5by1CiiivTPUO/8EfEa50WKGx1VGutOjUhGTmaMfwgZIBUdMHkZ64AFenaV438PalFvj1OCBgqlkuW8kqT2+bAJHfaSP0r5yorzcRllGs+ZaPyPNxGV0az5lo/I+k77xj4esohJNrFmyltuIZPOOfomTjjr0rznxb8UZby3Nt4filtY5EKyTzACUEn+DBIHHfk88YxmvMqKVDKqNJ8z1fmTQymjSfNL3n5hRRRXpnqH//Z"};
const img = k => Buffer.from(FIX[k], 'base64');
async function upload(buf, token, type) {
  const res = await fetch('http://127.0.0.1:' + PORT + '/api/avatar', { method: 'POST', headers: Object.assign({ 'Content-Type': type || 'image/webp' }, token ? { Authorization: 'Bearer ' + token } : {}), body: buf });
  return Object.assign(await res.json(), { status: res.status });
}
async function raw(p) {
  const res = await fetch('http://127.0.0.1:' + PORT + p);
  return { status: res.status, type: res.headers.get('content-type'), cache: res.headers.get('cache-control'), nosniff: res.headers.get('x-content-type-options'), buf: Buffer.from(await res.arrayBuffer()) };
}

(async () => {
  await start();
  const names = ['Admin', 'Ava1', 'Pl2', 'Pl3', 'Pl4', 'Pl5'];
  const U = {};
  for (const n of names) { const r = await ok(post('/api/register', { nick: n, pass: 'secret12' })); U[n] = { token: r.token, id: r.id }; U[n].s = stream(r.token); }
  await until(() => names.every(n => U[n].s.state), 'потоки');

  // --- аватары
  const { probe } = require('../lib/avatars');
  assert.deepStrictEqual(probe(img('webp')), { ext: 'webp', w: 64, h: 64 });
  assert.deepStrictEqual(probe(img('webpl')), { ext: 'webp', w: 64, h: 64 });
  assert.deepStrictEqual(probe(img('png')), { ext: 'png', w: 64, h: 64 });
  assert.deepStrictEqual(probe(img('jpeg')), { ext: 'jpg', w: 64, h: 64 });
  await bad(upload(img('png'), null), /Войди/);
  await bad(upload(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>' + ' '.repeat(40)), U.Ava1.token, 'image/svg+xml'), /JPG, PNG или WebP/);
  const huge = Buffer.from(img('png')); huge.writeUInt32BE(5000, 16);
  await bad(upload(huge, U.Ava1.token), /1024/);
  await bad(upload(Buffer.alloc(500 * 1024, 1), U.Ava1.token), /400 КБ/);
  const up = await ok(upload(img('webp'), U.Ava1.token), 'webp');
  assert(/^\/avatars\/\d+-[a-f0-9]{10}\.webp$/.test(up.av), up.av);
  const f = await raw(up.av);
  assert.strictEqual(f.status, 200);
  assert.strictEqual(f.type, 'image/webp');
  assert(/immutable/.test(f.cache) && f.nosniff === 'nosniff');
  assert(f.buf.equals(img('webp')));
  assert.strictEqual((await raw('/avatars/../config.json')).status, 404);
  assert.strictEqual((await raw('/avatars/1-zzzz.webp')).status, 404);
  await until(() => U.Pl2.s.state && U.Ava1.s.state.me && true, 'снимок');
  const top = await ok(get('/api/top', U.Pl2.token));
  assert.strictEqual(top.list.find(x => x.id === U.Ava1.id).av, up.av, 'аватар виден другим в топе');
  // замена: старый файл удаляется
  const up2 = await ok(upload(img('jpeg'), U.Ava1.token, 'image/jpeg'), 'jpeg');
  assert(up2.av.endsWith('.jpg'));
  assert.strictEqual((await raw(up.av)).status, 404, 'старый аватар удалён');
  assert.strictEqual((await raw(up2.av)).type, 'image/jpeg');
  await ok(post('/api/avatar/remove', {}, U.Ava1.token));
  assert.strictEqual((await raw(up2.av)).status, 404);
  assert.strictEqual((await ok(get('/api/profile?id=' + U.Ava1.id, U.Pl2.token))).av, undefined);
  console.log('✓ аватары: проверка формата и размера, отдача, замена и удаление');

  // --- о себе и ID в игре
  await ok(post('/api/profile/edit', { bio: '  Играю за опорников\n\n\n\nпиши в тг  ', rid: ' 1234567 ' }, U.Ava1.token));
  let pr = await ok(get('/api/profile?id=' + U.Ava1.id, U.Pl2.token));
  assert.strictEqual(pr.bio, 'Играю за опорников\n\nпиши в тг');
  assert.strictEqual(pr.rid, '1234567');
  await bad(post('/api/profile/edit', { bio: 'x'.repeat(141) }, U.Ava1.token), /140/);
  await bad(post('/api/profile/edit', { rid: '<script>' }, U.Ava1.token), /ID в игре/);
  await ok(post('/api/profile/edit', { rid: 'Kotik_Pro#77' }, U.Ava1.token));
  // админ убирает аватар и «О себе»
  await ok(upload(img('png'), U.Ava1.token, 'image/png'), 'png');
  await bad(post('/api/admin/avatar', { id: U.Ava1.id }, U.Pl2.token), /администратор/i);
  await ok(post('/api/admin/avatar', { id: U.Ava1.id, bio: true }, U.Admin.token));
  pr = await ok(get('/api/profile?id=' + U.Ava1.id, U.Pl2.token));
  assert.strictEqual(pr.av, undefined); assert.strictEqual(pr.bio, ''); assert.strictEqual(pr.rid, 'Kotik_Pro#77');
  await until(() => U.Ava1.s.notes.some(n => /удалил твой аватар/.test(n.t)), 'уведомление');
  console.log('✓ «О себе», ID в игре, модерация аватара админом');

  // --- статистика по картам, лучшая серия, ID в игре виден в матче
  await ok(upload(img('webpl'), U.Pl3.token), 'p3');
  const four = ['Ava1', 'Pl2', 'Pl3', 'Pl4'];
  for (let g = 0; g < 2; g++) {
    for (const n of four) await ok(post('/api/lobby/join', { i: 3 }, U[n].token), 'join ' + n);
    await until(() => U.Ava1.s.state.lobbies[3].state === 'accept', 'accept');
    for (const n of four) await ok(post('/api/accept', {}, U[n].token));
    await until(() => U.Ava1.s.state.match, 'матч');
    const M = U.Ava1.s.state.match;
    const all = M.teams.flat();
    assert(all.find(p => p.id === U.Ava1.id).rid === 'Kotik_Pro#77', 'ID в игре в матче');
    assert(all.find(p => p.id === U.Pl3.id).av, 'аватар в матче');
    const tok = Object.fromEntries(Object.values(U).map(x => [x.id, x.token]));
    for (let k = 0; k < M.pool.length - 1; k++) {
      const cur = U.Ava1.s.state.match;
      const left = cur.pool.filter(m => !cur.bans.some(b => b.map === m));
      await ok(post('/api/match/veto', { map: left[g] }, tok[cur.caps[cur.turn]]), 'veto');
      await until(() => U.Ava1.s.state.match.bans.length === k + 1, 'бан ' + k);
    }
    await until(() => U.Ava1.s.state.match.state === 'live', 'live');
    const tm = M.teams.findIndex(t => t.some(p => p.id === U.Ava1.id));
    await ok(post('/api/admin/resolve', { id: M.id, winner: tm }, U.Admin.token));
    await until(() => !U.Ava1.s.state.match, 'конец матча');
  }
  pr = await ok(get('/api/profile?id=' + U.Ava1.id, U.Pl2.token));
  const played = Object.entries(pr.maps);
  assert.strictEqual(played.reduce((s, [, r]) => s + r[0] + r[1], 0), 2);
  assert.strictEqual(played.reduce((s, [, r]) => s + r[0], 0), 2);
  assert.strictEqual(pr.bestStreak, 2);
  assert.strictEqual(pr.history.length, 2);
  assert(pr.history.every(h => cfg.modes['2x2'].maps.includes(h.map)));
  assert.strictEqual(typeof pr.items, 'number');
  assert.strictEqual(pr.tg, false);
  console.log('✓ статистика по картам и лучшая серия');

  // --- всё на месте после перезапуска
  proc.kill('SIGTERM');
  await new Promise(r => proc.on('exit', r));
  await start();
  pr = await ok(get('/api/profile?id=' + U.Pl3.id, U.Pl2.token));
  assert(pr.av && (await raw(pr.av)).status === 200, 'аватар после перезапуска');
  assert.strictEqual((await ok(get('/api/profile?id=' + U.Ava1.id, U.Pl2.token))).bestStreak, 2);
  console.log('✓ после перезапуска аватары и статистика на месте');

  console.log('\nПРОФИЛЬ: ВСЕ ТЕСТЫ ПРОЙДЕНЫ');
  proc.kill('SIGTERM');
  process.exit(0);
})().catch(e => { console.error('ОШИБКА:', e); try { proc.kill('SIGTERM'); } catch (_) {} process.exit(1); });
