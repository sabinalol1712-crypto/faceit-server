'use strict';
// Тест главного экрана, заданий дня, новых вкладок топа и админ-сводки.
// Запуск: node test/home.js
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');
const PORT = 20500 + Math.floor(Math.random() * 300);
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'faceit-home-'));
const CFG = path.join(DATA, 'config.json');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
Object.assign(cfg, { acceptSeconds: 5, vetoSeconds: 30 });
fs.writeFileSync(CFG, JSON.stringify(cfg));

let proc;
function start() {
  return new Promise((resolve, reject) => {
    proc = spawn(process.execPath, [path.join(ROOT, 'server.js')], { env: Object.assign({}, process.env, { PORT: String(PORT), DATA_DIR: DATA, CONFIG: CFG, FACEIT_TEST: '1' }), stdio: ['ignore', 'pipe', 'pipe'] });
    proc.stderr.on('data', d => process.stderr.write('[server] ' + d));
    proc.stdout.on('data', d => { if (String(d).includes('запущен')) resolve(); });
    proc.on('exit', c => { if (c) reject(new Error('exit ' + c)); });
  });
}
async function call(method, p, body, token) {
  const res = await fetch('http://127.0.0.1:' + PORT + p, { method, headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}), body: body ? JSON.stringify(body) : undefined });
  return Object.assign(await res.json(), { status: res.status });
}
const post = (p, b, t) => call('POST', p, b, t);
const get = (p, t) => call('GET', p, null, t);
async function ok(pr, what) { const r = await pr; if (!r.ok) throw new Error((what || '') + ' → ' + r.status + ' ' + r.error); return r; }
async function bad(pr, re) { const r = await pr; assert(!r.ok, 'ожидалась ошибка ' + re); if (re) assert(re.test(r.error), r.error); return r; }
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, what, ms = 6000) { const t = Date.now(); while (Date.now() - t < ms) { try { if (fn()) return; } catch (_) {} await sleep(30); } throw new Error('не дождались: ' + what); }
function stream(token) {
  const s = { state: null, notes: [] };
  s.req = http.get('http://127.0.0.1:' + PORT + '/api/events?t=' + token, res => {
    let buf = '';
    res.setEncoding('utf8');
    res.on('data', ch => {
      buf += ch;
      let k;
      while ((k = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, k); buf = buf.slice(k + 2);
        const line = block.split('\n').find(l => l.startsWith('data: '));
        if (block.includes('event: state') && line) {
          s.state = JSON.parse(line.slice(6));
          for (const n of s.state.notes) if (!s.notes.some(x => x.id === n.id)) s.notes.push(n);
        }
      }
    });
  });
  s.req.on('error', () => {});
  return s;
}



(async () => {
  await start();
  const names = ['Admin', 'Pa1', 'Pb1', 'Pc1'];
  const U = {};
  for (const n of names) { const r = await ok(post('/api/register', { nick: n, pass: 'secret12' })); U[n] = { token: r.token, id: r.id }; U[n].s = stream(r.token); }
  await until(() => names.every(n => U[n].s.state), 'потоки');
  const st = () => U.Pa1.s.state;

  // главный экран: общие данные
  await until(() => st().home && st().home.players === 4, 'игроков 4');
  const home = st().home;
  assert(home && Array.isArray(home.live) && Array.isArray(home.feed) && Array.isArray(home.leaders), 'home');
  assert(cfg.modes['2x2'].maps.includes(home.mapDay) || cfg.modes['3x3'].maps.includes(home.mapDay), 'карта дня');
  assert.strictEqual(st().me.quests.length, 3);
  assert(st().me.quests.every(q => q.v === 0 && !q.got));
  await bad(post('/api/quest', { id: 'win' }, U.Pa1.token), /не выполнено/);
  await bad(post('/api/quest', { id: 'zzz' }, U.Pa1.token), /Нет такого/);
  console.log('✓ главный экран: данные и задания дня');

  // играем 2 матча 2×2: первый на карте дня
  const tok = Object.fromEntries(Object.values(U).map(x => [x.id, x.token]));
  const four = ['Pa1', 'Pb1', 'Pc1', 'Admin'];
  for (let g = 0; g < 2; g++) {
    for (const n of four) await ok(post('/api/lobby/join', { i: 3 }, U[n].token), 'join');
    await until(() => st().lobbies[3].state === 'accept', 'accept');
    for (const n of four) await ok(post('/api/accept', {}, U[n].token));
    await until(() => st().match, 'матч');
    assert(st().home.live.some(m => m.id === st().match.id), 'матч виден в «Сейчас играют»');
    const M = st().match;
    const keep = g === 0 ? st().home.mapDay : M.pool.find(m => m !== st().home.mapDay);
    for (let k = 0; k < M.pool.length - 1; k++) {
      const cur = st().match;
      const left = cur.pool.filter(m => !cur.bans.some(b => b.map === m) && m !== keep);
      await ok(post('/api/match/veto', { map: left[0] }, tok[cur.caps[cur.turn]]), 'veto');
      await until(() => st().match.bans.length === k + 1, 'бан');
    }
    await until(() => st().match.state === 'live', 'live');
    assert.strictEqual(st().match.map, keep);
    const tm = M.teams.findIndex(t => t.some(p => p.id === U.Pa1.id));
    await ok(post('/api/admin/resolve', { id: M.id, winner: tm }, U.Admin.token));
    await until(() => !st().match, 'конец');
  }
  await until(() => st().home.feed.length === 2, 'лента');
  assert(st().home.feed[0].w.some(p => p.id === U.Pa1.id), 'победители в ленте');
  assert.strictEqual(st().home.today, 2);
  assert.strictEqual(st().home.live.length, 0);
  assert.strictEqual(st().home.leaders[0].id, U.Pa1.id === st().home.leaders[0].id ? U.Pa1.id : st().home.leaders[0].id);
  assert.strictEqual(st().me.form, 'WW');
  const q = Object.fromEntries(st().me.quests.map(x => [x.id, x]));
  assert.deepStrictEqual([q.play.v, q.win.v, q.map.v], [2, 1, 1]);
  const ec0 = st().me.ec;
  for (const id of ['play', 'win', 'map']) await ok(post('/api/quest', { id }, U.Pa1.token));
  await bad(post('/api/quest', { id: 'play' }, U.Pa1.token), /уже получена/);
  await until(() => st().me.ec === ec0 + 150 && st().me.quests.every(x => x.got), 'награды');
  console.log('✓ задания дня: прогресс, карта дня, награды один раз');

  // топ: новые вкладки
  const wr = await ok(get('/api/top?by=wr', U.Pa1.token));
  assert.strictEqual(wr.list.length, 0, 'винрейт только от 5 матчей');
  const wk = await ok(get('/api/top?by=week', U.Pa1.token));
  assert.strictEqual(wk.list.length, 4);
  assert(wk.list[0].wk > 0 && wk.list[3].wk < 0);
  assert.strictEqual(wk.list.find(p => p.id === U.Pa1.id).form, 'WW');
  const elo = await ok(get('/api/top', U.Pa1.token));
  assert.strictEqual(elo.by, 'elo');
  assert(typeof elo.list[0].on === 'boolean' && typeof elo.list[0].wr === 'number');
  console.log('✓ топ: ELO, неделя, винрейт');

  // админка: сводка и объявление
  await bad(get('/api/admin/stats', U.Pa1.token), /администратор/i);
  const s = await ok(get('/api/admin/stats', U.Admin.token));
  assert.strictEqual(s.users, 4); assert.strictEqual(s.today, 2); assert.strictEqual(s.newToday, 4);
  assert.strictEqual(s.days.length, 7); assert.strictEqual(s.days[6].m, 2);
  assert.strictEqual(s.onlineList.length, 4); assert.strictEqual(s.fresh.length, 4);
  await bad(post('/api/admin/announce', { text: 'x' }, U.Pa1.token), /администратор/i);
  await bad(post('/api/admin/announce', { text: 'x'.repeat(301) }, U.Admin.token), /300/);
  await ok(post('/api/admin/announce', { text: '  Турнир в 20:00!  ' }, U.Admin.token));
  await until(() => st().home.announce && st().home.announce.t === 'Турнир в 20:00!', 'объявление у игроков');
  await ok(post('/api/admin/announce', { text: '' }, U.Admin.token));
  await until(() => st().home.announce === null, 'объявление убрано');
  console.log('✓ админка: сводка, неделя, объявление');

  console.log('\nГЛАВНАЯ, ТОП, АДМИНКА: ВСЕ ТЕСТЫ ПРОЙДЕНЫ');
  proc.kill('SIGTERM');
  process.exit(0);
})().catch(e => { console.error('ОШИБКА:', e); try { proc.kill('SIGTERM'); } catch (_) {} process.exit(1); });
