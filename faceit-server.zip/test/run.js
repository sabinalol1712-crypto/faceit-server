'use strict';
// Автотест: поднимает сервер на временной папке и проходит полный цикл — регистрация, пати, лобби,
// принятие, вето, код комнаты, чат, результат, ELO/EC, отказ от матча, спор и админка, отмена, магазин, перезапуск.
// Запуск: node test/run.js
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');
const PORT = 18000 + Math.floor(Math.random() * 1000);
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'faceit-test-'));
const CFG = path.join(DATA, 'config.json');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
Object.assign(cfg, { acceptSeconds: 3, vetoSeconds: 2, declineCooldownSeconds: 5 });
fs.writeFileSync(CFG, JSON.stringify(cfg));

let proc = null;
function start() {
  return new Promise((resolve, reject) => {
    proc = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
      env: Object.assign({}, process.env, { PORT: String(PORT), DATA_DIR: DATA, CONFIG: CFG, FACEIT_TEST: '1' }),
      stdio: ['ignore', 'pipe', 'pipe']
    });
    proc.stderr.on('data', d => process.stderr.write('[server] ' + d));
    proc.stdout.on('data', d => { if (String(d).includes('запущен')) resolve(); });
    proc.on('exit', code => { if (code) reject(new Error('server exit ' + code)); });
  });
}
function stopServer() {
  return new Promise(r => { proc.once('exit', r); proc.kill('SIGTERM'); });
}

async function call(method, p, body, token) {
  const res = await fetch('http://127.0.0.1:' + PORT + p, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined
  });
  const j = await res.json();
  return Object.assign(j, { status: res.status });
}
const post = (p, b, t) => call('POST', p, b, t);
const get = (p, t) => call('GET', p, null, t);
async function ok(promise, what) {
  const r = await promise;
  if (!r.ok) throw new Error((what || '') + ' → ' + r.status + ' ' + r.error);
  return r;
}
async function bad(promise, re) {
  const r = await promise;
  assert(!r.ok, 'ожидалась ошибка ' + re);
  if (re) assert(re.test(r.error), 'ошибка "' + r.error + '" не совпала с ' + re);
  return r;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

// SSE-клиент: хранит последний снимок
function stream(token) {
  const s = { state: null, notes: [], req: null, closedAuth: false };
  s.req = http.get('http://127.0.0.1:' + PORT + '/api/events?t=' + token, res => {
    let buf = '';
    res.setEncoding('utf8');
    res.on('data', ch => {
      buf += ch;
      let k;
      while ((k = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, k);
        buf = buf.slice(k + 2);
        let ev = 'message', data = '';
        for (const line of block.split('\n')) {
          if (line.startsWith('event: ')) ev = line.slice(7);
          else if (line.startsWith('data: ')) data += line.slice(6);
        }
        if (ev === 'state') {
          s.state = JSON.parse(data);
          for (const n of s.state.notes) if (!s.notes.some(x => x.id === n.id)) s.notes.push(n);
        }
        if (ev === 'auth') s.closedAuth = true;
      }
    });
  });
  s.req.on('error', () => {});
  return s;
}
async function until(fn, what, ms = 4000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try { if (fn()) return; } catch (_) {}
    await sleep(25);
  }
  throw new Error('не дождались: ' + what);
}

(async () => {
  await start();
  const names = ['Admin', 'Bober', 'Kotik', 'Sasha_1', 'Мирон', 'Dima.K', 'Lena', 'Oleg', 'Petya', 'Roma'];
  const U = {};
  // --- регистрация и вход
  for (const n of names) {
    const r = await ok(post('/api/register', { nick: n, pass: 'secret12' }), 'register ' + n);
    U[n] = { token: r.token, id: r.id };
  }
  assert.strictEqual(U.Admin.id, 1);
  await bad(post('/api/register', { nick: 'admin', pass: 'secret12' }), /занят/);
  await bad(post('/api/register', { nick: 'ab', pass: 'secret12' }), /Ник/);
  await bad(post('/api/register', { nick: 'Good', pass: '123' }), /Пароль/);
  await bad(post('/api/login', { nick: 'Bober', pass: 'wrong!!' }), /Неверный/);
  const lg = await ok(post('/api/login', { nick: 'bober', pass: 'secret12' }));
  assert(lg.token);
  await bad(get('/api/top'), /Войди/);
  console.log('✓ регистрация и вход');

  for (const n of names) U[n].s = stream(U[n].token);
  await until(() => names.every(n => U[n].s.state), 'снимки');
  assert.strictEqual(U.Admin.s.state.me.admin, true);
  assert.strictEqual(U.Bober.s.state.me.admin, false);
  assert.strictEqual(U.Admin.s.state.me.ec, 300);
  await until(() => U.Admin.s.state.online === 10, 'онлайн 10');
  console.log('✓ онлайн-поток, онлайн =', U.Admin.s.state.online);

  // --- пати Admin + Bober
  await ok(post('/api/party/invite', { nick: 'Bober' }, U.Admin.token));
  await until(() => U.Bober.s.state.inv.length === 1, 'приглашение');
  assert(U.Bober.s.notes.some(n => /зовёт/.test(n.t)));
  await ok(post('/api/party/accept', { from: U.Admin.id }, U.Bober.token));
  await until(() => U.Admin.s.state.party && U.Admin.s.state.party.members.length === 2, 'пати');
  await bad(post('/api/lobby/join', { i: 0 }, U.Bober.token), /лидер/);
  console.log('✓ пати');

  // --- лобби 3×3: пати + 4 игрока
  await ok(post('/api/lobby/join', { i: 0 }, U.Admin.token));
  await until(() => U.Bober.s.state.lobby === 0, 'пати в лобби');
  for (const n of ['Kotik', 'Sasha_1', 'Мирон']) await ok(post('/api/lobby/join', { i: 0 }, U[n].token));
  assert.strictEqual((await ok(post('/api/quick', { mode: '3x3' }, U['Dima.K'].token))).lobby, 1);
  await until(() => U.Kotik.s.state.lobbies[0].state === 'accept', 'принятие');
  assert.strictEqual(U.Kotik.s.state.queue, 6);
  for (const n of ['Admin', 'Bober', 'Kotik', 'Sasha_1', 'Мирон', 'Dima.K']) await ok(post('/api/accept', {}, U[n].token), 'accept ' + n);
  await until(() => U.Admin.s.state.match, 'матч');
  const M = U.Admin.s.state.match;
  assert.strictEqual(M.state, 'veto');
  const teamOf = id => (M.teams[0].some(p => p.id === id) ? 0 : 1);
  assert.strictEqual(teamOf(U.Admin.id), teamOf(U.Bober.id), 'пати в одной команде');
  assert.strictEqual(U.Admin.s.state.lobbies[0].p.length, 0, 'лобби освободилось');
  console.log('✓ лобби → принятие → матч #' + M.id + ', команды:', M.teams.map(t => t.map(p => p.nick).join('+')).join(' vs '));

  // --- вето
  const capTok = t => Object.values(U).find(x => x.id === M.caps[t]).token;
  const notCap = Object.values(U).find(x => M.teams.flat().some(p => p.id === x.id) && !M.caps.includes(x.id));
  await bad(post('/api/match/veto', { map: M.pool[0] }, notCap.token), /капитан/);
  await bad(post('/api/match/veto', { map: M.pool[0] }, capTok(1)), /другой/);
  await ok(post('/api/match/veto', { map: 'Порт' }, capTok(0)));
  await bad(post('/api/match/veto', { map: 'Порт' }, capTok(1)), /нельзя/);
  await ok(post('/api/match/veto', { map: 'Сакура' }, capTok(1)));
  await ok(post('/api/match/veto', { map: 'Перрон' }, capTok(0)));
  await ok(post('/api/match/veto', { map: 'Лагуна' }, capTok(1)));
  await until(() => U.Admin.s.state.match.state === 'live', 'live');
  assert.strictEqual(U.Admin.s.state.match.map, 'Пыльный квартал');
  console.log('✓ вето → карта', U.Admin.s.state.match.map);

  // --- код комнаты, чат
  await bad(post('/api/match/room', { code: 'X1' }, notCap.token), /хост/);
  await ok(post('/api/match/room', { code: 'ROOM-777' }, capTok(0)));
  await ok(post('/api/match/chat', { text: 'го го' }, notCap.token));
  await until(() => U.Kotik.s.state.match.room === 'ROOM-777' && U.Kotik.s.state.match.chat.some(c => c.x === 'го го'), 'код и чат');
  await bad(post('/api/lobby/join', { i: 2 }, U.Kotik.token), /в матче/);
  console.log('✓ код комнаты и чат');

  // --- результат: оба капитана — победа A
  const elo0 = {}, ec0 = {};
  for (const n of names) { elo0[n] = U[n].s.state.me.elo; ec0[n] = U[n].s.state.me.ec; }
  await ok(post('/api/match/report', { win: true }, capTok(0)));
  await ok(post('/api/match/report', { win: false }, capTok(1)));
  await until(() => !U.Admin.s.state.match && U.Admin.s.state.recent && U.Admin.s.state.recent.state === 'done', 'итог');
  const R = U.Admin.s.state.recent;
  assert.strictEqual(R.result.winner, 0);
  for (const p of R.teams[0]) {
    const n = Object.keys(U).find(k => U[k].id === p.id);
    await until(() => U[n].s.state.me.elo === elo0[n] + R.result.d, 'elo ' + n);
    assert.strictEqual(U[n].s.state.me.ec, ec0[n] + cfg.rewardWin);
  }
  for (const p of R.teams[1]) {
    const n = Object.keys(U).find(k => U[k].id === p.id);
    await until(() => U[n].s.state.me.elo === elo0[n] - R.result.d, 'elo ' + n);
    assert.strictEqual(U[n].s.state.me.ec, ec0[n] + cfg.rewardLoss);
  }
  console.log('✓ результат: победа A, ELO ±' + R.result.d + ', EC +' + cfg.rewardWin + '/+' + cfg.rewardLoss);

  // --- 2×2: один не принимает → кулдаун
  for (const n of ['Lena', 'Oleg', 'Petya', 'Roma']) await ok(post('/api/lobby/join', { i: 2 }, U[n].token));
  await until(() => U.Lena.s.state.lobbies[2].state === 'accept', 'принятие 2×2');
  for (const n of ['Lena', 'Oleg', 'Petya']) await ok(post('/api/accept', {}, U[n].token));
  await until(() => U.Lena.s.state.lobbies[2].state === 'wait' && U.Lena.s.state.lobbies[2].p.length === 3, 'не принял', 6000);
  await bad(post('/api/lobby/join', { i: 2 }, U.Roma.token), /не принял/);
  assert(U.Roma.s.notes.some(n => /не принял/.test(n.t)));
  console.log('✓ кто не принял — выкинут и получает паузу');

  // --- спор → админ
  await sleep(5200);
  await ok(post('/api/lobby/join', { i: 2 }, U.Roma.token));
  for (const n of ['Lena', 'Oleg', 'Petya', 'Roma']) await ok(post('/api/accept', {}, U[n].token));
  await until(() => U.Lena.s.state.match, 'матч 2×2');
  const M2 = U.Lena.s.state.match;
  // вето по таймауту (2 с на ход, 3 карты → 2 бана)
  await until(() => U.Lena.s.state.match.state === 'live', 'авто-вето', 7000);
  assert.strictEqual(U.Lena.s.state.match.bans.length, 2);
  const cap2 = t => Object.values(U).find(x => x.id === M2.caps[t]).token;
  await ok(post('/api/match/report', { win: true }, cap2(0)));
  await ok(post('/api/match/report', { win: true }, cap2(1)));
  await until(() => U.Lena.s.state.match.state === 'dispute', 'спор');
  await until(() => U.Admin.s.state.disputes === 1, 'админ видит спор');
  const am = await ok(get('/api/admin/matches', U.Admin.token));
  assert.strictEqual(am.list[0].id, M2.id);
  await bad(post('/api/admin/resolve', { id: M2.id, winner: 1 }, U.Lena.token), /администратор/);
  await ok(post('/api/admin/resolve', { id: M2.id, winner: 1 }, U.Admin.token));
  await until(() => !U.Lena.s.state.match && U.Lena.s.state.recent.result.winner === 1, 'решено админом');
  console.log('✓ спор решён админом (авто-вето по таймеру тоже работает)');

  // --- отмена матча голосованием
  for (const n of ['Lena', 'Oleg', 'Petya', 'Roma']) await ok(post('/api/lobby/join', { i: 3 }, U[n].token));
  for (const n of ['Lena', 'Oleg', 'Petya', 'Roma']) await ok(post('/api/accept', {}, U[n].token));
  await until(() => U.Lena.s.state.match, 'матч 3');
  const M3id = U.Lena.s.state.match.id;
  for (const n of ['Lena', 'Oleg']) await ok(post('/api/match/cancel', {}, U[n].token));
  assert(U.Lena.s.state.match, 'двух голосов из 4 мало');
  await ok(post('/api/match/cancel', {}, U.Petya.token));
  await until(() => !U.Lena.s.state.match && U.Lena.s.state.recent.id === M3id && U.Lena.s.state.recent.state === 'cancelled', 'отмена');
  console.log('✓ отмена матча голосованием');

  // --- выход из лобби, быстрая игра, пати распускается
  await ok(post('/api/lobby/join', { i: 1 }, U.Admin.token));
  await until(() => U.Bober.s.state.lobby === 1, 'пати в лобби 2');
  await ok(post('/api/lobby/leave', {}, U.Bober.token));
  await until(() => U.Admin.s.state.lobby === null && U.Bober.s.state.lobby === null, 'вся пати вышла');
  await ok(post('/api/party/leave', {}, U.Bober.token));
  await until(() => !U.Admin.s.state.party, 'пати распущена');
  console.log('✓ выход из лобби всей пати и роспуск пати');

  // --- магазин, бонус, ник, топ, профиль
  await ok(post('/api/daily', {}, U.Kotik.token));
  await bad(post('/api/daily', {}, U.Kotik.token), /уже/);
  await bad(post('/api/shop/buy', { id: 'frame_rainbow' }, U.Kotik.token), /Не хватает/);
  await ok(post('/api/shop/buy', { id: 'frame_violet' }, U.Kotik.token));
  await bad(post('/api/shop/buy', { id: 'frame_violet' }, U.Kotik.token), /Уже/);
  await until(() => U.Kotik.s.state.me.equip.frame === 'frame_violet', 'рамка надета');
  await ok(post('/api/shop/unequip', { type: 'frame' }, U.Kotik.token));
  await ok(post('/api/shop/equip', { id: 'frame_violet' }, U.Kotik.token));
  await ok(post('/api/nick', { nick: 'KotikPro' }, U.Kotik.token));
  await bad(post('/api/nick', { nick: 'KotikPro2' }, U.Kotik.token), /сутки/);
  const top = await ok(get('/api/top', U.Lena.token));
  assert.strictEqual(top.list.length, 10);
  assert(top.list[0].elo >= top.list[9].elo);
  const pr = await ok(get('/api/profile?id=' + U.Kotik.id, U.Lena.token));
  assert.strictEqual(pr.nick, 'KotikPro');
  assert.strictEqual(pr.frame, 'frame_violet');
  assert(pr.history.length >= 1);
  console.log('✓ бонус, магазин, ник, топ, профиль (место #' + pr.rank + ')');

  // --- админ: EC и бан
  await ok(post('/api/admin/ec', { id: 'Roma', amount: 500 }, U.Admin.token));
  await until(() => U.Roma.s.state.me.ec >= 800, 'EC выданы');
  await ok(post('/api/admin/ban', { id: 'Roma', on: true }, U.Admin.token));
  await until(() => U.Roma.s.closedAuth, 'бан закрыл поток');
  await bad(post('/api/login', { nick: 'Roma', pass: 'secret12' }), /заблокирован/);
  await ok(post('/api/admin/ban', { id: 'Roma', on: false }, U.Admin.token));
  await ok(post('/api/login', { nick: 'Roma', pass: 'secret12' }));
  console.log('✓ админ: выдача EC, бан/разбан');

  // --- перезапуск: аккаунты и активный матч сохраняются
  for (const n of ['Admin', 'Bober', 'KotikPro', 'Sasha_1', 'Мирон', 'Dima.K']) {
    const key = n === 'KotikPro' ? 'Kotik' : n;
    await ok(post('/api/lobby/join', { i: 0 }, U[key].token), 'join ' + n);
  }
  for (const k of ['Admin', 'Bober', 'Kotik', 'Sasha_1', 'Мирон', 'Dima.K']) await ok(post('/api/accept', {}, U[k].token));
  await until(() => U.Admin.s.state.match, 'матч перед перезапуском');
  const mid = U.Admin.s.state.match.id;
  for (const n of names) U[n].s.req.destroy();
  await stopServer();
  await start();
  const s2 = stream(U.Admin.token);
  await until(() => s2.state && s2.state.match && s2.state.match.id === mid, 'матч после перезапуска');
  assert.strictEqual(s2.state.me.nick, 'Admin');
  await ok(post('/api/login', { nick: 'KotikPro', pass: 'secret12' }));
  console.log('✓ перезапуск: аккаунты, сессии и матч #' + mid + ' на месте');
  s2.req.destroy();

  const h = await ok(get('/api/health'));
  assert.strictEqual(h.users, 10);
  await stopServer();
  console.log('\nВСЕ ТЕСТЫ ПРОЙДЕНЫ');
  process.exit(0);
})().catch(async e => {
  console.error('ТЕСТ УПАЛ:', e);
  try { await stopServer(); } catch (_) {}
  process.exit(1);
});
