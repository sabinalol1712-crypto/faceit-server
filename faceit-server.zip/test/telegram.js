'use strict';
// Тест Telegram-бота на поддельном Bot API: подключение токена, привязка, уведомления, вход, восстановление пароля, команды.
// Запуск: node test/telegram.js
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');
const PORT = 19000 + Math.floor(Math.random() * 500);
const TGPORT = PORT + 600;
const TOKEN = '123456789:AAHfakeTokenForTestsOnly_abcdefghijk';
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'faceit-tg-'));

// ---------- поддельный Telegram ----------
const sent = [];
const docs = [];
const queue = [];
let waiting = null;
let updId = 1;
function pushUpdate(chatId, text, username) {
  queue.push({ update_id: updId++, message: { message_id: updId, chat: { id: chatId, type: 'private' }, from: { id: chatId, username }, text } });
  if (waiting) { const w = waiting; waiting = null; w(); }
}
const fake = http.createServer((req, res) => {
  let body = '';
  req.on('data', c => { body += c; });
  req.on('end', () => {
    const m = req.url.match(/^\/bot([^/]+)\/(\w+)$/);
    const ok = r => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: true, result: r })); };
    if (!m || m[1] !== TOKEN) { res.writeHead(401); return res.end(JSON.stringify({ ok: false, error_code: 401, description: 'Unauthorized' })); }
    const p = body && body[0] === '{' ? JSON.parse(body) : {};
    if (m[2] === 'getMe') return ok({ id: 1, is_bot: true, username: 'etn_test_bot' });
    if (m[2] === 'setMyCommands') return ok(true);
    if (m[2] === 'sendMessage') { sent.push(p); return ok({ message_id: sent.length }); }
    if (m[2] === 'sendDocument') { docs.push(body); return ok({ message_id: 1 }); }
    if (m[2] === 'getUpdates') {
      const give = () => ok(queue.filter(u => u.update_id >= (p.offset || 0)));
      if (queue.some(u => u.update_id >= (p.offset || 0))) return give();
      const t = setTimeout(() => { waiting = null; give(); }, 800);
      waiting = () => { clearTimeout(t); give(); };
      return;
    }
    ok(true);
  });
});

let proc;
function start() {
  return new Promise((resolve, reject) => {
    proc = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
      env: Object.assign({}, process.env, { PORT: String(PORT), DATA_DIR: DATA, FACEIT_TEST: '1', TG_API: 'http://127.0.0.1:' + TGPORT }),
      stdio: ['ignore', 'pipe', 'pipe']
    });
    proc.stderr.on('data', d => process.stderr.write('[server] ' + d));
    proc.stdout.on('data', d => { if (String(d).includes('запущен')) resolve(); });
    proc.on('exit', c => { if (c) reject(new Error('exit ' + c)); });
  });
}
async function call(method, p, body, token) {
  const res = await fetch('http://127.0.0.1:' + PORT + p, {
    method, headers: Object.assign({ 'Content-Type': 'application/json', 'X-Forwarded-Proto': 'https', 'X-Forwarded-Host': 'faceit.1-2-3-4.sslip.io' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined
  });
  return Object.assign(await res.json(), { status: res.status });
}
const post = (p, b, t) => call('POST', p, b, t);
const get = (p, t) => call('GET', p, null, t);
async function ok(pr, what) { const r = await pr; if (!r.ok) throw new Error((what || '') + ' → ' + r.status + ' ' + r.error); return r; }
async function bad(pr, re) { const r = await pr; assert(!r.ok, 'ожидалась ошибка ' + re); if (re) assert(re.test(r.error), r.error); return r; }
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, what, ms = 5000) { const t = Date.now(); while (Date.now() - t < ms) { try { if (fn()) return; } catch (_) {} await sleep(30); } throw new Error('не дождались: ' + what); }
function stream(token) {
  const s = { state: null };
  s.req = http.get('http://127.0.0.1:' + PORT + '/api/events?t=' + token, res => {
    let buf = '';
    res.setEncoding('utf8');
    res.on('data', ch => {
      buf += ch;
      let k;
      while ((k = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, k); buf = buf.slice(k + 2);
        const line = block.split('\n').find(l => l.startsWith('data: '));
        if (block.includes('event: state') && line) s.state = JSON.parse(line.slice(6));
      }
    });
  });
  s.req.on('error', () => {});
  return s;
}
const lastTo = chat => [...sent].reverse().find(m => m.chat_id === chat);

(async () => {
  await new Promise(r => fake.listen(TGPORT, r));
  await start();
  const names = ['Admin', 'Kotik', 'Bober', 'Lena', 'Oleg', 'Petya'];
  const U = {};
  for (const n of names) { const r = await ok(post('/api/register', { nick: n, pass: 'secret12' })); U[n] = { token: r.token, id: r.id, s: null }; }
  for (const n of names) U[n].s = stream(U[n].token);
  await until(() => names.every(n => U[n].s.state), 'потоки');

  // бот не подключён
  assert.strictEqual((await ok(get('/api/meta'))).tgBot, '');
  await bad(post('/api/tg/link', {}, U.Kotik.token), /не подключён/);
  await bad(post('/api/admin/tg', { token: TOKEN }, U.Kotik.token), /администратор/);
  await bad(post('/api/admin/tg', { token: 'abc' }, U.Admin.token), /не похоже/);
  await bad(post('/api/admin/tg', { token: '999999:AAHwrongwrongwrongwrongwrongwrong1' }, U.Admin.token), /не принял/);
  const set = await ok(post('/api/admin/tg', { token: TOKEN }, U.Admin.token));
  assert.strictEqual(set.bot, 'etn_test_bot');
  assert.strictEqual((await ok(get('/api/meta'))).tgBot, 'etn_test_bot');
  const st = await ok(get('/api/admin/tg', U.Admin.token));
  assert.strictEqual(st.site, 'https://faceit.1-2-3-4.sslip.io');
  console.log('✓ токен бота подключается через админку, неверный — отклоняется');

  // привязка 4 игроков
  const chats = { Admin: 5000, Kotik: 5001, Bober: 5002, Lena: 5003 };
  for (const n of Object.keys(chats)) {
    const l = await ok(post('/api/tg/link', {}, U[n].token));
    assert(l.url.startsWith('https://t.me/etn_test_bot?start=L'));
    pushUpdate(chats[n], '/start ' + l.payload, n.toLowerCase());
  }
  await until(() => Object.keys(chats).every(n => U[n].s.state.me.tg && U[n].s.state.me.tg.name === '@' + n.toLowerCase()), 'привязка в снимке');
  assert(/привязан к аккаунту <b>Kotik<\/b>/.test(lastTo(5001).text));
  assert.strictEqual(lastTo(5001).reply_markup.inline_keyboard[0][0].url, 'https://faceit.1-2-3-4.sslip.io');
  pushUpdate(5001, '/start Lxxxxxxxx', 'kotik');
  await until(() => /устарела/.test(lastTo(5001).text), 'старая ссылка');
  console.log('✓ привязка Telegram через /start, имя видно в профиле');

  // уведомления: приглашение, матч найден, код комнаты, результат
  await ok(post('/api/party/invite', { nick: 'Kotik' }, U.Bober.token));
  await until(() => /зовёт тебя в пати/.test(lastTo(5001).text), 'уведомление о пати');
  await ok(post('/api/party/decline', { from: U.Bober.id }, U.Kotik.token));
  for (const n of names) await ok(post('/api/lobby/join', { i: 0 }, U[n].token));
  await until(() => [5000, 5001, 5002, 5003].every(c => /Матч найден/.test(lastTo(c).text)), 'матч найден в TG');
  for (const n of names) await ok(post('/api/accept', {}, U[n].token));
  await until(() => U.Admin.s.state.match, 'матч');
  const M = U.Admin.s.state.match;
  const tokById = id => Object.values(U).find(x => x.id === id).token;
  for (let i = 0; i < M.pool.length - 1; i++) {
    const cur = (await until(() => true, ''), U.Admin.s.state.match);
    const rest = cur.pool.filter(x => !cur.bans.some(b => b.map === x));
    await ok(post('/api/match/veto', { map: rest[0] }, tokById(cur.caps[cur.turn])));
    await until(() => U.Admin.s.state.match.bans.length === i + 1, 'бан ' + i);
  }
  await until(() => U.Admin.s.state.match.state === 'live', 'live');
  await ok(post('/api/match/room', { code: 'ROOM-55' }, tokById(M.caps[0])));
  const others = Object.entries(chats).filter(([n]) => U[n].id !== M.caps[0]).map(([, c]) => c);
  await until(() => others.every(c => /ROOM-55/.test(lastTo(c).text)), 'код комнаты в TG');
  // Lena выключает уведомления командой /off
  pushUpdate(5003, '/off', 'lena');
  await until(() => U.Lena.s.state.me.tg.notify === false, '/off');
  const lenaBefore = sent.filter(m => m.chat_id === 5003).length;
  await ok(post('/api/match/report', { win: true }, tokById(M.caps[0])));
  await ok(post('/api/match/report', { win: false }, tokById(M.caps[1])));
  await until(() => [5000, 5001, 5002].every(c => /Победа|Поражение/.test(lastTo(c).text)), 'результат в TG');
  await sleep(300);
  assert.strictEqual(sent.filter(m => m.chat_id === 5003).length, lenaBefore, 'после /off уведомлений нет');
  console.log('✓ уведомления: пати, матч найден, код комнаты, результат; /off выключает');

  // команды
  pushUpdate(5001, '/profile', 'kotik');
  await until(() => /Kotik<\/b>  ·  ID #/.test(lastTo(5001).text), '/profile');
  pushUpdate(5001, '/top', 'kotik');
  await until(() => /Топ-10/.test(lastTo(5001).text), '/top');
  console.log('✓ команды /profile и /top');

  // вход через Telegram
  const lg = await ok(post('/api/tg/login', {}));
  assert((await ok(get('/api/tg/check?code=' + lg.code))).wait);
  pushUpdate(7777, '/start ' + lg.payload, 'stranger');
  await until(() => /не привязан/.test(lastTo(7777).text), 'чужой Telegram');
  assert((await ok(get('/api/tg/check?code=' + lg.code))).wait);
  pushUpdate(5002, '/start ' + lg.payload, 'bober');
  let ch;
  await until(async () => false, '', 300).catch(() => {});
  for (let i = 0; i < 50; i++) { ch = await ok(get('/api/tg/check?code=' + lg.code)); if (ch.token) break; await sleep(50); }
  assert(ch.token && ch.id === U.Bober.id);
  assert((await ok(get('/api/top', ch.token))).list.length === 6);
  await bad(get('/api/tg/check?code=' + lg.code), /устарела/);
  console.log('✓ вход через Telegram (и чужой Telegram не пускает)');

  // восстановление пароля
  await bad(post('/api/tg/reset', { nick: 'Oleg' }), /не привязан Telegram/);
  await ok(post('/api/tg/reset', { nick: 'lena' }));
  const msg = lastTo(5003).text;
  const codeM = msg.match(/<b>(\d{6})<\/b>/);
  assert(codeM, 'код пришёл даже при выключенных уведомлениях? ' + msg);
  await bad(post('/api/tg/reset', { nick: 'Lena' }), /через минуту/);
  await bad(post('/api/tg/reset2', { nick: 'Lena', code: '000000', pass: 'newpass1' }), /Неверный/);
  const rr = await ok(post('/api/tg/reset2', { nick: 'Lena', code: codeM[1], pass: 'newpass1' }));
  assert(rr.token);
  await bad(post('/api/login', { nick: 'Lena', pass: 'secret12' }), /Неверный/);
  await ok(post('/api/login', { nick: 'Lena', pass: 'newpass1' }));
  await bad(get('/api/top', U.Lena.token), /Войди/);
  console.log('✓ восстановление пароля кодом из Telegram (старые сессии сброшены)');

  // бэкап: в Telegram админу (Admin привязан), скачивание, восстановление с перезапуском
  const bk = await ok(post('/api/admin/backup', {}, U.Admin.token));
  assert.strictEqual(bk.sent, 1, 'бэкап отправлен одному админу');
  assert(/filename="etn-faceit-.*\.json\.gz"/.test(docs[0]) && /Бэкап ETN FACEIT/.test(docs[0]));
  await bad(post('/api/admin/backup', {}, U.Kotik.token), /администратор/);
  const list = await ok(get('/api/admin/backups', U.Admin.token));
  assert(list.files.length >= 1 && list.last.time > 0);
  const fileRes = await fetch('http://127.0.0.1:' + PORT + '/api/admin/backup/file?name=' + list.files[0].name, { headers: { Authorization: 'Bearer ' + U.Admin.token } });
  assert.strictEqual(fileRes.status, 200);
  const gz = Buffer.from(await fileRes.arrayBuffer());
  const snap = JSON.parse(require('zlib').gunzipSync(gz).toString('utf8'));
  assert(snap.users[U.Petya.id]);
  pushUpdate(5000, '/backup', 'admin');
  await until(() => docs.length === 2, 'бэкап по команде /backup');
  // меняем копию: Petya получает 777 EC, и восстанавливаем
  snap.users[U.Petya.id].ec = 777;
  const before = Date.now();
  const rres = await fetch('http://127.0.0.1:' + PORT + '/api/admin/restore', { method: 'POST', headers: { Authorization: 'Bearer ' + U.Admin.token }, body: require('zlib').gzipSync(JSON.stringify(snap)) });
  assert.strictEqual(rres.status, 200);
  await new Promise(r => { if (proc.exitCode !== null) return r(); proc.once('exit', r); });
  assert.strictEqual(proc.exitCode, 75);
  await start();
  const pp = await ok(get('/api/admin/user?q=Petya', U.Admin.token));
  assert.strictEqual(pp.ec, 777);
  assert(require('fs').readdirSync(require('path').join(DATA, 'backups')).some(f => f.startsWith('before-restore-')));
  for (const n of names) U[n].s = stream(U[n].token);
  await until(() => names.filter(n => n !== 'Lena').every(n => U[n].s.state), 'потоки после восстановления');
  console.log('✓ бэкап в Telegram и по /backup, скачивание, восстановление с перезапуском');

  // отвязка и перезапуск: токен бота и привязки сохраняются
  await ok(post('/api/tg/unlink', {}, U.Kotik.token));
  await until(() => U.Kotik.s.state.me.tg === null, 'отвязка');
  for (const n of names) U[n].s.req.destroy();
  await new Promise(r => { proc.once('exit', r); proc.kill('SIGTERM'); });
  await start();
  assert.strictEqual((await ok(get('/api/meta'))).tgBot, 'etn_test_bot');
  pushUpdate(5000, '/profile', 'admin');
  await until(() => /Admin<\/b>/.test(lastTo(5000).text), 'бот после перезапуска');
  console.log('✓ после перезапуска бот и привязки на месте');

  await new Promise(r => { proc.once('exit', r); proc.kill('SIGTERM'); });
  fake.close();
  console.log('\nTELEGRAM: ВСЕ ТЕСТЫ ПРОЙДЕНЫ');
  process.exit(0);
})().catch(e => { console.error('ТЕСТ УПАЛ:', e); try { proc.kill(); } catch (_) {} process.exit(1); });
