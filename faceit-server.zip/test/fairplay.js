'use strict';
// Тест честной игры: лобби по уровню, нарастающие штрафы за непринятый матч и «Отказаться», голосование за ливера, снятие штрафа.
// Запуск: node test/fairplay.js
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');
const PORT = 19600 + Math.floor(Math.random() * 300);
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'faceit-fair-'));
const CFG = path.join(DATA, 'config.json');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
Object.assign(cfg, { acceptSeconds: 2, vetoSeconds: 30, declinePenalty: [3, 6], leaveBan: [4, 8] });
fs.writeFileSync(CFG, JSON.stringify(cfg));

let proc;
function start() {
  return new Promise((resolve, reject) => {
    proc = spawn(process.execPath, [path.join(ROOT, 'server.js')], { env: Object.assign({}, process.env, { PORT: String(PORT), DATA_DIR: DATA, CONFIG: CFG, FACEIT_TEST: '1' }), stdio: ['ignore', 'pipe', 'pipe'] });
    proc.stderr.on('data', d => process.stderr.write('[server] ' + d));
    proc.stdout.on('data', d => { if (String(d).includes('запущен')) resolve(); });
    proc.on('exit', c => { if (c) reject(new Error('exit ' + c)); });
  });
}
async function call(method, p, body, token) {
  const res = await fetch('http://127.0.0.1:' + PORT + p, { method, headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}), body: body ? JSON.stringify(body) : undefined });
  return Object.assign(await res.json(), { status: res.status });
}
const post = (p, b, t) => call('POST', p, b, t);
const get = (p, t) => call('GET', p, null, t);
async function ok(pr, what) { const r = await pr; if (!r.ok) throw new Error((what || '') + ' → ' + r.status + ' ' + r.error); return r; }
async function bad(pr, re) { const r = await pr; assert(!r.ok, 'ожидалась ошибка ' + re); if (re) assert(re.test(r.error), r.error); return r; }
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, what, ms = 6000) { const t = Date.now(); while (Date.now() - t < ms) { try { if (fn()) return; } catch (_) {} await sleep(30); } throw new Error('не дождались: ' + what); }
function stream(token) {
  const s = { state: null, notes: [] };
  s.req = http.get('http://127.0.0.1:' + PORT + '/api/events?t=' + token, res => {
    let buf = '';
    res.setEncoding('utf8');
    res.on('data', ch => {
      buf += ch;
      let k;
      while ((k = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, k); buf = buf.slice(k + 2);
        const line = block.split('\n').find(l => l.startsWith('data: '));
        if (block.includes('event: state') && line) {
          s.state = JSON.parse(line.slice(6));
          for (const n of s.state.notes) if (!s.notes.some(x => x.id === n.id)) s.notes.push(n);
        }
      }
    });
  });
  s.req.on('error', () => {});
  return s;
}

(async () => {
  await start();
  const names = ['Admin', 'Pro1', 'Pro2', 'Low1', 'Low2', 'Low3', 'Low4', 'Low5'];
  const U = {};
  for (const n of names) { const r = await ok(post('/api/register', { nick: n, pass: 'secret12' })); U[n] = { token: r.token, id: r.id }; U[n].s = stream(r.token); }
  await until(() => names.every(n => U[n].s.state), 'потоки');
  for (const n of ['Pro1', 'Pro2']) await ok(post('/api/admin/elo', { id: U[n].id, elo: 1500 }, U.Admin.token));
  await until(() => U.Pro1.s.state.me.lvl === 6, 'уровень 6');
  const L = U.Low1.s.state.lobbies;
  assert.deepStrictEqual(L.map(l => [l.mode, l.min, l.max]), [['3x3', 1, 10], ['3x3', 1, 4], ['3x3', 5, 10], ['2x2', 1, 10], ['2x2', 1, 4], ['2x2', 5, 10]]);

  // ---- лобби по уровню
  await bad(post('/api/lobby/join', { i: 2 }, U.Low1.token), /для 5–10 уровня/);
  await bad(post('/api/lobby/join', { i: 1 }, U.Pro1.token), /для 1–4 уровня/);
  assert.strictEqual((await ok(post('/api/quick', { mode: '3x3' }, U.Pro1.token))).lobby, 3, 'про → лобби 5–10');
  assert.strictEqual((await ok(post('/api/quick', { mode: '3x3' }, U.Low1.token))).lobby, 2, 'новичок → лобби 1–4');
  await ok(post('/api/lobby/leave', {}, U.Pro1.token));
  await ok(post('/api/lobby/leave', {}, U.Low1.token));
  // пати со смешанными уровнями не пускают в 1–4
  await ok(post('/api/party/invite', { nick: 'Pro2' }, U.Low2.token));
  await until(() => U.Pro2.s.state.inv.length, 'приглашение');
  await ok(post('/api/party/accept', { from: U.Low2.id }, U.Pro2.token));
  await bad(post('/api/lobby/join', { i: 1 }, U.Low2.token), /Pro2: это лобби для 1–4/);
  assert.strictEqual((await ok(post('/api/quick', { mode: '3x3' }, U.Low2.token))).lobby, 1, 'смешанная пати → «все уровни»');
  await ok(post('/api/lobby/leave', {}, U.Low2.token));
  await ok(post('/api/party/leave', {}, U.Pro2.token));
  console.log('✓ лобби по уровню: чужой уровень не пускает, быстрая игра выбирает подходящее, пати проверяется целиком');

  // ---- штраф за непринятый матч: 3 с, потом 6 с
  const four = ['Low1', 'Low2', 'Low3', 'Low4'];
  for (const n of four) await ok(post('/api/lobby/join', { i: 3 }, U[n].token));
  await until(() => U.Low1.s.state.lobbies[3].state === 'accept', 'принятие');
  for (const n of ['Low1', 'Low2', 'Low3']) await ok(post('/api/accept', {}, U[n].token));
  await until(() => U.Low4.s.state.me.cd > 0, 'штраф 1', 5000);
  assert.strictEqual(U.Low4.s.state.me.banReason, 'не принял матч');
  await bad(post('/api/lobby/join', { i: 3 }, U.Low4.token), /не принял матч/);
  await sleep(3200);
  await ok(post('/api/lobby/join', { i: 3 }, U.Low4.token));
  await until(() => U.Low1.s.state.lobbies[3].state === 'accept', 'принятие 2');
  // «Отказаться» = тоже непринятие, второй раз за сутки → 6 с
  await ok(post('/api/lobby/leave', {}, U.Low4.token));
  await until(() => U.Low4.s.notes.some(x => /2-й раз/.test(x.t)), 'второй штраф');
  const left = U.Low4.s.state.me.cd - U.Low4.s.state.t;
  assert(left > 4000 && left <= 6000, 'второй штраф 6 с, а не ' + left);
  console.log('✓ непринятый матч и «Отказаться»: штраф растёт (3 с → 6 с)');

  // ---- ливер: 2 голоса из 3 → матч отменён, −25 ELO и бан
  for (const n of ['Low1', 'Low2', 'Low3']) if (U[n].s.state.lobby !== 3) await ok(post('/api/lobby/join', { i: 3 }, U[n].token));
  await ok(post('/api/lobby/join', { i: 3 }, U.Low5.token));
  await until(() => U.Low1.s.state.lobbies[3].state === 'accept', 'принятие 3');
  for (const n of ['Low1', 'Low2', 'Low3', 'Low5']) await ok(post('/api/accept', {}, U[n].token));
  await until(() => U.Low1.s.state.match, 'матч');
  const M = U.Low1.s.state.match;
  assert.strictEqual(M.leaverNeed, 2);
  const elo0 = {};
  for (const n of ['Low1', 'Low2', 'Low3', 'Low5']) elo0[n] = U[n].s.state.me.elo;
  await bad(post('/api/match/leaver', { id: U.Low1.id }, U.Low1.token), /против себя/);
  await ok(post('/api/match/leaver', { id: U.Low5.id }, U.Low1.token));
  await until(() => (U.Low2.s.state.match.leavers[U.Low5.id] || []).length === 1, 'голос 1');
  assert(U.Low2.s.state.match, 'одного голоса мало');
  await ok(post('/api/match/leaver', { id: U.Low5.id }, U.Low2.token));
  await until(() => !U.Low1.s.state.match && U.Low1.s.state.recent && U.Low1.s.state.recent.state === 'cancelled', 'матч отменён');
  await until(() => U.Low5.s.state.me.elo === elo0.Low5 - 25, 'штраф ELO');
  for (const n of ['Low1', 'Low2', 'Low3']) assert.strictEqual(U[n].s.state.me.elo, elo0[n], 'у остальных ELO не меняется');
  await bad(post('/api/lobby/join', { i: 0 }, U.Low5.token), /покинул матч #/);
  const prof = await ok(get('/api/profile?id=' + U.Low5.id, U.Low1.token));
  assert.strictEqual(prof.leaves, 1);
  assert(prof.history[0].leave);
  const au = await ok(get('/api/admin/user?q=Low5', U.Admin.token));
  assert(au.banUntil > 0 && /покинул/.test(au.banReason));
  console.log('✓ ливер: голосование 2/3, матч отменён, ливер −25 ELO и бан, остальным ELO не меняется');

  // ---- админ снимает штраф
  await ok(post('/api/admin/pardon', { id: U.Low5.id }, U.Admin.token));
  await ok(post('/api/lobby/join', { i: 0 }, U.Low5.token));
  console.log('✓ админ снимает штраф');

  // ---- штрафы переживают перезапуск
  await ok(post('/api/lobby/leave', {}, U.Low5.token));
  for (const n of ['Low1', 'Low2', 'Low3', 'Low5']) await ok(post('/api/lobby/join', { i: 3 }, U[n].token));
  await until(() => U.Low1.s.state.lobbies[3].state === 'accept', 'принятие 4');
  for (const n of ['Low1', 'Low2', 'Low3', 'Low5']) await ok(post('/api/accept', {}, U[n].token));
  await until(() => U.Low1.s.state.match, 'матч 2');
  await ok(post('/api/match/leaver', { id: U.Low3.id }, U.Low1.token));
  await ok(post('/api/match/leaver', { id: U.Low3.id }, U.Low2.token));
  await until(() => !U.Low1.s.state.match, 'матч 2 отменён');
  for (const n of names) U[n].s.req.destroy();
  await new Promise(r => { proc.once('exit', r); proc.kill('SIGTERM'); });
  await start();
  await bad(post('/api/lobby/join', { i: 0 }, U.Low3.token), /покинул матч/);
  console.log('✓ бан сохраняется после перезапуска');

  await new Promise(r => { proc.once('exit', r); proc.kill('SIGTERM'); });
  console.log('\nЧЕСТНАЯ ИГРА: ВСЕ ТЕСТЫ ПРОЙДЕНЫ');
  process.exit(0);
})().catch(e => { console.error('ТЕСТ УПАЛ:', e); try { proc.kill(); } catch (_) {} process.exit(1); });
