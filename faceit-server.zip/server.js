'use strict';
// ETN FACEIT — сервер. Node.js 16+ без внешних зависимостей.
// Сайт: папка public/. Онлайн: GET /api/events (Server-Sent Events) + POST-запросы /api/...
const http = require('http');
const fs = require('fs');
const path = require('path');
const { createStore } = require('./lib/db');
const { createCore, LEVELS, ITEMS } = require('./lib/core');
const { createTelegram } = require('./lib/telegram');

const ROOT = __dirname;
const cfg = JSON.parse(fs.readFileSync(process.env.CONFIG || path.join(ROOT, 'config.json'), 'utf8'));
if (process.env.FACEIT_TEST === '1') cfg.noLimits = true;
const PORT = Number(process.env.PORT) || cfg.port || 8090;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const PUB = path.join(ROOT, 'public');

const store = createStore(DATA_DIR);
const core = createCore(store, cfg);
const tg = createTelegram(store, core, cfg);

const META = {
  brand: cfg.brand || 'ETN',
  season: cfg.season || 'none',
  modes: Object.fromEntries(Object.entries(cfg.modes).map(([k, m]) => [k, { title: m.title, size: m.size, maps: m.maps }])),
  catalog: ITEMS,
  levels: LEVELS,
  partyMax: cfg.partyMax,
  rewards: { win: cfg.rewardWin, loss: cfg.rewardLoss, daily: cfg.dailyBonus },
  acceptSeconds: cfg.acceptSeconds,
  autoConfirmMinutes: cfg.autoConfirmMinutes
};

// ---------- SSE-подключения ----------
const streams = new Set();
function pushAll() {
  const cache = new Map();
  for (const c of streams) {
    let data = cache.get(c.uid);
    if (data === undefined) {
      const snap = core.snapshot(c.uid);
      data = snap ? 'event: state\ndata: ' + JSON.stringify(snap) + '\n\n' : null;
      cache.set(c.uid, data);
    }
    if (data) c.res.write(data);
  }
}
core.on('change', pushAll);
core.on('kick', uid => {
  for (const c of streams) if (c.uid === uid) { c.res.write('event: auth\ndata: {}\n\n'); c.res.end(); }
});
setInterval(() => { for (const c of streams) c.res.write(': ping\n\n'); }, 20000);

function openStream(req, res, user) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no'
  });
  res.write('retry: 2000\n\n');
  const c = { uid: user.id, res };
  streams.add(c);
  core.connect(user.id);
  const snap = core.snapshot(user.id);
  res.write('event: state\ndata: ' + JSON.stringify(snap) + '\n\n');
  const close = () => {
    if (!streams.has(c)) return;
    streams.delete(c);
    core.disconnect(user.id);
  };
  req.on('close', close);
  res.on('close', close);
}

// ---------- HTTP ----------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8', '.ico': 'image/x-icon', '.webp': 'image/webp'
};

function clientIp(req) {
  const ra = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  const trusted = /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|::1$|f[cd])/.test(ra);
  const xff = req.headers['x-forwarded-for'];
  if (trusted && xff) return String(xff).split(',')[0].trim();
  return ra;
}

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', ch => {
      size += ch.length;
      if (size > 16384) { reject(Object.assign(new Error('Слишком большой запрос'), { status: 413 })); req.destroy(); return; }
      chunks.push(ch);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (e) { reject(Object.assign(new Error('Неверный JSON'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(PUB, rel));
  if (!file.startsWith(PUB + path.sep)) { res.writeHead(403); return res.end(); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) {
      // любые неизвестные пути — главная страница (одностраничное приложение)
      if (!path.extname(rel)) return serveStatic(req, res, '/index.html');
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Не найдено');
    }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

const api = {
  'GET /api/meta': () => Object.assign({}, META, { tgBot: tg.botName() }),
  'GET /api/health': () => core.health(),
  'POST /api/register': (u, b, q, req) => core.register(b.nick, b.pass, clientIp(req)),
  'POST /api/login': (u, b, q, req) => core.login(b.nick, b.pass, clientIp(req)),
  'POST /api/logout': (u, b, q, req) => { core.logout(tokenOf(req)); return {}; },
  'GET /api/top': (u, b, q) => core.top(q.get('by') === 'wins' ? 'wins' : 'elo', u.id),
  'GET /api/profile': (u, b, q) => core.profile(q.get('id') || u.id),
  'GET /api/match': (u, b, q) => core.matchInfo(q.get('id')),

  'POST /api/lobby/join': (u, b) => core.joinLobby(u, b.i),
  'POST /api/lobby/leave': u => core.leaveLobby(u),
  'POST /api/quick': (u, b) => ({ lobby: core.quickPlay(u, b.mode) }),
  'POST /api/accept': u => core.accept(u),

  'POST /api/party/invite': (u, b) => core.invite(u, b.nick),
  'POST /api/party/accept': (u, b) => core.acceptInvite(u, b.from),
  'POST /api/party/decline': (u, b) => core.declineInvite(u, b.from),
  'POST /api/party/leave': u => core.leaveParty(u),
  'POST /api/party/kick': (u, b) => core.kickFromParty(u, b.id),

  'POST /api/match/veto': (u, b) => core.veto(u, b.map),
  'POST /api/match/room': (u, b) => core.setRoom(u, b.code),
  'POST /api/match/report': (u, b) => core.report(u, !!b.win),
  'POST /api/match/cancel': u => core.cancelVote(u),
  'POST /api/match/chat': (u, b) => core.chat(u, b.text),

  'POST /api/shop/buy': (u, b) => core.buy(u, b.id),
  'POST /api/shop/equip': (u, b) => core.equip(u, b.id),
  'POST /api/shop/unequip': (u, b) => core.unequip(u, b.type),
  'POST /api/daily': u => ({ bonus: core.daily(u) }),
  'POST /api/nick': (u, b) => core.changeNick(u, b.nick),
  'POST /api/password': (u, b) => core.changePassword(u, b.old, b.pass),

  'POST /api/tg/link': u => tg.linkStart(u),
  'POST /api/tg/unlink': u => tg.unlink(u),
  'POST /api/tg/notify': (u, b) => tg.setNotify(u, b.on),
  'POST /api/tg/login': (u, b, q, req) => tg.loginStart(clientIp(req)),
  'GET /api/tg/check': (u, b, q) => tg.loginCheck(q.get('code')),
  'POST /api/tg/reset': (u, b, q, req) => tg.resetStart(b.nick, clientIp(req)),
  'POST /api/tg/reset2': (u, b) => tg.resetFinish(b.nick, b.code, b.pass),
  'GET /api/admin/tg': u => tg.adminStatus(u),
  'POST /api/admin/tg': (u, b, q, req) => tg.adminSetToken(u, b.token, siteUrl(req)),

  'GET /api/admin/matches': u => ({ list: core.adminMatches(u) }),
  'GET /api/admin/user': (u, b, q) => core.adminUser(u, q.get('q')),
  'POST /api/admin/resolve': (u, b) => core.adminResolve(u, b.id, b.winner),
  'POST /api/admin/ec': (u, b) => core.adminEc(u, b.id, b.amount),
  'POST /api/admin/elo': (u, b) => core.adminElo(u, b.id, b.elo),
  'POST /api/admin/ban': (u, b) => core.adminBan(u, b.id, b.on),
  'POST /api/admin/admin': (u, b) => core.adminAdmin(u, b.id, b.on)
};
const PUBLIC = new Set(['GET /api/meta', 'GET /api/health', 'POST /api/register', 'POST /api/login', 'POST /api/logout',
  'POST /api/tg/login', 'GET /api/tg/check', 'POST /api/tg/reset', 'POST /api/tg/reset2']);

function siteUrl(req) {
  const proto = String(req.headers['x-forwarded-proto'] || (req.socket.encrypted ? 'https' : 'http')).split(',')[0].trim();
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  return host ? proto + '://' + host : '';
}

function tokenOf(req, q) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) return h.slice(7).trim();
  return q ? q.get('t') : null;
}

async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  if (!p.startsWith('/api/')) {
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    return serveStatic(req, res, p);
  }
  if (p === '/api/events' && req.method === 'GET') {
    const u = core.auth(tokenOf(req, url.searchParams));
    if (!u) {
      res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache' });
      return res.end('event: auth\ndata: {}\n\n');
    }
    return openStream(req, res, u);
  }
  const key = req.method + ' ' + p;
  const fn = api[key];
  if (!fn) return send(res, 404, { error: 'Нет такого запроса' });
  try {
    let u = null;
    if (!PUBLIC.has(key)) {
      u = core.auth(tokenOf(req));
      if (!u) return send(res, 401, { error: 'Войди в аккаунт', auth: false });
      if (!core.limit('act:' + u.id, 15, 30)) return send(res, 429, { error: 'Слишком много действий, помедленнее' });
    }
    const body = req.method === 'POST' ? await readBody(req) : {};
    const out = await fn(u, body || {}, url.searchParams, req);
    send(res, 200, Object.assign({ ok: true }, out || {}));
  } catch (e) {
    if (e && e.status) return send(res, e.status, { error: e.message });
    console.error('[api]', key, e);
    send(res, 500, { error: 'Ошибка сервера' });
  }
}

const server = http.createServer((req, res) => {
  handle(req, res).catch(e => { console.error(e); try { send(res, 500, { error: 'Ошибка сервера' }); } catch (_) {} });
});
server.keepAliveTimeout = 65000;
server.headersTimeout = 70000;
server.listen(PORT, () => {
  console.log('ETN FACEIT запущен: http://localhost:' + PORT + '  (данные: ' + DATA_DIR + ')');
});

function shutdown() {
  try { store.saveNow(); } catch (e) { console.error(e); }
  for (const c of streams) { try { c.res.end(); } catch (_) {} }
  process.exit(0);
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
